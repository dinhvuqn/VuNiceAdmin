export enum roleEnum {
  STAFF = 10,
  PM = 20,
  DIRETOR = 30,
}
