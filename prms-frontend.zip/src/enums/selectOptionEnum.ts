enum SelectOptionEnum {
  USER_ROLE = 'userRole',
  USER = 'user',
  PROJECT_ROLE = 'projectRole',
}

export default SelectOptionEnum;
