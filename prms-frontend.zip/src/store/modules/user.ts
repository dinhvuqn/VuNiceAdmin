import { router } from '@/router';
import { defineStore } from 'pinia';
import UserService, { TLoginRequest } from '@/services/users';
import { getToken, setToken, removeToken } from '@/utils/auth';
import { THrmsUser } from '@/services/users/model';
import { store } from '@/store';

const initUserInfo: THrmsUser = {
  userID: '',
  account: '',
  email: '',
  firstName: '',
  lastName: '',
  imageBase64: '',
  loginFirstTimeFlag: false,
  joinDate: '',
  leftDate: '',
  tel: '',
  gender: undefined,
  genderName: '',
  statusCode: undefined,
  statusName: '',
};

export const useUserStore = defineStore({
  id: 'app-user',
  state: () => ({
    token: '',
    userInfo: { ...initUserInfo },
  }),
  getters: {
    getToken(): string {
      return this.token || getToken();
    },
    avatar(): string {
      return this.userInfo.imageBase64;
    },
    fullName(): string {
      const { firstName, lastName } = this.userInfo;

      return firstName && lastName ? `${lastName} ${firstName}` : '';
    },
    userID(): string {
      return this.userInfo.userID;
    },
  },
  actions: {
    setToken(token: string, isRememberMe: boolean) {
      this.token = token ?? '';

      if (this.userInfo.loginFirstTimeFlag) return;

      const storage = isRememberMe ? 'localStorage' : 'sessionStorage';
      removeToken();
      setToken(storage, token);
    },
    setUserInfo(userInfo: THrmsUser) {
      this.userInfo = { ...userInfo };
    },

    async login(formData: TLoginRequest) {
      const { hrmsUser, token } = await UserService.login(formData);

      this.setUserInfo(hrmsUser);
      this.setToken(token, formData.isRememberMe);

      return hrmsUser;
    },

    async logout() {
      removeToken();
      router.push('/login');
      setTimeout(() => location.reload(), 0);
    },

    isMyID(userID?: string): boolean {
      return this.userInfo.userID === userID;
    },
  },
});

// Need to be used outside the setup
export function useUserStoreWithOut() {
  return useUserStore(store);
}
