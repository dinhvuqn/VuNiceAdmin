<script setup lang="ts">
  const { t } = useI18n();
  const router = useRouter();

  const breadcrumb = computed(() =>
    router.currentRoute.value.matched.concat().map(({ meta, path }) => ({
      name: t((meta.breadcrumb || meta.title) as string),
      path: path.includes(':') ? '' : path,
    })),
  );

  const pageName = computed(() => breadcrumb.value[breadcrumb.value.length - 1].name);

  defineEmits(['submit', 'close']);
</script>

<template>
  <a-card class="top-content !border-b-0 !border-t-0 shadow">
    <div class="flex justify-between items-center flex-wrap gap-y-6 md:gap-0">
      <a-space direction="vertical">
        <div class="top-content__title">{{ pageName }}</div>
        <div>
          <a-breadcrumb>
            <a-breadcrumb-item v-for="({ name, path }, index) in breadcrumb" :key="index">
              <router-link :to="path">{{ name }}</router-link>
            </a-breadcrumb-item>
          </a-breadcrumb>
        </div>
      </a-space>
      <div>
        <slot></slot>
      </div>
    </div>
  </a-card>
</template>

<style lang="scss" scoped>
  .top-content {
    &__title {
      font-size: 24px;
      text-transform: uppercase;
      color: #393e46;
    }
  }
  .ant-breadcrumb a {
    &:focus-within {
      color: #1890ff;
    }
  }
</style>
