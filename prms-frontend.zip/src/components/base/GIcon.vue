<script setup lang="ts">
  import {
    CalendarOutlined,
    InfoCircleOutlined,
    QuestionCircleFilled,
    LogoutOutlined,
    CheckOutlined,
    CloseOutlined,
    MessageOutlined,
    DownloadOutlined,
    CheckCircleFilled,
    CloseCircleFilled,
    InfoCircleFilled,
    ExclamationCircleFilled,
    ReadFilled,
    ReconciliationFilled,
    MenuOutlined,
    WarningOutlined,
    EditOutlined,
    SaveOutlined,
    MinusCircleOutlined,
    ArrowRightOutlined,
    DeleteOutlined,
    ProfileFilled,
    HistoryOutlined,
    ContainerFilled,
    BarChartOutlined,
    DashboardFilled,
  } from '@ant-design/icons-vue';

  const props = defineProps<{ icon: TIcon }>();

  const componentIs = computed(() => {
    const objIcon = {
      'calendar-outlined': CalendarOutlined,
      'info-circle-outlined': InfoCircleOutlined,
      'question-circle-filled': QuestionCircleFilled,
      'logout-outlined': LogoutOutlined,
      'check-outlined': CheckOutlined,
      'close-outlined': CloseOutlined,
      'message-outlined': MessageOutlined,
      'download-outlined': DownloadOutlined,
      'check-circle-filled': CheckCircleFilled,
      'close-circle-filled': CloseCircleFilled,
      'info-circle-filled': InfoCircleFilled,
      'exclamation-circle-filled': ExclamationCircleFilled,
      'warning-outlined': WarningOutlined,
      'menu-outlined': MenuOutlined,
      'read-filled': ReadFilled,
      'reconciliation-filled': ReconciliationFilled,
      'edit-outlined': EditOutlined,
      'save-outlined': SaveOutlined,
      'minus-circle-outlined': MinusCircleOutlined,
      'arrow-right-outline': ArrowRightOutlined,
      'delete-outlined': DeleteOutlined,
      'profile-filled': ProfileFilled,
      'history-outlined': HistoryOutlined,
      'container-filled': ContainerFilled,
      'dashboard-filled': DashboardFilled,
      'bar-chart-outlined': BarChartOutlined,
    };

    return objIcon[props.icon] || CalendarOutlined;
  });
</script>

<template>
  <component :is="componentIs" />
</template>
