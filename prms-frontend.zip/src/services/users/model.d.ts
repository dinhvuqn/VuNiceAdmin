export type TLoginRequest = {
  account: string;
  password: string;
  isRememberMe: boolean;
};

export type THrmsUser = {
  account: string;
  email: string;
  firstName: string;
  joinDate: string;
  lastName: string;
  leftDate: string;
  imageBase64: string;
  loginFirstTimeFlag: boolean;
  tel: string;
  userID: string;
  roleCode?: number;
  gender: number | undefined;
  genderName: string;
  statusCode: number | undefined;
  statusName: string;
};

export type TLoginResponse = {
  token: string;
  hrmsUser: THrmsUser;
};

export type TPermissionResponse = {
  fullName: string;
  auths: string[];
  modules: string[];
  is_admin?: 0 | 1;
  firstName: string;
  lastName: string;
  hrmsUser: THrmsUser;
};

export type TSearch = {
  userIDs: number[] | undefined;
  statusFlag: number | undefined;
  pageSize: number;
  curentpage: number;
};
export type THrmsUserData = {
  userID: string | undefined;
  account: string | undefined;
  password: string | undefined;
  firstName: string | undefined;
  lastName: string | undefined;
  email: string | undefined;
  personalEmail: string | undefined;
  nationality: string | undefined;
  failCount: string | undefined;
  statusFlag: boolean | undefined;
  joinDate: string | undefined;
  leavingDate: string | undefined;
  birthDate: string | undefined;
  marriedStatusCode: string | undefined;
  addressCountry: string | undefined;
  addressProvince: string | undefined;
  addressDistrict: string | undefined;
  addressHamlet: string | undefined;
  addressOthers: string | undefined;
  tel: string | undefined;
  citizenId: string | undefined;
  citizenPlace: string | undefined;
  citizenTime: string | undefined;
  bankAccountNumber: string | undefined;
  socialInsuranceNumber: string | undefined;
  medicalExaminationPlace: string | undefined;
  taxNumber: string | undefined;
  roleCode: number | undefined;
  loginFirstTimeFlag: number | undefined;
  imageBase64: string | undefined;
  imageBase64Byte: string | undefined;
  gender: number | undefined;
  level: number | undefined;
  workingType: number | undefined;
  aptitude: string | undefined;
  leaveReason: string | undefined;
  createUserID: string | undefined;
  createDateTime: string | undefined;
  updateUserID: string | undefined;
  updateDateTime: string | undefined;
  oldUserID: string | undefined;
};
