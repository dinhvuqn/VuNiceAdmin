import { BaseService } from '@/services/base.service';

class DashboardService extends BaseService<any, any> {
  static _instance = new DashboardService();

  get enity() {
    return '/';
  }

  async test() {
    return await this.request.get({
      url: `${this.enity!}/demo`,
    });
  }
}

export default DashboardService._instance;
