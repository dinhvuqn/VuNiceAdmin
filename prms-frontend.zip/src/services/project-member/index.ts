import { BaseService } from '@/services/base.service';
import { TSearch, TList, TProjectMember } from './model';

type TRequest = {
  TSearch: TSearch;
};

type TResponse = {
  TList: TList;
  TDetail: { messageId: string; params: string[] };
};

class ProjectMemberService extends BaseService<TRequest, TResponse> {
  static _instance = new ProjectMemberService();

  get enity() {
    return '/project-member';
  }

}

export type { TSearch, TList, TProjectMember };
export default ProjectMemberService._instance;
