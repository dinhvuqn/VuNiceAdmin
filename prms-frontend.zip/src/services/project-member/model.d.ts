/**
 * Request type bellow
 */

export type TSearch = {
  userIDs: number[] | undefined;
  projectRole: number | undefined;
  pageSize: number;
  curentpage: number;
};

/**
 * Response type bellow
 */

export type TProjectMember = {
  projectId: number | undefined;
  userId: string | undefined;
  username: string;
  fullname: string;
  email: string;
  projectRole: number | undefined;
  createUserID?: string;
  createDateTime?: string;
  updateUserID?: string;
  updateDateTime?: string;
};

export type TList = {
  list: TProjectMember[];
  total: number;
};