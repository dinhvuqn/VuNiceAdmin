import { RouteRecordRaw } from 'vue-router';
import { roleEnum } from '@/enums/roleEnum';
import AppLayout from '@/layouts/AppLayout/index.vue';
import BlankLayout from '@/layouts/BlankLayout.vue';

declare module 'vue-router' {
  export interface RouteMeta {
    icon?: TIcon;
    title?: string;
    breadcrumb?: string;
    role?: roleEnum[];
    hidden?: boolean;
    externalLink?: string;
  }
}

export const accessRoutes: RouteRecordRaw[] = [
  {
    path: '/',
    name: 'app',
    component: AppLayout,
    redirect: '/project-list',
    meta: {
      title: 'menuTitle.leaveManagement',
      breadcrumb: 'menuTitle.home',
      icon: 'calendar-outlined',
    },
    children: [
      {
        path: '/project-list',
        component: BlankLayout,
        redirect: '/project-list/:projectId/member-list',
        meta: {
          title: 'menuTitle.projectList',
          icon: 'profile-filled',
        },
        children: [
          {
            path: '/project-list/:projectId/member-list',
            component: () => import('@/views/ProjectList/MemberList/index.vue'),
            name: 'memberList',
            meta: {
              title: 'menuTitle.memberList',
              icon: 'team-outlined',
            },
          }
        ]
      }
    ]
  }
];

const constantRoutes: RouteRecordRaw[] = [
  {
    path: '/login',
    component: () => import('@/views/login/index.vue'),
    name: 'login',
    meta: {
      title: 'label.login',
    },
  },
  ...accessRoutes,
  {
    path: '/:pathMatch(.*)',
    redirect: '/404',
  },
  {
    path: '/404',
    component: () => import('@/views/Dashboard/index.vue'),
    meta: {
      title: 'label.notFound',
    },
  },
  {
    path: '/403',
    component: () => import('@/views/403.vue'),
    meta: {
      title: 'label.accessDenied',
    },
  },
];

export default constantRoutes;
