export default {
  appTitle: 'Project Resource Management System',
  prms: 'Project Resource Management System',
  menuTitle: {
    home: 'Home',
    projectList: 'Project List',
    projectInformation: 'Project Information',
    dashboard: 'Dashboard',
    reports: 'Reports',
    memberList: 'Member List',
    resourceAllocation: 'Resource Allocation',
    projectReports: 'Project Reports',

  },
  message: {
    // Error message
    E0000: 'Unknow error!',
    E0040: 'Username or Password is incorrect',

    // Warning message
    W0001: 'Are you sure?',

    // Success message
    S0001: 'Your request has been successfully submitted',
  },
  label: {
    homePageBtn: 'HOME PAGE',
    cancel: 'Cancel',
    save: 'Save',
    clone: 'Clone',
    submit: 'Submit',
    edit: 'Edit',
    addNew: 'Add New',
    delete: 'Delete',
    selectOptions: 'Select options',
    action: 'Action',
    success: 'Success',
    error: 'Error',
    warning: 'Warning',
    info: 'Info',
    close: 'Close',
    search: 'Search',
    totalRecords: 'Total: {total} Records ',
    show: 'Show',
  },
  params: {
    create: 'create',
  },
};
