export default {
  appTitle: 'Quản Lý Dự Án',
  prms: 'Hệ thống Quản Lý Dự Án',
  menuTitle: {
    home: 'Trang chủ',
    projectList: 'Danh sách dự án',
    projectInformation: 'Thông tin dự án',
    dashboard: 'Bảng điều khiển',
    reports: 'Báo cáo',
    memberList: 'Danh sách thành viên',
    resourceAllocation: 'Phân bổ dự án',
    projectReports: 'Báo cáo',

  },
  message: {
    // Error message
    E0000: 'Đã có lỗi xảy ra',
    E0040: 'Tên tài khoản hoặc mật khẩu không đúng',
    // Warning message
    W0001: 'Xác nhận lại',

    // Success message
    S0001: 'Yêu cầu của bạn đã được gửi đi',
  },
  label: {
    homePageBtn: 'TRANG CHỦ',
    cancel: 'Hủy',
    save: 'Lưu',
    clone: 'Nhân bản',
    submit: 'Nộp',
    edit: 'Sửa',
    addNew: 'Thêm mới',
    delete: 'Xóa',
    selectOptions: 'Vui lòng chọn',
    action: 'Hành động',
    success: 'Thành công',
    error: 'Lỗi',
    warning: 'Chú ý',
    info: 'Thông tin',
    close: 'Đóng',
    search: 'Tìm kiếm',
    totalRecords: 'Tổng: {total} bản ghi',
    show: 'Hiển thị',
  },
  params: {
    create: 'tạo',
  },
};
