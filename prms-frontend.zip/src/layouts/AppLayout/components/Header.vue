<script setup lang="ts">
  import RightContent from './RightContent.vue';

  const props = defineProps<{ collapsed: boolean }>();
  const emit = defineEmits(['update:collapsed']);
</script>

<template>
  <a-layout-header class="flex !bg-[#1976d2] !px-5 w-full h-16 relative z-10 shadow-md">
    <div class="flex justify-between items-center h-full w-full">
      <div class="flex items-center text-white font-medium gap-4">
        <g-icon
          icon="menu-outlined"
          class="text-[17px]"
          @click="emit('update:collapsed', !props.collapsed)"
        />
        <span>{{ $t('prms') }}</span>
      </div>
      <div>
        <right-content />
      </div>
    </div>
  </a-layout-header>
</template>
