<script setup lang="ts">
  import { useUserStore } from '@/store/modules/user';
  import avatarSrc from '@/assets/images/avatar.png';

  const { t } = useI18n();
  const { fullName, avatar, logout } = useUserStore();
</script>

<i18n lang="ts">
{
  en: {
    welcome: 'Welcome',
    logout: 'Logout',
  },
  vi: {
    welcome: 'Chào mừng',
    logout: 'Đăng xuất',
  }
}
</i18n>

<template>
  <div class="right-content">
    <a-space size="middle" class="flex items-center">
      <div class="text-white">
        {{ t('welcome') }}
        <span class="font-medium">{{ fullName }}</span>
      </div>

      <div>
        <a-dropdown trigger="click">
          <a-avatar v-if="avatar" :src="avatar" :size="40" class="!flex cursor-pointer" />
          <img v-else :src="avatarSrc" alt="avatar" class="w-10 cursor-pointer" />

          <template #overlay>
            <a-menu class="mt-1 w-32">
              <a-menu-item @click="logout">
                <div class="flex items-center gap-2">
                  <g-icon icon="logout-outlined" class="text-lg" />
                  <span class="flex py-0.5 font-medium">{{ t('logout') }}</span>
                </div>
              </a-menu-item>
            </a-menu>
          </template>
        </a-dropdown>
      </div>
    </a-space>
  </div>
</template>
