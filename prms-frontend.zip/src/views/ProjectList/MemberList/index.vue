<script setup lang="ts">
  // import moment from 'moment';
  import SelectOptionEnum from '@/enums/selectOptionEnum';
  import { useSelectOptions } from '@/hooks/useSelectOption';
  import { createColumns } from './constant';
  import { cloneDeep } from 'lodash-es';
  import ProjectMemberService, { TSearch, TProjectMember } from '@/services/project-member';
  // import CloneAnnualHolidayModal from './CloneAnnualHolidayModal.vue';
  import { Ref } from 'vue';
  import { useNotification } from '@/hooks/useNotification';
  // import { formatToDate, getFirstWorkDateOfYear } from '@/utils/dateUtil';
  import { useUserStore } from '@/store/modules/user';

  const { t } = useI18n();
  const router = useRouter();
  const { fullName, userID: myID } = useUserStore();
  const setIsLoading = inject<Fn<boolean>>('setIsLoading')!;
  const showConfirmModal = inject<Fn<TConfirmConfig>>('showConfirmModal')!;
  const { createNotification } = useNotification();
  type TNewTProjectMember = TProjectMember & { isNew?: boolean };
  type TState = {
    formSearch: TSearch;
    loading: boolean;
    originalProjectMemberList: TProjectMember[];
    projectMemberList: TNewTProjectMember[];
    total: number;
  };

  const initTProjectMember: TProjectMember = {
    projectId: undefined,
    userId: undefined,
    username: "",
    fullname: "",
    email: "",
    projectRole: undefined,
  };
  
  const initFormSearch: TSearch = {
    userIDs: undefined,
    projectRole: undefined,
    pageSize: 20,
    curentpage: 1,
  };

  const state = reactive<TState>({
    formSearch: { ...initFormSearch },
    loading: false,
    originalProjectMemberList: [],
    projectMemberList: [],
    total: 0,
  });
  
  const options = useSelectOptions([SelectOptionEnum.USER, SelectOptionEnum.PROJECT_ROLE]);
  // mock data
  options.value.projectRole = [{
    label: "PM",
    value: 1,
  }, {
    label: "PMO",
    value: 2,
  }]

  options.value.userOptions = [{
    label: "aaa",
  value: "bbb",
  role: 1,
  userInfo: {
    account: "",
    email: "",
    firstName: "",
    joinDate: "",
    lastName: "",
    leftDate: "",
    imageBase64: "",
    loginFirstTimeFlag: false,
    tel: "",
    userID: "",
    roleCode: undefined,
    gender: undefined,
    genderName: "",
    statusCode: undefined,
    statusName: "",
  },
  }]
  const getProjectMemberList = async (currentPage?: number) => {
    try {
      state.loading = true;
      state.formSearch.curentpage = currentPage || 1;

      // const { list, total } = await ProjectMemberService.getList(state.formSearch);
      // mock data
      state.originalProjectMemberList = [{
        projectId: 1,
        userId: '1',
        username: "adad",
        fullname: "ssada",
        email: "đa",
        projectRole: 1,
      }, {
        projectId: 1,
        userId: '2',
        username: "vvv",
        fullname: "ssbbada",
        email: "aaaa",
        projectRole: 1,
      }];
      state.total = 2;

      state.projectMemberList = cloneDeep(state.originalProjectMemberList);
    } finally {
      state.loading = false;
    }
  };

  // const InsertHoliday = async (index: number) => { 
  //   try {
  //     if (!validate(index)) return;

  //     setIsLoading(true);

  //     const hodidayData = state.annualHoliday[index];
  //     const method = hodidayData.holidayID ? 'update' : 'create';

  //     const { messageId, params } = await AnnualHolidayService[method](hodidayData);
  //     createNotification('success', t(`message.${messageId}`, [t(`params.${params}`)]));

  //     if (method === 'create') {
  //       fetchAnnualHoliday();
  //     } else {
  //       state.annualHoliday[index].isEditting = false;
  //       state.originalAnnualHoliday[index] = cloneDeep(state.annualHoliday[index]);
  //     }
  //   } finally {
  //     setIsLoading(false);
  //   }
  // };

  // const deleteHoliday = async (index: number) => {
  //   try {
  //     setIsLoading(true);

  //     const { messageId, params } = await AnnualHolidayService.remove(
  //       state.annualHoliday[index].holidayID!,
  //     );
  //     createNotification('success', t(`message.${messageId}`, [t(`params.${params}`)]));
  //     fetchAnnualHoliday();
  //   } finally {
  //     setIsLoading(false);
  //   }
  // };

  const firstInputRefs = ref<HTMLElement[]>([]);

  const disabledAddNewBtn = computed(
    () => state.projectMemberList.some(item => item.isNew),
  );

  const addNew = () => {
    // state.errors = {};

    const tProjectMember: TNewTProjectMember = { ...initTProjectMember, isNew: true };
    debugger
    state.projectMemberList.unshift(tProjectMember);
    state.originalProjectMemberList.unshift(tProjectMember);

    nextTick(() => {
      firstInputRefs.value[0].focus();
    });
  };

  // const edit = (index: number) => {
  //   state.annualHoliday[index].isEditting = true;

  //   nextTick(() => {
  //     firstInputRefs.value[index].value.focus();
  //   });
  // };

  // const handleDelete = (index: number) => {
  //   showConfirmModal({
  //     type: 'warning',
  //     subTitle: t('message.confirmDelete'),
  //     onOK: () => deleteHoliday(index),
  //   });
  // };

  onMounted(() => {
    getProjectMemberList();
  });
</script>

<i18n src="./locale" />

<template>
  <div>
    <g-top-content>
      <a-space>
        <g-button :disabled="disabledAddNewBtn" type="secondary" @click="addNew">
          {{ t('label.addNew') }}
        </g-button>
        <g-button type="secondary">
          {{ t('label.save') }}
        </g-button>
      </a-space>
    </g-top-content>
    <transition name="fade-slide" mode="out-in" appear>
      <div class="my-report-page m-4">
        <div class="bg-white mb-4 p-4 rounded shadow-md">
          <a-form
            :model="state.formSearch"
            class="grid md:grid-cols-4 sm:grid-cols-2 gap-x-4"
            @finish="getProjectMemberList()"
          >
            <!--userId -->
            <a-form-item name="userIDs" class="ant-form-item--column" :label="t('label.search_username')">
              <a-select
                v-model:value="state.formSearch.userIDs"
                mode="multiple"
                max-tag-count="responsive"
                option-filter-prop="label"
                :placeholder="t('label.selectOptions')"
                :options="options.userOptions"
                :allow-clear="true"
              />
            </a-form-item>
            <!--project role -->
            <a-form-item name="projectRole" class="ant-form-item--column" :label="t('label.search_role')">
              <a-select
                v-model:value="state.formSearch.projectRole"
                show-search
                :placeholder="t('label.selectOptions')"
                :options="options.projectRole"
                option-filter-prop="label"
                :allow-clear="true"
              />
            </a-form-item>
            <div class="md:col-start-4 sm:col-start-2 flex justify-end items-center">
              <g-button type="primary" html-type="submit" class="w-24">
                {{ t('label.search') }}
              </g-button>
            </div>
          </a-form>
        </div>
        <div class="bg-white rounded shadow-md p-4">
          <g-table
            v-model:currentPage="state.formSearch.curentpage"
            v-model:pageSize="state.formSearch.pageSize"
            class="table--header-center"
            :data-source="state.projectMemberList"
            :columns="createColumns(t)"
            :loading="state.loading"
            :total="state.total"
            @pagination="getProjectMemberList"
            @refresh-list="getProjectMemberList(state.formSearch.curentpage)"
          >
            <!-- <template #holidayDate="{ record, text, index }">
              <a-form-item
                class="!mb-0"
                :class="{
                  'ant-form-item-has-error':
                    state.errors[record.holidayID || 'create']?.holidayDate,
                }"
              >
                <g-date-picker
                  v-if="record.isEditting"
                  v-model:value="record.holidayDate"
                  :ref="(el: Ref<TPickerEvent>) => (firstInputRefs[index] = el)"
                  :disabled-date-range="{
                    min: moment(state.searchParams.year).startOf('year'),
                    max: moment(state.searchParams.year).endOf('year'),
                  }"
                  @change="validateFiled(index, 'holidayDate')"
                />
                <div v-else>{{ text }}</div>
              </a-form-item>
            </template>

            <template #holidayName="{ text, record, index }">
              <a-form-item
                class="!mb-0"
                :class="{
                  'ant-form-item-has-error':
                    state.errors[record.holidayID || 'create']?.holidayName,
                }"
              >
                <a-input
                  v-if="record.isEditting"
                  v-model:value="record.holidayName"
                  @keyup.esc="cancelEdit(index)"
                  @change="validateFiled(index, 'holidayName')"
                />
                <div v-else>{{ text }}</div>
              </a-form-item>
            </template>

            <template #foreignName="{ text, record, index }">
              <a-input
                v-if="record.isEditting"
                v-model:value="record.holidayForeignName"
                @keyup.esc="cancelEdit(index)"
              />
              <div v-else>{{ text }}</div>
            </template> -->

            <template #no="{ index }">
              {{ index + 1 + state.formSearch.pageSize * (state.formSearch.curentpage - 1) }}
            </template>
            <template #username="{ record, text }">
              <a-form-item
                class="!mb-0"
              >
                <a-select
                  v-if="record.isNew"
                  v-model:value="record.username"
                  show-search
                  option-filter-prop="label"
                  :ref="(el: HTMLElement) => firstInputRefs[0] = el"
                  :placeholder="$t('label.selectOptions')"
                  :options="options.userOptions"
                />
                <div v-else class="text-left">{{ text }}</div>
              </a-form-item>
            </template>
            <template #role="{ record, index }">
              <a-form-item class="ant-form-item--column">
              <a-select
                v-model:value="record.projectRole"
                :default-value="1"
                :options="options.projectRole"
                :ref="(el: HTMLElement) => {
                  if (!record.isNew) {
                    firstInputRefs[index] = el
                  }
                }"
              />
            </a-form-item>
            </template>
            <template #action="{ index, record }">
              <a-space size="large" style="gap: 10px">
                <template v-if="!record.isNew">
                  <a-tooltip v-if="!record.isNew" :title="t('label.delete')">
                    <g-button>
                      <template #icon>
                        <g-icon icon="delete-outlined" class="text-xl !text-red-600" />
                      </template>
                    </g-button>
                  </a-tooltip>
                </template>

                <template v-else>
                  <a-tooltip :title="t('label.save')">
                    <g-button>
                      <template #icon>
                        <g-icon icon="save-outlined" class="text-lg !text-emerald-700" />
                      </template>
                    </g-button>
                  </a-tooltip>
                  <a-tooltip :title="t('label.cancel')">
                    <g-button>
                      <template #icon>
                        <g-icon icon="minus-circle-outlined" class="text-lg !text-red-700" />
                      </template>
                    </g-button>
                  </a-tooltip>
                </template>
              </a-space>
            </template>
          </g-table>
        </div>
      </div>
    </transition>
  </div>
</template>
