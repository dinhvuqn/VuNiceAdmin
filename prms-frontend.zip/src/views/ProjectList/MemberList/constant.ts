import type { ColumnProps } from 'ant-design-vue/es/table/Column';

export const createColumns = (t: Fn<string>): ColumnProps[] => [
  {
    title: t('label.column_no'),
    dataIndex: 'no',
    key: 'no',
    slots: {
      customRender: 'no',
    },
    align: 'center',
    width: 60,
  },
  {
    title: t('label.column_username'),
    dataIndex: 'username',
    key: 'username',
    width: 150,
    slots: {
      customRender: 'username',
    },
  },
  {
    title: t('label.column_fullname'),
    dataIndex: 'fullname',
    key: 'fullname',
    slots: {
      customRender: 'fullname',
    },
    width: 200,
  },
  {
    title: t('label.column_email'),
    dataIndex: 'email',
    key: 'email',
    width: 250,
  },
  {
    title: t('label.column_role'),
    dataIndex: 'role',
    key: 'role',
    width: 120,
    slots: {
      customRender: 'role',
    },
  },
  {
    title: t('label.action'),
    dataIndex: 'action',
    key: 'action',
    width: 90,
    align: 'center',
    slots: {
      customRender: 'action',
    },
  },
];
