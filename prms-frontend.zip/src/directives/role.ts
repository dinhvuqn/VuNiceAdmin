/**
 * Global authority directive
 * @Example v-role="[HR,ADMIN,...]"
 */

import type { App, Directive, DirectiveBinding } from 'vue';
import { usePermissionStoreWithOut } from '@/store/modules/permission';

const permissionStore = usePermissionStoreWithOut();

const mounted = (el: HTMLElement, { value }: DirectiveBinding) => {
  if (value && !value.includes(permissionStore.role)) {
    el.remove();
  }
};

const roleDirective: Directive = {
  mounted,
};

export function setupRoleDirective(app: App) {
  app.directive('role', roleDirective);
}

export default roleDirective;
