import { RuleObject } from 'ant-design-vue/es/form';

export type TFormRules = { [k: string]: RuleObject | RuleObject[] };
