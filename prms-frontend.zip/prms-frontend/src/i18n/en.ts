export default {
  appTitle: 'Project Management System',
  tms: 'Project Management System',
  menuTitle: {
    home: 'Home',
  },
  message: {
    // Error message
    E0000: 'Unknow error!',

    // Warning message
    W0001: 'Are you sure?',

    // Success message
    S0001: 'Your request has been successfully submitted',
  },
  label: {
    homePageBtn: 'HOME PAGE',
  },
  params: {
    create: 'create',
  },
};
