export default {
  appTitle: 'Quản Lý Nghỉ Vắng',
  tms: 'Hệ thống quản lý nghỉ vắng',
  menuTitle: {
    home: 'Trang chủ',
  },
  message: {
    // Error message
    E0000: 'Đã có lỗi xảy ra',
    // Warning message
    W0001: 'Xác nhận lại',

    // Success message
    S0001: 'Yêu cầu của bạn đã được gửi đi',
  },
  label: {
    homePageBtn: 'TRANG CHỦ',
  },
  params: {
    create: 'tạo',
  },
};
