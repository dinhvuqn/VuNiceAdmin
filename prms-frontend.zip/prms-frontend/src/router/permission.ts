import { router } from '.';
import { getToken } from '@/utils/auth';
import { usePermissionStoreWithOut } from '@/store/modules/permission';

const permissioStore = usePermissionStoreWithOut();
const loginPath = '/login';
const whiteList = [loginPath, '/change-password', '/404', '/403'];

router.beforeEach(async (to, _, next) => {
  const hasToken = getToken();
  const toRouteRoles = to.meta.role as number[];
  const toRouteHidden = to.meta.hidden && !to.meta.menuHighlight;

  if (hasToken) {
    if (to.path === loginPath) {
      next({ path: '/' });
    }

    if (!toRouteHidden && !permissioStore.isUserInfoReady) {
      await permissioStore.getPermission();
    }

    if (toRouteHidden) {
      next({ path: '/404', replace: true });
    }

    if (toRouteRoles && !toRouteRoles?.includes(permissioStore.role)) {
      next({ path: '/403', replace: true });
    }

    next();
    return;
  }

  if (whiteList.indexOf(to.path) !== -1) {
    next();
  }

  next({ path: '/login', query: { path: to.fullPath } });
});
