enum SelectOptionEnum {
  USER_ROLE = 'userRole',
  USER = 'user',
  COUNTRY = 'country',
}

export default SelectOptionEnum;
