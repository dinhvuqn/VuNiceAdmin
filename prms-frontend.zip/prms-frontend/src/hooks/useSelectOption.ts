import { TTmsUser } from '@/services/users/model.d';
import SelectOptionEnum from '@/enums/selectOptionEnum';
import { BaseService } from '@/services/base.service';
import { pull } from 'lodash-es';

export type IUserOptions = {
  label: string;
  value: string;
  role: number;
  userInfo: TTmsUser;
};

type TOptionsResponse = Indexable<IOptions> & {
  userOptions: IUserOptions[];
};

export function useSelectOptions(optionNames: SelectOptionEnum[]) {
  const { locale } = useI18n();

  const initOptions = optionNames.reduce((response, optionName) => {
    return {
      ...response,
      [optionName]: [],
    };
  }, {});

  const optionsResponse = ref<TOptionsResponse>({
    userOptions: [],
    ...initOptions,
  });

  const getSelectOptions = async () => {
    const service = new BaseService();

    const iterable = optionNames.includes(SelectOptionEnum.USER)
      ? [
          service.getSelectOptions(pull([...optionNames], SelectOptionEnum.USER)),
          service.getUserOptions(),
        ]
      : [service.getSelectOptions(optionNames)];

    const [selectOptions, userOptions] = await Promise.all<any>(iterable);

    selectOptions.userOptions = userOptions || [];
    optionsResponse.value = selectOptions;
  };

  watch(() => locale.value, getSelectOptions, { immediate: true });

  return optionsResponse;
}
