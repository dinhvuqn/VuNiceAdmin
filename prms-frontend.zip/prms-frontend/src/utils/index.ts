import type { RouteLocationNormalized, RouteRecordNormalized } from 'vue-router';
import type { App, Plugin } from 'vue';

import { unref } from 'vue';
import { isEmpty, isObject } from '@/utils/is';
import { omitBy, isNil, keyBy, cloneDeep, isEqual } from 'lodash-es';
import { StatusEnum } from '@/enums/statusEnum';

/**
 * @description:  Set ui mount node
 */
export function getPopupContainer(node?: HTMLElement): HTMLElement {
  return (node?.parentNode as HTMLElement) ?? document.body;
}

/**
 * Add the object as a parameter to the URL
 *  + let obj = {a: '3', b: '4'}
 *  + setObjToUrlParams('www.baidu.com', obj)
 *  + ==>www.baidu.com?a=3&b=4
 * @param baseUrl url
 * @param obj
 * @returns {string}
 */
export function setObjToUrlParams(baseUrl: string, obj: any): string {
  let parameters = '';
  for (const key in obj) {
    parameters += key + '=' + encodeURIComponent(obj[key]) + '&';
  }
  parameters = parameters.replace(/&$/, '');
  return /\?$/.test(baseUrl) ? baseUrl + parameters : baseUrl.replace(/\/?$/, '?') + parameters;
}

export function deepMerge<T = any>(src: any = {}, target: any = {}): T {
  let key: string;
  for (key in target) {
    src[key] = isObject(src[key]) ? deepMerge(src[key], target[key]) : (src[key] = target[key]);
  }
  return src;
}

export function openWindow(
  url: string,
  opt?: { target?: TargetContext | string; noopener?: boolean; noreferrer?: boolean },
) {
  const { target = '__blank', noopener = true, noreferrer = true } = opt || {};
  const feature: string[] = [];

  noopener && feature.push('noopener=yes');
  noreferrer && feature.push('noreferrer=yes');

  window.open(url, target, feature.join(','));
}

// dynamic use hook props
export function getDynamicProps<T, U>(props: T): Partial<U> {
  const ret: Recordable = {};

  Object.keys(props).map((key) => {
    ret[key] = unref((props as Recordable)[key]);
  });

  return ret as Partial<U>;
}

export function getRawRoute(route: RouteLocationNormalized): RouteLocationNormalized {
  if (!route) return route;
  const { matched, ...opt } = route;
  return {
    ...opt,
    matched: (matched
      ? matched.map((item) => ({
          meta: item.meta,
          name: item.name,
          path: item.path,
        }))
      : undefined) as RouteRecordNormalized[],
  };
}

export const withInstall = <T>(component: T, alias?: string) => {
  const comp = component as any;
  comp.install = (app: App) => {
    app.component(comp.name || comp.displayName, component);
    if (alias) {
      app.config.globalProperties[alias] = component;
    }
  };
  return component as T & Plugin;
};

/**
 * Remove key with empty value from object
 * + let obj = { a: '3', b: '4', c: 0, d: '0', e: '', f: false, g: undefined, h: null, i: [], k: {} }
 * + removeEmptyValues(obj)
 * + ==> { a: '3', b: '4', c: 0, d: '0' }
 * @param formData object T
 * @returns object Partial(T)
 */
export const removeEmptyValues = <T extends Object>(formData: T) => {
  return omitBy(formData, (k) => isEmpty(k) || isNil(k));
};

/**
 * Get color by status value
 * + let status = StatusEnum.SUBMITTED
 * + getColorByStatus(status) ==> 'cyan'
 * @param status StatusEnum - status value
 * @returns string - color by status
 */
export const getColorByStatus = (status: StatusEnum) => {
  const statusColor = {
    [StatusEnum.STATUS_1]: 'cyan',
    [StatusEnum.STATUS_2]: 'green',
  };

  return statusColor[status] || '';
};

/**
 * Get color by status value
 * + let options = [{ value: 1, label: 'All' }, { value: 2, label: 'Submitted' }]
 * + mappingOptionArrayToObject(options) ==> { 1: 'All' }, { 2: 'Submitted' }
 * @param options IOptions - array option - { value, label }[]
 * @returns object from array key by 'value' - { [value]: label }
 */
export const mappingOptionArrayToObject = (options: IOptions) => {
  return keyBy(options, 'value');
};

/**
 * Get the size of file in KB
 * + getFileSizeKB(file)
 * @param file string | File
 * @param fileName string
 * @returns string size of file format '{size} KB'
 */
export const getFileSizeKB = (file: string | File) => {
  const { size } = new File([file], '');

  return `${(size / 1000).toFixed(3)} KB`;
};

/**
 * @param firstName string
 * @param lastName string
 * @param acount string | undefind
 * @returns firstName + lastName || firstName + lastName (acount)
 */
export const displayName = (firstName: string, lastName: string, acount?: string) => {
  return acount ? `${lastName} ${firstName} (${acount})` : `${lastName} ${firstName}`;
};

/**
 * @param queryItem undefined | string | string[]
 * @param toNumber boolean
 * @returns undefined | number[] | string[]
 */
export const formatQueryToArray = (queryItem?: string | string[], toNumber = true) => {
  if (!queryItem) return queryItem;

  const format = (value) => (toNumber ? +value : value);

  return typeof queryItem === 'string'
    ? [format(queryItem)]
    : queryItem.map((value) => format(value));
};

/**
 * Check equal two object
 * @param value
 * @param other
 * @returns boolean
 */
export const isEqualCustom = (value: any, other: any) => {
  const formatData = (originData: any) => {
    const formattedData = cloneDeep(originData);

    Object.keys(formattedData).forEach((key) => {
      if ([undefined, null, ''].includes(formattedData[key])) {
        formattedData[key] = undefined;
      }
    });

    return formattedData;
  };

  return isEqual(formatData(value), formatData(other));
};
