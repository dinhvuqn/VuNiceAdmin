import { defineStore } from 'pinia';
import { useUserStoreWithOut } from '@/store/modules/user';
import { roleEnum } from '@/enums/roleEnum';
import UserService from '@/services/users';
import { store } from '@/store';

const userStore = useUserStoreWithOut();

export const usePermissionStore = defineStore({
  id: 'app-permission',
  state: () => ({
    isUserInfoReady: false,
    role: roleEnum.STAFF,
  }),
  getters: {
    isStaff(): boolean {
      return this.role === roleEnum.STAFF;
    },
    isPM(): boolean {
      return this.role === roleEnum.PM;
    },
    isDirector(): boolean {
      return this.role === roleEnum.DIRETOR;
    },
  },
  actions: {
    async getPermission() {
      const { tmsUser } = await UserService.permission();

      this.isUserInfoReady = true;
      this.role = tmsUser.roleCode!;
      userStore.setUserInfo(tmsUser);
    },
  },
});

// Need to be used outside the setup
export function usePermissionStoreWithOut() {
  return usePermissionStore(store);
}
