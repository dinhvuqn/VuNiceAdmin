<script setup lang="ts"></script>

<i18n src="./locale" />
<template>
  <g-top-content />
  <transition name="fade-slide" mode="out-in" appear>
    <div class="my-report-page overflow-auto">
      <div class="bg-white p-4 rounded shadow-md m-4">
        <h1>Hello Word</h1>
      </div>
    </div>
  </transition>
</template>
