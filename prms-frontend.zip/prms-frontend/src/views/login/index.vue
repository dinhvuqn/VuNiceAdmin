<script setup lang="ts">
  import { useLanguage } from '@/hooks/useLanguage';
  import LoginForm from './Form.vue';

  const { isVieLang, LanguageEnum } = useLanguage();
</script>

<template>
  <div class="login-container">
    <div class="login-content">
      <div class="flex justify-between items-center">
        <h2 class="title">{{ $t('appTitle') }}</h2>
        <a-switch
          v-model:checked="isVieLang"
          :checked-children="LanguageEnum.VI"
          :un-checked-children="LanguageEnum.EN"
        />
      </div>

      <login-form />
    </div>
  </div>
</template>

<style lang="scss" scoped>
  .login-container {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100vw;
    height: 100vh;
    background-image: linear-gradient(to right, #74ebd5 0%, #9face6 100%);

    .login-content {
      width: 480px;
      padding: 30px 60px;
      border-radius: 10px;
      background-color: #fff;
      box-shadow: 0 3px 10px rgba(0, 0, 0, 0.4);

      .title {
        font-size: 22px;
        color: #000000;
        margin: 0;
      }
    }
  }
</style>
