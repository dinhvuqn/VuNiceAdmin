<script setup lang="ts">
  import { useUserStore } from '@/store/modules/user';
  import { TFormRules } from '@/types';

  const { t } = useI18n();
  const userStore = useUserStore();
  const router = useRouter();

  const state = reactive({
    formData: {
      account: '',
      password: '',
      isRememberMe: true,
    },
    btnLoading: false,
    hasError: false,
  });

  const formRef = ref();

  const rules = computed<TFormRules>(() => ({
    account: [{ required: true, trigger: 'blur', message: t('message.requireUsername') }],
    password: [{ required: true, trigger: 'blur', message: t('message.requirePassword') }],
  }));

  watch(rules, async () => {
    try {
      state.hasError = false;
      await formRef.value.clearValidate();
    } catch {}
  });

  const setIsLoading = inject<Fn<boolean>>('setIsLoading')!;

  const handleFinish = async () => {
    try {
      state.hasError = false;
      state.btnLoading = true;
      setIsLoading(true);

      const tmsUser = await userStore.login(state.formData);

      if (tmsUser.loginFirstTimeFlag) {
        return;
      }

      return router.push({
        name: 'dashboard',
      });
    } catch {
      state.hasError = true;
    } finally {
      state.btnLoading = false;
      setIsLoading(false);
    }
  };
</script>

<i18n lang="ts">
{
  en: {
    label: {
      username: 'Username',
      password: 'Password',
      rememberMe: 'Remember Me',
      login: 'Login',
    },
    placeholder: {
      username: 'SBIFPT Account',
      password: 'Password',
    },
    message: {
      requireUsername: 'Username is required',
      requirePassword: 'Password is required',
    }
  },
  vi: {
    label: {
      username: 'Tên tài khoản',
      password: 'Mật khẩu',
      rememberMe: 'Ghi nhớ',
      login: 'Đăng Nhập',
    },
    placeholder: {
      username: 'Tài khoản SBIFPT',
      password: 'Mật khẩu',
    },
    message: {
      requireUsername: 'Tên tài khoản là bắt buộc',
      requirePassword: 'Mật khẩu là bắt buộc',
    }
  }
}
</i18n>

<template>
  <div class="login-form">
    <a-form :model="state.formData" :rules="rules" @finish="handleFinish" ref="formRef">
      <p class="text">{{ t('label.username') }}</p>
      <a-form-item name="account">
        <a-input
          v-model:value="state.formData.account"
          class="custom-input"
          :placeholder="t('placeholder.username')"
        />
      </a-form-item>
      <p class="text">{{ t('label.password') }}</p>
      <a-form-item name="password">
        <a-input
          v-model:value="state.formData.password"
          type="password"
          class="custom-input"
          :placeholder="t('placeholder.password')"
        />
      </a-form-item>
      <div class="flex items-center justify-between mb-6">
        <a-checkbox v-model:checked="state.formData.isRememberMe" class="custom-checkbox">
          {{ t('label.rememberMe') }}
        </a-checkbox>
      </div>
      <transition name="fade-slide" mode="out-in">
        <div v-if="state.hasError" class="mb-6">
          <a-alert type="error" :message="t('message.E0040')" show-icon />
        </div>
      </transition>
      <a-form-item>
        <g-button :loading="state.btnLoading" html-type="submit" class="btn">
          {{ t('label.login') }}
        </g-button>
      </a-form-item>
    </a-form>
  </div>
</template>

<style lang="scss">
  .login-form {
    margin-top: 30px;
    --shadow-color: rgb(0 139 202 / 70%);

    .g-button.btn {
      width: 100%;
      height: 54px;
      font-size: 20px;
      border-radius: 6px;
      color: #fff;
      background: linear-gradient(90deg, #00c3fd 0%, #3662f4 100%);

      &:hover,
      &:focus-within {
        opacity: 0.85;
        box-shadow: 0 0 0 2px var(--shadow-color);
        border-color: white;
      }
    }

    .text {
      font-size: 14px;
      line-height: 20px;
      color: #999999;
      letter-spacing: 1.1px;
      margin-bottom: 10px;
    }

    .gray_text {
      font-size: 12px;
      color: #666666;
    }

    .custom-checkbox {
      outline: none;

      .ant-checkbox-inner {
        border-radius: 50%;
      }

      .ant-checkbox-checked:after {
        border: none;
      }

      & > span:last-child {
        font-size: 12px;
        color: #666666;
      }
    }

    .custom-input {
      height: 50px;
      line-height: 50px;
      border: 1px solid #707070;
      border-radius: 6px;
    }
  }
</style>
