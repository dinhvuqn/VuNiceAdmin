import { defineStore } from 'pinia';
import RegulationService from '@/services/regulation';
import { store } from '@/store';

const createObjectURL = (blobPart: BlobPart) => {
  return URL.createObjectURL(new Blob([blobPart], { type: 'application/pdf' }));
};

export const useRegulationStore = defineStore({
  id: 'app-regulation',
  state: () => ({
    useLeaveDaysFileURL: '',
    userManualFileURL: '',
  }),
  actions: {
    async getUseLeaveDays() {
      try {
        if (this.useLeaveDaysFileURL) return;

        const responseData = await RegulationService.useLeaveDays();

        this.useLeaveDaysFileURL = createObjectURL(responseData);
      } catch {}
    },

    async getUserManual() {
      try {
        if (this.userManualFileURL) return;

        const responseData = await RegulationService.userManual();

        this.userManualFileURL = createObjectURL(responseData);
      } catch {}
    },

    async uploadUseLeaveDays(event: ChangeEvent) {
      if (!event.target.files?.[0]) return;

      const formData = new FormData();
      formData.append('file', event.target.files[0]);

      await RegulationService.uploadUseLeaveDays(formData);

      this.useLeaveDaysFileURL = '';

      await this.getUseLeaveDays();
    },

    async uploadUserManual(event: ChangeEvent) {
      if (!event.target.files?.[0]) return;

      const formData = new FormData();
      formData.append('file', event.target.files[0]);

      await RegulationService.uploadUserManual(formData);

      this.userManualFileURL = '';

      await this.getUserManual();
    },
  },
});

// Need to be used outside the setup
export function useRegulationnStoreWithOut() {
  return useRegulationStore(store);
}
