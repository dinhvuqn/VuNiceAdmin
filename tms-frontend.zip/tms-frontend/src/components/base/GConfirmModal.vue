<script setup lang="ts">
  const props = defineProps<{ visible: boolean; confirmModalConfig: Required<TConfirmConfig> }>();

  const visible = computed({
    get() {
      return props.visible;
    },
    set(value) {
      emit('update:visible', value);
    },
  });

  const handleOk = () => {
    props.confirmModalConfig.onOK();
    visible.value = false;
  };

  const handleCancel = () => {
    props.confirmModalConfig.onCancel();
    visible.value = false;
  };

  const iconOption = computed(() => {
    const { icon, type } = props.confirmModalConfig;

    const colorObj = {
      info: '!text-sky-600',
      warning: '!text-amber-500',
    };

    const iconObj = {
      info: 'info-circle-outlined',
      warning: 'warning-outlined',
    };

    return {
      colorClassName: colorObj[type],
      icon: icon || iconObj[type],
    };
  });

  const emit = defineEmits(['update:visible']);
</script>

<template>
  <a-modal
    v-model:visible="visible"
    centered
    :width="confirmModalConfig.width || 'unset'"
    class="g-confirm-modal"
    :z-index="9999"
    :footer="false"
    :closable="false"
  >
    <div class="flex flex-col items-center">
      <g-icon :icon="iconOption.icon" class="text-6xl" :class="iconOption.colorClassName" />
      <div class="pb-3 pt-2">
        <h3 class="text-2xl m-0 mb-1 text-center">
          {{ confirmModalConfig.title ?? $t('message.W0001') }}
        </h3>
        <p class="whitespace-pre-line text-center mb-0">
          {{ confirmModalConfig.subTitle }}
        </p>
      </div>
      <a-space size="small" class="mt-1">
        <g-button class="w-20" @click="handleCancel">{{ $t('label.cancel') }}</g-button>
        <g-button type="primary" class="w-20" @click="handleOk">
          {{ $t('label.ok') }}
        </g-button>
      </a-space>
    </div>
  </a-modal>
</template>

<style lang="scss">
  .g-confirm-modal {
    min-width: 300px;
    max-width: 50%;

    .ant-modal-content {
      border-radius: 6px;
    }
  }
</style>
