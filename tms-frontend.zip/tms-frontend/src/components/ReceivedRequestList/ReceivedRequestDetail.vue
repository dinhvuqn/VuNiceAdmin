<script setup lang="ts">
  import ReceivedRequestService, { TReceivedRequest } from '@/services/received-request';
  import ViewRequestModal from '@/components/common/ViewRequestModal/index.vue';
  import {
    isActiveApprove,
    isActiveReject,
    isActiveConfirm,
    isActiveDelegate,
  } from '@/views/ReceivedRequestList/constant';
  import StatusCodes from 'http-status-codes';

  const router = useRouter();

  const props = defineProps<{ visible: boolean }>();

  const visible = computed({
    get() {
      return props.visible;
    },
    set(value) {
      emit('update:visible', value);
    },
  });

  const state = reactive({ receivedRequest: {} as TReceivedRequest });

  const getRequestDetail = async (requestID: string, subID: string) => {
    try {
      state.receivedRequest = await ReceivedRequestService.getByID(requestID, subID);
      visible.value = true;
    } catch (error: any) {
      if (error?.response?.data?.status === StatusCodes.FORBIDDEN) {
        router.replace({ path: '/403' });
      } else {
        router.replace({ path: '/404' });
      }
    }
  };

  watchEffect(() => {
    const { requestID, subID } = router.currentRoute.value.query;

    if (requestID && subID) {
      getRequestDetail(requestID as string, subID as string);
    }
  });

  const emit = defineEmits(['handle-action', 'update:visible']);
</script>

<template>
  <view-request-modal v-model:visible="visible" :request-detail="state.receivedRequest">
    <a-space>
      <g-button
        v-if="isActiveDelegate([state.receivedRequest])"
        type="secondary"
        class="w-24"
        @click="emit('handle-action', 'delegate', state.receivedRequest.requestID)"
      >
        {{ $t('label.delegate') }}
      </g-button>
      <g-button
        v-if="isActiveConfirm([state.receivedRequest])"
        type="success"
        class="w-24"
        @click="emit('handle-action', 'confirm', state.receivedRequest.requestID)"
      >
        {{ $t('label.confirm') }}
      </g-button>
      <g-button
        v-if="isActiveApprove([state.receivedRequest])"
        type="primary"
        class="w-24"
        @click="emit('handle-action', 'approve', state.receivedRequest.requestID)"
      >
        {{ $t('label.approve') }}
      </g-button>
      <g-button
        v-if="isActiveReject([state.receivedRequest])"
        type="warning"
        class="w-24"
        @click="emit('handle-action', 'reject', state.receivedRequest.requestID)"
      >
        {{ $t('label.reject') }}
      </g-button>
    </a-space>
  </view-request-modal>
</template>
