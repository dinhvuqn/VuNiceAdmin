<script setup lang="ts">
  import ReceivedRequestService, {
    TReceivedRequest,
    TActionType,
  } from '@/services/received-request';
  import {
    isActiveApprove,
    isActiveReject,
    isActiveConfirm,
    isActiveDelegate,
  } from '@/views/ReceivedRequestList/constant';

  const { t } = useI18n();

  const showConfirmModal = inject<Fn<TConfirmConfig>>('showConfirmModal')!;
  const setIsLoading = inject<Fn<boolean>>('setIsLoading')!;

  const props = defineProps<{
    delegateUserOptions: IOptions<string>;
    selectedRows: TReceivedRequest[];
    selectedRowKeys: string[];
  }>();

  type TState = {
    delegateTo: string | undefined;
    comment: string;
    visibleDelegateModal: boolean;
    delegateModalConfig: {
      visible: boolean;
      onOK: Fn;
    };
    commentModalConfig: {
      visible: boolean;
      title: string;
      requiredComment: boolean;
      onOK: Fn;
    };
  };

  const state = reactive<TState>({
    delegateTo: undefined,
    comment: '',
    visibleDelegateModal: false,
    delegateModalConfig: {
      visible: false,
      onOK: () => {},
    },
    commentModalConfig: {
      visible: false,
      title: t('label.comment'),
      requiredComment: true,
      onOK: () => {},
    },
  });

  const closeDelegateModal = () => {
    state.delegateTo = undefined;
    state.delegateModalConfig.visible = false;
  };

  const closeCommentModal = () => {
    state.commentModalConfig.visible = false;
    state.comment = '';
  };

  const handleAction = async (actionType: TActionType, requestIDList = props.selectedRowKeys) => {
    const formAction = {
      requestIDList,
      delegateTo: state.delegateTo,
      comment: state.comment,
    };

    try {
      setIsLoading(true);

      await ReceivedRequestService.action(actionType, formAction);
      closeDelegateModal();

      emit('refresh-list');
    } finally {
      closeCommentModal();
      setIsLoading(false);
    }
  };

  const handleConfirmModal = (actionType: TActionType, list = props.selectedRowKeys) => {
    showConfirmModal({
      title: t('message.W0002', { action: t(`label.${actionType}`).toLowerCase() }),
      onOK: () => handleAction(actionType, list),
    });
  };

  const handleCommentModal = (actionType: TActionType, list = props.selectedRowKeys) => {
    state.commentModalConfig.visible = true;
    state.commentModalConfig.title = t('message.W0003', {
      action: t(`label.${actionType}`).toLowerCase(),
    });
    state.commentModalConfig.requiredComment = actionType === 'reject';

    state.commentModalConfig.onOK = (comment: string) => {
      state.comment = comment;

      handleConfirmModal(actionType, list);
    };
  };

  const handleDeligate = (list = props.selectedRowKeys) => {
    state.delegateModalConfig.visible = true;

    state.delegateModalConfig.onOK = () => handleConfirmModal('delegate', list);
  };

  const emit = defineEmits(['refresh-list']);
  defineExpose({ handleCommentModal, handleDeligate });
</script>

<template>
  <g-top-content>
    <a-space>
      <g-button
        type="secondary"
        class="w-24"
        :disabled="!isActiveDelegate(props.selectedRows)"
        @click="handleDeligate(props.selectedRowKeys)"
      >
        {{ $t('label.delegate') }}
      </g-button>
      <g-button
        type="success"
        class="w-24"
        :disabled="!isActiveConfirm(props.selectedRows)"
        @click="handleCommentModal('confirm')"
      >
        {{ $t('label.confirm') }}
      </g-button>
      <g-button
        type="primary"
        class="w-24"
        :disabled="!isActiveApprove(props.selectedRows)"
        @click="handleCommentModal('approve')"
      >
        {{ $t('label.approve') }}
      </g-button>
      <g-button
        type="warning"
        class="w-24"
        :disabled="!isActiveReject(props.selectedRows)"
        @click="handleCommentModal('reject')"
      >
        {{ $t('label.reject') }}
      </g-button>
    </a-space>
  </g-top-content>
  <a-modal
    centered
    class="delegate-modal z-50"
    :title="$t('label.selectDelegate')"
    :visible="state.delegateModalConfig.visible"
    :closable="false"
  >
    <a-form>
      <a-form-item :label="$t('label.delegateTo')" class="required">
        <a-select
          v-model:value="state.delegateTo"
          show-search
          option-filter-prop="label"
          :placeholder="$t('label.select')"
          :options="delegateUserOptions"
        />
      </a-form-item>
    </a-form>
    <template #footer>
      <a-space size="small">
        <g-button
          type="primary"
          class="w-20"
          @click="state.delegateModalConfig.onOK"
          :disabled="!state.delegateTo"
        >
          {{ $t('label.delegate') }}
        </g-button>
        <g-button class="w-20" @click="closeDelegateModal">
          {{ $t('label.cancel') }}
        </g-button>
      </a-space>
    </template>
  </a-modal>
  <g-comment-modal
    v-model:visible="state.commentModalConfig.visible"
    :title="state.commentModalConfig.title"
    :required-comment="state.commentModalConfig.requiredComment"
    @ok="state.commentModalConfig.onOK"
    @cancel="closeCommentModal"
  />
</template>

<style lang="scss" scoped>
  :deep .ant-form-item-label {
    width: 100px;
  }
</style>
<style lang="scss">
  .delegate-modal {
    .ant-modal {
      &-header {
        padding: 16px;
      }

      &-body {
        padding: 24px 16px;
      }
    }
  }
</style>
