<script setup lang="ts">
  import MyRequestService, { TMyRequest } from '@/services/my-request';
  import ViewRequestModal from '@/components/common/ViewRequestModal/index.vue';
  import { StatusEnum } from '@/enums/statusEnum';
  import StatusCodes from 'http-status-codes';
  import { isActiveCancel } from '@/views/ReceivedRequestList/constant';

  const showConfirmModal = inject<Fn<TConfirmConfig>>('showConfirmModal')!;
  const router = useRouter();
  const { t } = useI18n();

  const props = defineProps<{ visible: boolean }>();

  const visible = computed({
    get() {
      return props.visible;
    },
    set(value) {
      emit('update:visible', value);
    },
  });

  const state = reactive({
    myRequest: {} as TMyRequest,
    comment: '',
    commentModalConfig: {
      visible: false,
      onOK: (() => {}) as Fn,
    },
  });

  const isShowEditBtn = computed(() => {
    const { requestStatusCode, confirmUsers } = state.myRequest;

    return (
      requestStatusCode === StatusEnum.SUBMITTED &&
      confirmUsers?.every(({ statusCode }) => statusCode === StatusEnum.SUBMITTED)
    );
  });

  const isShowCancelBtn = computed(() => {
    return isActiveCancel(state.myRequest);
  });

  const handleClickEditBtn = () => {
    const { requestID: id, subID } = state.myRequest;

    router.push({ name: 'editMyRequest', params: { id, subID } });
  };

  const handleClickCancelBtn = () => {
    state.commentModalConfig.visible = true;

    state.commentModalConfig.onOK = (comment: string) => {
      state.comment = comment;

      showConfirmModal({
        title: t('message.W0002', { action: t('label.cancel').toLowerCase() }),
        onOK: () => handleCancelRequest(),
      });
    };
  };

  const handleCancelRequest = async () => {
    try {
      const cancelData = {
        requestID: state.myRequest.requestID!,
        subID: state.myRequest.subID!,
        comment: state.comment,
      };

      await MyRequestService.cancel(cancelData);

      emit('refresh-list');
    } finally {
      closeCommentModal();
      router.push({ name: 'myRequest' });
      visible.value = false;
    }
  };

  const closeCommentModal = () => {
    state.comment = '';
    state.commentModalConfig.visible = false;
  };

  const getRequestDetail = async (requestID: string, subID: string) => {
    try {
      state.myRequest = await MyRequestService.getByID(requestID, subID);
      visible.value = true;
    } catch (error: any) {
      if (error?.response?.data?.status === StatusCodes.FORBIDDEN) {
        router.replace({ path: '/403' });
      } else {
        router.replace({ path: '/404' });
      }
    }
  };

  watchEffect(() => {
    const { requestID, subID } = router.currentRoute.value.query;

    if (requestID && subID) {
      getRequestDetail(requestID as string, subID as string);
    }
  });

  const emit = defineEmits(['update:visible', 'refresh-list']);
</script>

<template>
  <view-request-modal v-model:visible="visible" :request-detail="state.myRequest">
    <a-space>
      <g-button v-if="isShowEditBtn" type="secondary" class="w-24" @click="handleClickEditBtn">
        {{ t('label.edit') }}
      </g-button>
      <g-button v-if="isShowCancelBtn" type="danger" class="w-25" @click="handleClickCancelBtn">
        {{ t('label.cancelRequest') }}
      </g-button>
    </a-space>
  </view-request-modal>
  <g-comment-modal
    v-model:visible="state.commentModalConfig.visible"
    @ok="state.commentModalConfig.onOK"
    @cancel="closeCommentModal"
  />
</template>
