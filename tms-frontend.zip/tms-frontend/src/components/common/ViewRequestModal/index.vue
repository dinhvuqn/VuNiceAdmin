<script setup lang="ts">
  import { TMyRequest } from '@/services/my-request/model';
  import { TReceivedRequest } from '@/services/received-request/model';
  import { formatToDate } from '@/utils/dateUtil';
  import { displayName, getColorByStatus } from '@/utils';
  import { chunk, omit } from 'lodash-es';
  import { rows } from './constant';
  import { displayDuration } from '@/constants/displayDuration';
  import TimeOffRequestAndBalanceModal from '../TimeOffRequestAndBalanceModal/index.vue';
  import { useUserStore } from '@/store/modules/user';

  const { t } = useI18n();

  const router = useRouter();

  const { fullName, userID: myID } = useUserStore();

  type TRequestDetail = (TReceivedRequest | TMyRequest) & {
    requester: string;
    approver: string;
    creater: string;
    updater: string;
  };

  const props = defineProps<{
    requestDetail: TReceivedRequest | TMyRequest;
    visible: boolean;
    loading?: boolean;
  }>();

  const requestComments = computed(() => props.requestDetail.requestComments);

  const requestDetail = computed(() => {
    const { requestDetail } = props;

    return rows.reduce((itemDetail, { dataIndex, formatDate }) => {
      if (formatDate && itemDetail[dataIndex]) {
        itemDetail[dataIndex] = formatToDate(itemDetail[dataIndex], formatDate);
      }

      itemDetail.requester = `${itemDetail.requesterName} (${itemDetail.account})`;
      itemDetail.approver = `${itemDetail.approverName} (${itemDetail.approverAccount})`;
      itemDetail.creater = `${itemDetail.createUserName} (${itemDetail.createrAccount})`;
      itemDetail.updater = `${itemDetail.updateUserName} (${itemDetail.updaterAccount})`;

      return itemDetail;
    }, requestDetail as TRequestDetail);
  });

  const closeModal = () => {
    emit('update:visible', false);
    const { query } = router.currentRoute.value;

    router.push({ query: omit(query, ['requestID', 'subID']) });
  };

  const emit = defineEmits(['update:visible']);
</script>

<i18n src="./locale" />
<template>
  <a-modal
    centered
    class="icon-x-custom"
    :visible="props.visible"
    :width="1000"
    :z-index="20"
    :footer="false"
    @cancel="closeModal"
  >
    <div v-if="props.loading" class="flex items-center justify-center py-10">
      <a-spin />
    </div>
    <div v-else class="view-request">
      <div class="flex justify-between border-b border-b-gray-400 pb-4">
        <span class="text-gray-500 text-2xl">{{ t('pageName') }}</span>
        <div class="mr-6">
          <slot></slot>
        </div>
      </div>
      <div class="p-4 pb-0">
        <time-off-request-and-balance-modal
          v-if="requestDetail.userID === myID"
          :staff-i-d="myID"
          :full-name="fullName"
        />
        <div class="md:flex">
          <div v-for="(block, blockIndex) in chunk(rows, 9)" :key="blockIndex" class="md:w-1/2">
            <div
              v-for="{ key, dataIndex, slots } in block"
              :key="key"
              class="grid grid-cols-12 p-1"
            >
              <span class="font-semibold col-span-4">{{ t(`label.${key}`) }}</span>
              <span
                v-if="!slots"
                class="text-neutral-600 col-span-8 overflow-y-auto max-h-32 whitespace-pre-line"
              >
                {{ requestDetail[dataIndex] }}
              </span>
              <span v-if="slots === 'status'" class="col-span-8">
                <a-tag
                  :color="getColorByStatus(requestDetail.requestStatusCode)"
                  class="min-w-[90px]"
                >
                  {{ requestDetail.requestStatusName }}
                </a-tag>
              </span>
              <div v-if="slots === 'informTo'" class="col-span-8 overflow-y-auto max-h-32">
                <p
                  v-for="({ lastName, firstName, account }, index) in requestDetail[dataIndex]"
                  :key="index"
                  class="!mb-0"
                >
                  {{ displayName(firstName, lastName, account) }}
                </p>
              </div>
              <span
                v-if="slots === 'duration'"
                class="text-neutral-600 col-span-8 overflow-y-auto max-h-32 whitespace-pre-line"
              >
                {{ requestDetail[dataIndex]?.toFixed(1) }}
                {{ displayDuration(t, requestDetail[dataIndex], requestDetail.requestTypeCode) }}
              </span>
              <div v-if="slots === 'supervisor'" class="col-span-8 overflow-y-auto max-h-32">
                <div
                  v-for="(
                    { lastName, firstName, account, statusCode, statusName }, index
                  ) in requestDetail.confirmUsers"
                  :key="index"
                  class="flex"
                >
                  <p class="relative p-0 m-0 mr-2">
                    <span>
                      {{ displayName(firstName, lastName, account) }}
                    </span>
                    <span
                      :class="[
                        'custom-status',
                        `ant-tag-${getColorByStatus(statusCode)}`,
                        '!bg-white',
                      ]"
                    >
                      ( {{ statusName }} )
                    </span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="mt-5 mx-2" v-if="requestComments?.length > 0">
        <div class="overflow-y-auto max-h-40">
          <g-button
            disabled
            type="warning"
            class="!flex !items-center !cursor-default !text-white !border-amber-500 !bg-amber-500"
          >
            <template #icon>
              <g-icon icon="history-outlined" />
            </template>
            <span class="!m-1">{{ t('label.comment') }}</span>
          </g-button>
        </div>
        <div class="border-t pt-2 overflow-y-auto max-h-40">
          <div
            v-for="(commentInfo, index) in requestComments"
            :key="index"
            :class="{ 'mb-2': index !== requestComments.length - 1 }"
          >
            <div class="flex items-center">
              <h2 class="text-sky-500 font-semibold !mb-0 mr-2">
                {{ `${commentInfo.commentBy} (${commentInfo.account})` }}
              </h2>
              <span
                v-if="commentInfo.requestStatusCode"
                :class="[
                  'custom-status',
                  `ant-tag-${getColorByStatus(commentInfo.requestStatusCode)}`,
                  '!bg-white',
                ]"
              >
                ( {{ commentInfo.requestStatusName }} )
              </span>
              <p class="!m-0 text-xs">{{ ` (${commentInfo.commentAt})` }}</p>
            </div>
            <span class="text-neutral-600 whitespace-pre-line overflow-y-auto max-h-28">
              {{ commentInfo.comment }}
            </span>
          </div>
        </div>
      </div>
    </div>
  </a-modal>
</template>

<style lang="scss" scoped>
  .view-request {
    .custom-status {
      font-size: 11px;
      padding-right: 8px;
    }
  }
</style>
