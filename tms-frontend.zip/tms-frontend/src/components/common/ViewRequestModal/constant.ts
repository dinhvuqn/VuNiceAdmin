export const rows = [
  {
    key: 'requester',
    dataIndex: 'requester',
  },
  {
    key: 'requestType',
    dataIndex: 'requestTypeName',
  },
  {
    key: 'status',
    dataIndex: 'requestStatusName',
    slots: 'status',
  },
  {
    key: 'startDate',
    dataIndex: 'leaveFrom',
    formatDate: 'YYYY-MM-DD',
  },
  {
    key: 'endDate',
    dataIndex: 'leaveTo',
    formatDate: 'YYYY-MM-DD',
  },
  {
    key: 'partialDate',
    dataIndex: 'partialDayName',
  },
  {
    key: 'dayDuration',
    dataIndex: 'duration',
    slots: 'duration',
  },
  {
    key: 'reason',
    dataIndex: 'reasonName',
  },
  {
    key: 'detailReason',
    dataIndex: 'detailedReason',
  },
  {
    key: 'informTo',
    dataIndex: 'informUsers',
    slots: 'informTo',
  },
  {
    key: 'supervisor',
    dataIndex: 'confirmUsers',
    slots: 'supervisor',
  },
  {
    key: 'approver',
    dataIndex: 'approver',
  },
  {
    key: 'expectedApprove',
    dataIndex: 'expectedApproveDateTime',
    formatDate: 'YYYY-MM-DD HH:mm:ss',
  },
  {
    key: 'createdBy',
    dataIndex: 'creater',
  },
  {
    key: 'createdAt',
    dataIndex: 'createDateTime',
    formatDate: 'YYYY-MM-DD HH:mm:ss',
  },
  {
    key: 'lastModifyBy',
    dataIndex: 'updater',
  },
  {
    key: 'lastModifyAt',
    dataIndex: 'updateDateTime',
    formatDate: 'YYYY-MM-DD HH:mm:ss',
  },
];

export enum ScreenDetailEnum {
  MY_REQUEST = 'myRequest',
  RECEIVED_REQUEST_LIST = 'receivedRequestList',
}
