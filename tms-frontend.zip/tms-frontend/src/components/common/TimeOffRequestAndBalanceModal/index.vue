<script setup lang="ts">
  import { createColumns } from './constant';
  import MyTimeOffLeaveService, { TMyTimeOffLeave } from '@/services/my-time-off-leave';

  type TState = {
    myTimeOffLeaveList: TMyTimeOffLeave[];
    loading: boolean;
    visible: boolean;
  };

  const { t } = useI18n();

  const props = defineProps<{
    staffID: string;
    fullName: string;
    remainingQuotas?: String;
    displayRemain?: boolean;
    isvalidRemain?: boolean;
  }>();

  const state = reactive<TState>({
    myTimeOffLeaveList: [],
    loading: false,
    visible: false,
  });

  const currentYear = ref(new Date().getFullYear());

  const getMyTimeOffLeaveList = async () => {
    try {
      state.loading = true;

      state.myTimeOffLeaveList = await MyTimeOffLeaveService.getList({ staffID: props.staffID });
    } finally {
      state.loading = false;
    }
  };

  const showModalAndGetList = () => {
    state.visible = true;
    state.myTimeOffLeaveList = [];

    getMyTimeOffLeaveList();
  };
</script>

<i18n src="./locale" />
<template>
  <div style="display: flex">
    <div
      class="title-bold-blue mb-2 outline-none focus:border-transparent focus:text-sky-500 tab-link"
      tabindex="0"
      @keypress.enter="showModalAndGetList"
    >
      <g-icon icon="calendar-outlined" />
      <span class="leading-5" @click="showModalAndGetList">{{ t('pageName') }}</span>
    </div>
    <div style="margin-left: 10px; font-weight: 500" class="mb-2">
      <label v-if="props.displayRemain">
        {{ t('label.remainQuotas') }}
        <span class="color-text-blue" :class="{ 'color-text-red': !props.isvalidRemain }">
          {{ props.remainingQuotas }}
        </span>
      </label>
    </div>
  </div>
  <div class="time-off">
    <a-modal v-model:visible="state.visible" centered width="1200px" :footer="false">
      <div class="font-semibold text-lg mb-4 text-gray-500">
        {{ t('pageTitle', { year: currentYear }) }}
        <span class="text-blue-500">{{ props.fullName }}</span>
      </div>
      <g-table
        class="table--header-center"
        :data-source="state.myTimeOffLeaveList"
        :columns="createColumns(t)"
        :loading="state.loading"
        :pagination="false"
      >
        <template #requestName="{ text, record }">
          <a v-if="record.isDetail" class="flex items-center">
            <span class="mr-1">{{ text }}</span>
            <g-icon icon="question-circle-filled" />
          </a>
          <div v-else>{{ text }}</div>
        </template>
      </g-table>
    </a-modal>
  </div>
</template>
<style lang="scss" scoped>
  .tab-link:focus-visible {
    outline: -webkit-focus-ring-color auto 1px;
  }
  .color-text-red {
    color: red !important;
  }
  .color-text-blue {
    color: #108ee9;
  }
</style>
