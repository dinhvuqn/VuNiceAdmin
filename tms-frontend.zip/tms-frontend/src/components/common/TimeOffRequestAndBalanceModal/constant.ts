import type { ColumnProps } from 'ant-design-vue/es/table/Column';

export const createColumns = (t: Fn<string>): ColumnProps[] => [
  {
    title: t('label.requestType'),
    dataIndex: 'timeOffName',
    width: 600,
    key: 'requestName',
    slots: {
      customRender: 'requestName',
    },
  },
  {
    title: t('label.unit'),
    dataIndex: 'unitName',
    key: 'unit',
    width: 120,
  },
  {
    title: t('label.maximumAllowed'),
    dataIndex: 'maximumAllowed',
    key: 'maximumAllowed',
    width: 100,
    align: 'right',
  },
  {
    title: t('label.approvedQuotas'),
    dataIndex: 'approvedQuotas',
    key: 'approvedQuotas',
    width: 100,
    align: 'right',
  },
  {
    title: t('label.remainingQuotas'),
    dataIndex: 'remainingQuotas',
    key: 'remainingQuotas',
    width: 100,
    align: 'right',
  },
  {
    title: t('label.pendingQuotas'),
    dataIndex: 'pendingQuotas',
    key: 'pendingQuotas',
    width: 100,
    align: 'right',
  },
];
