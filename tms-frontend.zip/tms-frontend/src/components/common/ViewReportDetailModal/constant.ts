import type { ColumnProps } from 'ant-design-vue/es/table/Column';

export const createColumns = (t: Fn<string>): ColumnProps[] => [
  {
    title: t('label.no'),
    dataIndex: 'no',
    key: 'no',
    width: 30,
    slots: {
      customRender: 'no',
    },
    align: 'center',
  },
  {
    title: t('label.category'),
    width: 100,
    dataIndex: 'category',
    key: 'category',
  },
  {
    title: t('label.requestType'),
    dataIndex: 'requestTypeName',
    key: 'requestTypeName',
    width: 100,
  },
  {
    title: t('label.partialDay'),
    dataIndex: 'partialDayName',
    key: 'partialDayName',
    width: 70,
  },
  {
    title: t('label.duration'),
    dataIndex: 'duration',
    width: 50,
    key: 'duration',
    slots: {
      customRender: 'duration',
    },
  },
  {
    title: t('label.startDate'),
    dataIndex: 'leaveFrom',
    key: 'startDate',
    width: 60,
    slots: {
      customRender: 'startDate',
    },
  },
  {
    title: t('label.endDate'),
    dataIndex: 'leaveTo',
    width: 60,
    key: 'endDate',
    slots: {
      customRender: 'endDate',
    },
  },
];
