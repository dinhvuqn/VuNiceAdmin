<script setup lang="ts">
  import ReportDetailService, { TReportDetail } from '@/services/report-detail';
  import { formatToDate, formatToMonth } from '@/utils/dateUtil';
  import { displayName } from '@/utils';
  import { displayDuration } from '@/constants/displayDuration';
  import { createColumns } from './constant';

  const router = useRouter();

  const { t } = useI18n();

  defineProps<{ visible: boolean }>();

  const emit = defineEmits(['update:visible']);

  const state = reactive({
    reportDetail: {} as TReportDetail,
    loading: false,
  });

  const getReportDetail = async (query) => {
    try {
      state.loading = true;

      state.reportDetail = await ReportDetailService.getList(query);
      emit('update:visible', true);
    } finally {
      state.loading = false;
    }
  };

  watchEffect(() => {
    if (router.currentRoute.value.query.userID) {
      getReportDetail(router.currentRoute.value.query);
    }
  });

  const employeeAccount = computed(() => {
    const { firstName, lastName, account } = state.reportDetail;

    return displayName(firstName, lastName, account);
  });

  const closeModal = () => {
    emit('update:visible', false);
    router.push({ name: 'reportList' });
  };
</script>

<i18n src="./locale" />
<template>
  <a-modal centered width="1200px" :visible="visible" :footer="false" @cancel="closeModal">
    <div v-if="state.loading" class="flex items-center justify-center py-10">
      <a-spin />
    </div>
    <div v-else class="viewReport">
      <h3 class="font-bold text-xl">{{ t('pageName') }}</h3>
      <div class="py-6">
        <div class="md:w-3/4">
          <div class="flex">
            <div class="w-40">
              <p class="font-medium">{{ t('label.workingMonth') }}:</p>
            </div>
            <div class="flex">
              <p class="font-medium mr-4">{{ t('label.from') }}:</p>
              <p class="mr-10">{{ formatToMonth(state.reportDetail.workingMonthFrom) }}</p>
              <p class="font-medium mr-4">{{ t('label.to') }}:</p>
              <p>{{ formatToMonth(state.reportDetail.workingMonthTo) }}</p>
            </div>
          </div>
        </div>
        <div class="flex">
          <div class="w-40">
            <p class="font-medium mr-3">{{ t('label.employeeName') }}:</p>
          </div>
          <p>{{ employeeAccount }}</p>
        </div>
        <div class="flex">
          <div class="w-40">
            <p class="font-medium mr-3">{{ t('label.employeeID') }}:</p>
          </div>
          <p>{{ state.reportDetail.userID }}</p>
        </div>
        <div class="flex">
          <div class="w-40">
            <p class="font-medium mr-3">{{ $t('label.status') }}:</p>
          </div>
          <span>
            <a-tag color="blue">{{ $t('label.approved') }}</a-tag>
          </span>
        </div>
      </div>
      <g-table
        class="table--header-center"
        :columns="createColumns(t)"
        :pagination="false"
        :data-source="state.reportDetail.requestDetails"
      >
        <template #no="{ index }">
          {{ index + 1 }}
        </template>
        <template #duration="{ text }">
          <div class="text-right">{{ Number(text).toFixed(1) }} {{ displayDuration(t, text) }}</div>
        </template>
        <template #startDate="{ text }">{{ formatToDate(text) }}</template>
        <template #endDate="{ text }">{{ formatToDate(text) }}</template>
      </g-table>
    </div>
  </a-modal>
</template>
