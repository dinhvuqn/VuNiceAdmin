<script setup lang="ts">
  import { createColumns } from './constant';
  import ReportListService, { TSearch, TReportList } from '@/services/report-leave-off';
  import { formatToDateTime } from '@/utils/dateUtil';
  import { downloadExcelFile, getFileSizeKB } from '@/utils';
  import { cloneDeep } from 'lodash-es';
  import { useSelectOptions } from '@/hooks/useSelectOption';
  import SelectOptionEnum from '@/enums/selectOptionEnum';
  import moment from 'moment';
  import { ANNUAL_LEAVE } from '@/constants/requestTypes';

  const { t } = useI18n();
  const showConfirmModal = inject<Fn<TConfirmConfig>>('showConfirmModal')!;

  type TState = {
    myReportList: TReportList[];
    formSearch: TSearch;
    paramsSearch: TSearch;
    total: number;
    loading: boolean;
  };

  const initSearchParams = {
    year: moment().year().toString(),
    requestTypes: [ANNUAL_LEAVE],
    userIDs: undefined,
    pageSize: 20,
    curentpage: 1,
  };

  const state = reactive<TState>({
    myReportList: [],
    formSearch: cloneDeep(initSearchParams),
    paramsSearch: cloneDeep(initSearchParams),
    total: 0,
    loading: false,
  });

  const options = useSelectOptions([SelectOptionEnum.USER, SelectOptionEnum.REQUEST_TYPE]);

  const handleClickSearch = () => {
    state.paramsSearch = cloneDeep(state.formSearch);
    getReportList();
  };

  const getReportList = async (currentPage?: number) => {
    try {
      state.loading = true;
      state.formSearch.curentpage = currentPage || 1;
      state.paramsSearch.curentpage = currentPage || 1;

      const { list, total } = await ReportListService.getList(state.paramsSearch);
      state.myReportList = list;
      state.total = total;
    } finally {
      state.loading = false;
    }
  };

  const exportListReport = async () => {
    const { year, userIDs, requestTypes } = state.paramsSearch;

    const responseData = await ReportListService.exportExcel({
      year,
      requestTypes,
      userIDs,
    });

    const fileName =
      'TMS_Report_TimeOffBalance' + formatToDateTime(new Date(), 'YYYYMMDDHHmmss') + '.xlsx';

    showConfirmModal({
      title: t('message.W0004'),
      subTitle: `${fileName} (${getFileSizeKB(responseData)})`,
      icon: 'download-outlined',
      onOK: () => downloadExcelFile(responseData, fileName),
    });
  };
  getReportList();
</script>

<i18n src="./locale" />
<template>
  <g-top-content>
    <g-button type="warning" class="m-w-24" @click="exportListReport">
      {{ t('label.export') }}
    </g-button>
  </g-top-content>
  <transition name="fade-slide" mode="out-in" appear>
    <div class="my-report-page m-4">
      <div class="bg-white mb-4 p-4 rounded shadow-md">
        <a-form class="grid md:grid-cols-4 sm:grid-cols-2 gap-x-4" @finish="handleClickSearch">
          <a-form-item name="userIDs" class="ant-form-item--column" :label="t('label.staff')">
            <a-select
              v-model:value="state.formSearch.userIDs"
              mode="multiple"
              max-tag-count="responsive"
              option-filter-prop="label"
              :placeholder="$t('label.selectOptions')"
              :options="options.userOptions"
            />
          </a-form-item>
          <a-form-item
            name="requestTypeCode"
            class="ant-form-item--column"
            :label="$t('label.requestType')"
          >
            <a-select
              mode="multiple"
              max-tag-count="responsive"
              v-model:value="state.formSearch.requestTypes"
              show-search
              :placeholder="$t('label.select')"
              option-filter-prop="label"
              :options="options.requestType"
            />
          </a-form-item>
          <a-form-item name="year" class="ant-form-item--column" :label="t('label.year')">
            <g-date-picker
              v-model:value="state.formSearch.year"
              picker="year"
              :allow-clear="false"
            />
          </a-form-item>
          <div class="md:col-start-4 sm:col-start-2 flex justify-end items-center">
            <g-button type="primary" html-type="submit" class="w-24" @click="handleClickSearch">
              {{ $t('label.search') }}
            </g-button>
          </div>
        </a-form>
      </div>
      <div class="bg-white rounded shadow-md p-4">
        <g-table
          v-model:currentPage="state.formSearch.curentpage"
          v-model:pageSize="state.formSearch.pageSize"
          :columns="createColumns(t)"
          class="table--header-center"
          :data-source="state.myReportList"
          :loading="state.loading"
          :total="state.total"
          @pagination="getReportList"
          @refresh-list="getReportList(state.formSearch.curentpage)"
        >
          <template #no="{ index }">
            {{ index + 1 + state.formSearch.pageSize * (state.formSearch.curentpage - 1) }}
          </template>
          <template #employeeAccount="{ record: { account, userName } }">
            {{ `${userName} (${account}) ` }}
          </template>
        </g-table>
      </div>
    </div>
  </transition>
</template>
