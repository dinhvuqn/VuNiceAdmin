import type { ColumnProps } from 'ant-design-vue/es/table/Column';

export const createColumns = (t: Fn<string>): ColumnProps[] => [
  {
    title: t('label.no'),
    dataIndex: 'no',
    key: 'no',
    slots: {
      customRender: 'no',
    },
    align: 'center',
    width: 60,
  },
  {
    title: t('label.employeeID'),
    dataIndex: 'userID',
    key: 'userID',
    width: 100,
  },
  {
    title: t('label.employeeName'),
    dataIndex: 'employeeName',
    key: 'employeeName',
    width: 330,
  },
  {
    title: t('label.requestType'),
    dataIndex: 'displayName',
    key: 'displayName',
    width: 330,
  },
  {
    title: t('label.maximumAllowed'),
    dataIndex: 'maximumAllowed',
    key: 'maximumAllowed',
    align: 'right',
    width: 150,
  },
  {
    title: t('label.approvedQuotas'),
    dataIndex: 'approvedQuotas',
    key: 'approvedQuotas',
    align: 'right',
    width: 150,
  },
  {
    title: t('label.remainingQuotas'),
    dataIndex: 'remainingQuotas',
    key: 'remainingQuotas',
    align: 'right',
    width: 150,
  },
  {
    title: t('label.pendingQuotas'),
    dataIndex: 'pendingQuotas',
    key: 'pendingQuotas',
    align: 'right',
    width: 150,
  },
];
