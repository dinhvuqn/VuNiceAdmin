import type { FormProps } from 'ant-design-vue/es';
import moment from 'moment';
import { REQUEST_MONTH_TYPES } from '@/constants/requestTypes';

export type TEditRouter = {
  id: string;
  subID: string;
};

export const ALL_DAY_CODE = 10;
export const REASON_OTHER = 99;

export const duration = (
  t: Fn<string>,
  leaveFrom: string,
  leaveTo: string,
  partialDay = ALL_DAY_CODE,
  holidays: number,
  requestTypeCode: number | undefined,
) => {
  const from = moment(leaveFrom);
  const to = moment(leaveTo);

  const diffFromDays = to.diff(from, 'd') + 1;
  const diffSaturDayDays = to.diff(from.day(6), 'd');

  const dayOffs = diffFromDays - (Math.floor(diffSaturDayDays / 7) + 1) * 2;

  const partial = !partialDay || partialDay === ALL_DAY_CODE ? 1 : 0.5;
  const _duration = (dayOffs - holidays) * partial || 0;

  if (REQUEST_MONTH_TYPES.includes(requestTypeCode!)) {
    const fromDate = moment(leaveFrom, 'YYYY-MM-DD');
    let totalDayOff = 0;
    let duration_month = 0;
    while (totalDayOff < diffFromDays) {
      const dayOfMonthFromLeave = moment(fromDate).daysInMonth();
      fromDate.add(1, 'M');
      totalDayOff += dayOfMonthFromLeave;
      duration_month++;
    }

    return `${duration_month} ${duration_month === 1 ? t('label.month') : t('label.months')}`;
  }
  return `${_duration} ${_duration === 1 ? t('label.day') : t('label.days')}`;
};

export const initformData = {
  requestID: undefined,
  requestTypeCode: undefined,
  leaveFrom: '',
  leaveTo: '',
  partialDay: undefined,
  reasonCode: undefined,
  approverID: undefined,
  detailedReason: '',
  confirmUserIDs: undefined,
  informTo: undefined,
  expectedApproveDateTime: '',
  representedUserID: undefined,
  duration: undefined,
};

export const formRules: FormProps['rules'] = {
  requestTypeCode: [{ required: true, message: false }],
  leaveFrom: [{ required: true, message: false }],
  leaveTo: [{ required: true, message: false }],
  partialDay: [{ required: true, message: false }],
  reasonCode: [{ required: true, message: false }],
  approverID: [{ required: true, message: false }],
  confirmUserIDs: [{ required: true, message: false }],
};

export const displayRemain = (
  t: Fn<string>,
  valueRemain: number,
  requestTypeCode: number | undefined,
) => {
  if (REQUEST_MONTH_TYPES.includes(requestTypeCode!)) {
    return `${valueRemain} ${valueRemain === 1 ? t('label.month') : t('label.months')}`;
  }
  return `${valueRemain} ${valueRemain === 1 ? t('label.day') : t('label.days')}`;
};
