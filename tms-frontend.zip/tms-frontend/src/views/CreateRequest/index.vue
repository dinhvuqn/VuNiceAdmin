<script setup lang="ts">
  import SelectOptionEnum from '@/enums/selectOptionEnum';
  import MyRequestService, { TUpdate, TWorkingTime } from '@/services/my-request';
  import AnnualHolidayService from '@/services/annual-holiday';
  import TimeOffGenerateService from '@/services/request-type';
  import moment from 'moment';
  import {
    formRules,
    REASON_OTHER,
    initformData,
    duration,
    displayRemain,
    TEditRouter,
    ALL_DAY_CODE,
  } from './constant';
  import TimeOffRequestAndBalanceModal from '@/components/common/TimeOffRequestAndBalanceModal/index.vue';
  import { roleEnum } from '@/enums/roleEnum';
  import StatusCodes from 'http-status-codes';
  import { formatToDate, formatToDateTime } from '@/utils/dateUtil';
  import { cloneDeep, map, isEqual } from 'lodash-es';
  import { useUserStore } from '@/store/modules/user';
  import { useSelectOptions } from '@/hooks/useSelectOption';
  import MyTimeOffLeaveService, { TMyTimeOffLeave } from '@/services/my-time-off-leave';
  import {
    isLeaveOff,
    REQUEST_MONTH_TYPES,
    requestTypeAndReasonMap,
  } from '@/constants/requestTypes';

  const showConfirmModal = inject<Fn<TConfirmConfig>>('showConfirmModal')!;
  const { isMyID, userID: myID, fullName } = useUserStore();
  const { t } = useI18n();

  const router = useRouter();
  const paramsRouter = computed(() => router.currentRoute.value.params as TEditRouter);
  const isCreate = computed(() => !paramsRouter.value.id);
  let isEdit = !isCreate.value;

  const setIsLoading = inject<Fn<boolean>>('setIsLoading')!;

  type TState = {
    formData: TUpdate;
    rootEdit: TUpdate;
    isChangeFormData: boolean;
    holidays: number;
    myTimeOffLeaveList: TMyTimeOffLeave[];
    remainingQuotas: number;
    displayRemain: boolean;
    staffID: string;
    fullName: string;
    isvalidRemain: boolean;
    saveRequestTypeCode: number;
  };

  const state = reactive<TState>({
    formData: cloneDeep(initformData),
    rootEdit: cloneDeep(initformData),
    isChangeFormData: false,
    holidays: 0,
    myTimeOffLeaveList: [],
    remainingQuotas: 0,
    displayRemain: false,
    staffID: myID,
    fullName: fullName,
    isvalidRemain: true,
    saveRequestTypeCode: 0,
  });

  const options = useSelectOptions([
    SelectOptionEnum.USER,
    SelectOptionEnum.REQUEST_TYPE,
    SelectOptionEnum.REASON,
    SelectOptionEnum.PARTIAL_DAY,
  ]);

  const listReason = computed(() => {
    if (!state.formData.requestTypeCode) {
      return options.value.reason;
    }

    const reasonCodeByRequestTypes = requestTypeAndReasonMap[state.formData.requestTypeCode];

    if (!reasonCodeByRequestTypes.includes(state.formData.reasonCode)) {
      state.formData.reasonCode = undefined;
    }

    return options.value.reason.filter(({ value }) => reasonCodeByRequestTypes.includes(value));
  });

  const supervisor = computed(() =>
    options.value.userOptions.filter(
      (user) =>
        user.role === roleEnum.PM ||
        user.role === roleEnum.DIRETOR ||
        user.role === roleEnum.HR ||
        state.formData.confirmUserIDs?.includes(user.value),
    ),
  );

  const approver = computed(() =>
    options.value.userOptions.filter(
      ({ value, role }) =>
        (state.formData.representedUserID || !isMyID(value)) &&
        value !== state.formData.representedUserID &&
        [roleEnum.DIRETOR, roleEnum.HR].includes(role),
    ),
  );

  const representedUsers = computed(() =>
    options.value.userOptions.filter((user) => !isMyID(user.value)),
  );

  const createReqestForm = ref();

  const checkReasonOrder = computed(() => {
    createReqestForm.value?.clearValidate('detailedReason');

    return state.formData.reasonCode === REASON_OTHER;
  });

  const isDisablePartialDay = computed(() => {
    const isDisable = REQUEST_MONTH_TYPES.includes(state.formData.requestTypeCode!);

    state.formData.partialDay = isDisable ? ALL_DAY_CODE : state.formData.partialDay;
    calRemain();
    return isDisable;
  });

  const handleFinish = async () => {
    try {
      await createReqestForm.value.validate();
      setIsLoading(true);
      if (
        isLeaveOff(state.formData.requestTypeCode) &&
        !REQUEST_MONTH_TYPES.includes(state.formData.requestTypeCode!)
      ) {
        const timeWorkingParams: TWorkingTime = {
          leaveFrom: state.formData.leaveFrom,
          leaveTo: state.formData.leaveTo,
          partialDay: state.formData.partialDay,
          requestTypeCode: state.formData.requestTypeCode,
          representedUserID: state.formData.representedUserID,
          requestID: isCreate.value ? undefined : paramsRouter.value.id,
        };

        const workingTimeResponse = await MyRequestService.checkRemainWorkingTime(
          timeWorkingParams,
        );
        const { requestMonth, workingTime, standardWorkingTime, warningFlag } = workingTimeResponse;

        if (warningFlag) {
          return showConfirmModal({
            type: 'warning',
            width: 400,
            onOK: () => handleEventSubmit(),
            subTitle: t('message.W0005', [requestMonth, workingTime, standardWorkingTime]),
          });
        }

        handleEventSubmit();
      } else {
        handleEventSubmit();
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleEventSubmit = async () => {
    try {
      setIsLoading(true);

      if (isCreate.value) {
        await MyRequestService.create(state.formData);
      } else {
        state.formData.requestID = paramsRouter.value.id;
        await MyRequestService.update(state.formData);
      }

      setTimeout(() => handleClose(), 1000);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    const pathHistory = router.options.history.state.back?.toString();
    // return to myRequest screen
    if (!pathHistory || !pathHistory.includes('requestID')) {
      router.push({ name: 'myRequest' });
      return;
    }
    // return to myRequest screen with search conditions
    router.push(pathHistory.replace(/(.*)&requestID.*/, '$1'));
  };

  const initEditFormData = async () => {
    try {
      setIsLoading(true);
      const resuft = await MyRequestService.getByID(
        paramsRouter.value.id,
        paramsRouter.value.subID,
      );
      state.formData.requestTypeCode = resuft.requestTypeCode;
      state.formData.leaveFrom = formatToDate(resuft.leaveFrom);
      state.formData.leaveTo = formatToDate(resuft.leaveTo);
      state.formData.partialDay = resuft.partialDay;
      state.formData.reasonCode = resuft.reasonCode;
      state.formData.approverID = resuft.approverID;
      state.formData.detailedReason = resuft.detailedReason;
      state.formData.confirmUserIDs = map(resuft.confirmUsers, 'userID');
      state.formData.informTo = map(resuft.informUsers, 'userID');
      state.formData.expectedApproveDateTime =
        resuft.expectedApproveDateTime && formatToDateTime(resuft.expectedApproveDateTime);
      state.formData.representedUserID =
        resuft.userID === resuft.createUserID ? undefined : resuft.userID;
      state.formData.duration = resuft.duration;
      state.saveRequestTypeCode = resuft.requestTypeCode;
    } catch (error: any) {
      if (error?.response?.data?.status === StatusCodes.FORBIDDEN) {
        router.replace({ path: '/403' });
      } else {
        router.replace({ path: '/404' });
      }
    } finally {
      setIsLoading(false);
      state.rootEdit = cloneDeep(state.formData);
    }
  };

  watch(
    () => state.formData.representedUserID,
    () => {
      if (state.formData.representedUserID === state.formData.approverID) {
        state.formData.approverID = undefined;
      }

      if (isCreate.value) {
        state.formData.approverID = state.formData.representedUserID ? myID : undefined;
      }
      if (state.formData.representedUserID) {
        state.staffID = state.formData.representedUserID;
      } else {
        state.staffID = myID;
      }
      const user = options.value.userOptions.find(({ value }) => value == state.staffID);
      if (user) {
        state.fullName = user.userInfo.lastName + ' ' + user.userInfo.firstName;
      }
      calRemain();
    },
  );

  watch(
    () => state.formData,
    () => {
      const rootEdit = cloneDeep(state.rootEdit);
      rootEdit.confirmUserIDs?.sort();
      rootEdit.informTo?.sort();

      const formData = cloneDeep(state.formData);
      formData.confirmUserIDs?.sort();
      formData.informTo?.sort();
      state.isChangeFormData = isEqual(rootEdit, formData);
    },
    { deep: true },
  );

  watchEffect(() => {
    if (paramsRouter.value.id && paramsRouter.value.subID) {
      initEditFormData();
    } else {
      state.formData = cloneDeep(initformData);
    }
  });

  watchEffect(async () => {
    if (state.formData.leaveFrom && state.formData.leaveTo) {
      state.holidays = await AnnualHolidayService.countHoliday({
        startDate: state.formData.leaveFrom,
        endDate: state.formData.leaveTo,
      });
    }
  });

  watch(
    [() => state.formData.requestTypeCode, () => state.formData.leaveFrom],
    async ([newRequestTypeCode, newLeaveFrom], [oldRequestTypeCode]) => {
      if (state.formData.requestTypeCode) {
        state.displayRemain = true;
        calRemain();
      } else {
        state.displayRemain = false;
      }
      if (isEdit) {
        isEdit = false;
        return;
      }
      if (!REQUEST_MONTH_TYPES.includes(newRequestTypeCode!)) {
        if (REQUEST_MONTH_TYPES.includes(oldRequestTypeCode!)) {
          state.formData.leaveTo = '';
        }
        return;
      }

      createReqestForm.value.clearValidate('leaveTo');
      if (newRequestTypeCode) {
        const timeOffGenerate = await TimeOffGenerateService.getByID(newRequestTypeCode.toString());
        if (!newLeaveFrom) {
          state.formData.leaveTo = '';
          return;
        }
        const leaveTo = moment(newLeaveFrom)
          .add(timeOffGenerate?.maximumPerLog, 'M')
          .subtract(1, 'days');
        state.formData.leaveTo = leaveTo.format('YYYY-MM-DD') || '';
      }
    },
  );

  const calRemain = async () => {
    state.myTimeOffLeaveList = await MyTimeOffLeaveService.getList({ staffID: state.staffID });
    const myTimeOffLeave = state.myTimeOffLeaveList.find(
      ({ timeOffCode }) => Number(timeOffCode) === state.formData.requestTypeCode,
    );
    let timeOffGenerate;
    if (state.formData.requestTypeCode) {
      timeOffGenerate = await TimeOffGenerateService.getByID(
        state.formData.requestTypeCode.toString(),
      );
    }
    if (myTimeOffLeave) {
      if (
        !REQUEST_MONTH_TYPES.includes(state.formData.requestTypeCode!) &&
        timeOffGenerate.limitedByYear == true
      ) {
        if (isCreate.value) {
          state.remainingQuotas = myTimeOffLeave.remainingQuotas;
        } else {
          if (state.formData.requestTypeCode == state.saveRequestTypeCode) {
            state.remainingQuotas =
              myTimeOffLeave.remainingQuotas + Number(state.formData.duration);
          } else {
            state.remainingQuotas = myTimeOffLeave.remainingQuotas;
          }
        }
      } else {
        state.remainingQuotas = timeOffGenerate.maximumPerLog;
      }
    } else {
      state.remainingQuotas = 0;
    }
    if (state.remainingQuotas > 0) {
      state.isvalidRemain = true;
    } else {
      state.isvalidRemain = false;
    }
  };
</script>

<template>
  <g-top-content>
    <a-space>
      <g-button
        :disabled="state.isChangeFormData && !!paramsRouter.id"
        type="primary"
        class="w-24"
        @click="handleFinish"
      >
        {{ $t('label.submit') }}
      </g-button>
      <g-button type="warning" class="w-24" @click="() => handleClose()">
        {{ $t('label.close') }}
      </g-button>
    </a-space>
  </g-top-content>
  <transition name="fade-slide" mode="out-in" appear :key="paramsRouter.id">
    <div class="create-request-page bg-white m-4 p-4 rounded shadow-md">
      <time-off-request-and-balance-modal
        :staff-i-d="state.staffID"
        :full-name="state.fullName"
        :remaining-quotas="displayRemain(t, state.remainingQuotas, state.formData.requestTypeCode)"
        :display-remain="state.displayRemain"
        :isvalid-remain="state.isvalidRemain"
      />

      <div class="pt-6">
        <a-form
          ref="createReqestForm"
          :model="state.formData"
          :rules="formRules"
          @finish="handleFinish"
        >
          <div class="grid md:grid-cols-12">
            <a-form-item
              name="requestTypeCode"
              class="col-span-5 required"
              :label="$t('label.requestType')"
            >
              <a-select
                v-model:value="state.formData.requestTypeCode"
                show-search
                :placeholder="$t('label.select')"
                option-filter-prop="label"
                :options="options.requestType"
              />
            </a-form-item>

            <a-form-item
              v-if="isCreate"
              v-role="[roleEnum.HR]"
              name="representedUser"
              class="col-span-5 md:col-start-7"
              :label="$t('label.representedUser')"
            >
              <a-select
                v-model:value="state.formData.representedUserID"
                allow-clear
                show-search
                max-tag-count="responsive"
                :placeholder="$t('label.select')"
                option-filter-prop="label"
                :options="representedUsers"
              />
            </a-form-item>
          </div>

          <div class="grid md:grid-cols-12">
            <a-form-item
              name="leaveFrom"
              class="md:col-span-5 required"
              :label="$t('label.startDate')"
            >
              <g-date-picker
                v-model:value="state.formData.leaveFrom"
                :disabled-date-range="{ max: state.formData.leaveTo }"
              />
            </a-form-item>

            <a-form-item
              name="leaveTo"
              class="md:col-span-5 md:col-start-7 required"
              :label="$t('label.endDate')"
            >
              <g-date-picker
                v-model:value="state.formData.leaveTo"
                :disabled-date-range="{ min: state.formData.leaveFrom }"
              />
            </a-form-item>
          </div>

          <div class="grid md:grid-cols-12">
            <a-form-item
              name="partialDay"
              class="md:col-span-5 required"
              :label="$t('label.partialDay')"
            >
              <a-select
                v-model:value="state.formData.partialDay"
                :disabled="isDisablePartialDay"
                show-search
                option-filter-prop="label"
                :placeholder="$t('label.select')"
                :options="options.partialDay"
              />
            </a-form-item>

            <a-form-item class="md:col-span-5 md:col-start-7" :label="$t('label.duration')">
              <a-tag color="#108ee9">
                {{
                  duration(
                    t,
                    state.formData.leaveFrom,
                    state.formData.leaveTo,
                    state.formData.partialDay,
                    state.holidays,
                    state.formData.requestTypeCode,
                  )
                }}
              </a-tag>
            </a-form-item>
          </div>

          <div class="grid md:grid-cols-12">
            <a-form-item
              name="reasonCode"
              class="md:col-span-5 required"
              :label="$t('label.reason')"
            >
              <a-select
                v-model:value="state.formData.reasonCode"
                show-search
                :placeholder="$t('label.select')"
                option-filter-prop="label"
                :options="listReason"
              />
            </a-form-item>

            <a-form-item
              name="confirmUserIDs"
              class="md:col-start-7 md:col-span-5 required"
              :label="$t('label.supervisor')"
            >
              <a-select
                v-model:value="state.formData.confirmUserIDs"
                show-search
                mode="multiple"
                max-tag-count="responsive"
                :placeholder="$t('label.selectOptions')"
                option-filter-prop="label"
                :options="supervisor"
              />
            </a-form-item>
          </div>

          <div class="grid md:grid-cols-12">
            <div class="md:col-span-5">
              <a-form-item
                name="detailedReason"
                :label="$t('label.detailReason')"
                :rules="[
                  {
                    required: checkReasonOrder,
                    message: false,
                  },
                ]"
                :class="{
                  required: checkReasonOrder,
                }"
              >
                <a-textarea
                  v-model:value="state.formData.detailedReason"
                  :maxlength="255"
                  :rows="4"
                />
              </a-form-item>
            </div>
            <div class="md:col-span-5 md:col-start-7">
              <a-form-item name="approverID" class="required" :label="$t('label.approver')">
                <a-select
                  v-model:value="state.formData.approverID"
                  show-search
                  :placeholder="$t('label.select')"
                  option-filter-prop="label"
                  :options="approver"
                />
              </a-form-item>

              <a-form-item :label="$t('label.informTo')">
                <a-select
                  v-model:value="state.formData.informTo"
                  mode="multiple"
                  max-tag-count="responsive"
                  :placeholder="$t('label.selectOptions')"
                  option-filter-prop="label"
                  :options="options.userOptions"
                />
              </a-form-item>
            </div>
          </div>

          <div class="grid md:grid-cols-12">
            <a-form-item class="md:col-span-5" :label="$t('label.expectedApprove')">
              <g-date-picker
                v-model:value="state.formData.expectedApproveDateTime"
                :show-time="true"
                :disabled-date-range="{ min: formatToDate(moment(), 'YYYY-MM-DD HH:mm') }"
              />
            </a-form-item>
          </div>
        </a-form>
      </div>
    </div>
  </transition>
</template>

<style lang="scss" scoped>
  :deep .ant-form-item-label {
    width: 155px;
  }
</style>
