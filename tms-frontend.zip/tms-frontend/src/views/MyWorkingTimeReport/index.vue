<script setup lang="ts"></script>

<template>
  <div>MyWorkingTimeReport here...</div>
</template>
