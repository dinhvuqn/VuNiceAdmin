<script setup lang="ts">
  import { useRegulationStore } from '@/store/modules/regulation';
  import { roleEnum } from '@/enums/roleEnum';

  const { t } = useI18n();
  const { userManualFileURL, getUserManual, uploadUserManual } = toRefs(useRegulationStore());
  const file = ref<HTMLInputElement | null>(null);

  getUserManual.value();
</script>

<template>
  <g-top-content>
    <g-button v-role="[roleEnum.HR]" type="warning" class="m-w-24" @click="file?.click()">
      {{ t('label.upload') }}
    </g-button>
    <input ref="file" type="file" hidden accept=".pdf" @change="uploadUserManual" />
  </g-top-content>
  <transition name="fade-slide" mode="out-in" appear>
    <div class="use-leave-days-page overflow-hidden m-4">
      <div class="rounded shadow-md">
        <div class="h-[calc(100vh-96px)] overflow-auto">
          <iframe :src="userManualFileURL" frameborder="0" height="100%" width="100%"></iframe>
        </div>
      </div>
    </div>
  </transition>
</template>
