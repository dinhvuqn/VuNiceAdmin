<script setup lang="ts">
  import { use } from 'echarts/core';
  import { BarChart } from 'echarts/charts';
  import { CanvasRenderer } from 'echarts/renderers';
  import { TitleComponent, TooltipComponent, LegendComponent } from 'echarts/components';
  import { GridComponent, DatasetComponent } from 'echarts/components';
  import VChart from 'vue-echarts';

  import DashboardService, { TDashboardByRequestType } from '@/services/dashboard/index';
  import { useSelectOptions } from '@/hooks/useSelectOption';
  import SelectOptionEnum from '@/enums/selectOptionEnum';
  import { cloneDeep } from 'lodash-es';
  import { initRequestTypeChartOption } from './constant';
  import { formatToMonth } from '@/utils/dateUtil';

  use([
    BarChart,
    DatasetComponent,
    GridComponent,
    CanvasRenderer,
    TitleComponent,
    TooltipComponent,
    LegendComponent,
  ]);

  const { locale, t } = useI18n();
  const setIsLoading = inject<Fn<boolean>>('setIsLoading')!;

  const options = useSelectOptions([
    SelectOptionEnum.REQUEST_STATUS,
    SelectOptionEnum.REQUEST_TYPE,
  ]);

  const state = reactive({
    dashboadByRequestType: [] as TDashboardByRequestType[],
    selectedRequestType: [] as number[],
  });

  const chartHeight = computed(() => requestTypeChartOption.value.yAxis.data.length * 40 + 200);

  const requestTypeChartOption = computed(() => {
    const initOption = initRequestTypeChartOption(t);

    const { yAxis, series } = initOption;
    const dashboardData = cloneDeep(state.dashboadByRequestType).filter(({ requestTypeCode }) =>
      state.selectedRequestType.includes(requestTypeCode),
    );

    yAxis.data = dashboardData.map(({ requestTypeName }) => addNewLineForStr(requestTypeName, 40));

    series[0].data = dashboardData.map(({ countDay }) => countDay);
    series[1].data = dashboardData.map(({ countStaff }) => countStaff);

    return {
      ...initOption,
      yAxis,
      series,
    };
  });

  const addNewLineForStr = (str: string, charInLine: number) => {
    if (charInLine >= str.length) return str;

    const strArr = [...str];

    if (strArr.length > charInLine) {
      let spaceIndex = str.substring(0, charInLine).lastIndexOf(' ');
      spaceIndex = spaceIndex === -1 ? charInLine : spaceIndex;

      strArr.splice(spaceIndex, 0, '\n');
    }

    return strArr.join('');
  };

  const getDashboardByRequestType = async () => {
    try {
      setIsLoading(true);
      state.dashboadByRequestType = await DashboardService.dashboardByRequestType();

      if (state.selectedRequestType.length === 0) {
        state.selectedRequestType = state.dashboadByRequestType.map(
          ({ requestTypeCode }) => requestTypeCode,
        );
      }
    } finally {
      setIsLoading(false);
    }
  };

  getDashboardByRequestType();

  watch(
    () => locale.value,
    () => getDashboardByRequestType(),
  );
</script>

<i18n src="./locale" />
<template>
  <g-top-content />
  <transition name="fade-slide" mode="out-in" appear>
    <div class="my-report-page overflow-auto">
      <div class="bg-white p-4 rounded shadow-md m-4">
        <a-form class="grid md:grid-cols-4 sm:grid-cols-2 gap-x-4">
          <a-form-item class="ant-form-item--column" :label="$t('label.requestType')">
            <a-select
              v-model:value="state.selectedRequestType"
              mode="multiple"
              max-tag-count="responsive"
              :placeholder="$t('label.selectOptions')"
              option-filter-prop="label"
              :options="options.requestType"
            />
          </a-form-item>
        </a-form>
      </div>

      <div
        class="bg-white p-4 rounded shadow-md m-4 pb-0 min-h-[384px] max-h-[calc(100vh-96px)]"
        :style="{ height: chartHeight + 'px' }"
      >
        <div class="flex flex-col h-full gap-4">
          <div class="flex flex-wrap gap-2 items-end">
            <span class="text-[20px] text-gray-700 ml-2 font-semibold">
              {{ t('label.byRequestType', [formatToMonth()]) }}
            </span>
            <span class="mb-0.5 text-red-500">
              {{ t('label.noteByRequestType') }}
            </span>
          </div>
          <v-chart
            v-if="requestTypeChartOption.yAxis.data.length > 0"
            id="#logo"
            class="chart"
            :option="requestTypeChartOption"
            ref="bar"
            autoresize
          />
          <div v-else class="w-full h-full flex flex-col">
            <div class="text-gray-300 flex flex-col justify-center items-center mt-10">
              <g-icon icon="bar-chart-outlined" class="text-[200px]" />
              <span class="font-bold">{{ t('label.noData') }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </transition>
</template>
