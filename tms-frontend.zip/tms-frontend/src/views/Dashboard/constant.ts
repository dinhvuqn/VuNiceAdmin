import { initBarChartOption } from '@/constants/charts';

export const initRequestTypeChartOption = (t: Fn) => {
  const barChartOption = initBarChartOption();
  barChartOption.legend.data = [t('label.numberOfDays'), t('label.numberOfPeople')];

  return {
    ...barChartOption,
    series: [
      {
        type: 'bar',
        name: t('label.numberOfDays'),
        data: [] as number[],
        label: {
          show: true,
          position: 'right',
        },
        barCategoryGap: '50%',
      },
      {
        type: 'bar',
        name: t('label.numberOfPeople'),
        data: [] as number[],
        label: {
          show: true,
          position: 'right',
        },
        barCategoryGap: '50%',
      },
    ],
  };
};
