import type { ColumnProps } from 'ant-design-vue/es/table/Column';
export const createColumns = (t: Fn<string>): ColumnProps[] => [
  {
    title: t('label.no'),
    dataIndex: 'no',
    key: 'No',
    align: 'center',
    width: 60,
    slots: {
      customRender: 'no',
    },
  },
  {
    title: t('label.requestType'),
    dataIndex: 'requestTypeName',
    key: 'requestType',
    width: 300,
    slots: {
      customRender: 'requestType',
    },
  },
  {
    title: t('label.requestTime'),
    dataIndex: 'createDateTime',
    key: 'timeRequest',
    width: 250,
    slots: {
      customRender: 'timeRequest',
    },
  },
  {
    title: t('label.duration'),
    dataIndex: 'duration',
    key: 'duration',
    align: 'right',
    width: 130,
    slots: {
      customRender: 'duration',
    },
  },
  {
    title: t('label.reason'),
    dataIndex: 'reasonName',
    key: 'reason',
    width: 300,
  },
  {
    title: t('label.approver'),
    dataIndex: 'approverName',
    key: 'approver',
    width: 180,
    slots: {
      customRender: 'approver',
    },
  },
  {
    title: t('label.status'),
    dataIndex: 'requestStatusName',
    key: 'status',
    align: 'center',
    width: 130,
    slots: {
      customRender: 'status',
    },
  },
];
