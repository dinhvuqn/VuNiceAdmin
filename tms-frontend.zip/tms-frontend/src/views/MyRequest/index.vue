<script setup lang="ts">
  import TimeOffRequestAndBalanceModal from '@/components/common/TimeOffRequestAndBalanceModal/index.vue';
  import MyRequestDetail from '@/components/MyRequest/MyRequestDetail.vue';
  import MyRequestService, { TSearch, TMyRequest } from '@/services/my-request';
  import SelectOptionEnum from '@/enums/selectOptionEnum';
  import { useSelectOptions } from '@/hooks/useSelectOption';
  import { formatToDate } from '@/utils/dateUtil';
  import { formatQueryToArray, getColorByStatus } from '@/utils';
  import moment from 'moment';
  import { createColumns } from './constant';
  import { isEmpty } from '@/utils/is';
  import { cloneDeep, pick } from 'lodash-es';
  import { displayDuration } from '@/constants/displayDuration';
  import { useUserStore } from '@/store/modules/user';

  const { t } = useI18n();
  const router = useRouter();
  const { fullName, userID: myID } = useUserStore();

  type TState = {
    myRequestList: TMyRequest[];
    formSearch: TSearch;
    visibleModals: { viewRequestModal: boolean };
    currentRequest: TMyRequest | undefined;
    total: number;
    loading: boolean;
  };

  const initFormSearch: TSearch = {
    timeRequestFrom: moment().startOf('year').format('YYYY-MM-DD'),
    timeRequestTo: moment().endOf('year').format('YYYY-MM-DD'),
    requestTypes: undefined,
    requestStatus: undefined,
    pageSize: 20,
    curentpage: 1,
  };

  const state = reactive<TState>({
    myRequestList: [],
    formSearch: { ...initFormSearch },
    visibleModals: { viewRequestModal: false },
    currentRequest: undefined,
    total: 0,
    loading: false,
  });

  const options = useSelectOptions([
    SelectOptionEnum.REQUEST_STATUS,
    SelectOptionEnum.REQUEST_TYPE,
  ]);

  const getMyRequestList = async (currentPage?: number) => {
    try {
      state.loading = true;
      state.formSearch.curentpage = currentPage || 1;

      const { list, total } = await MyRequestService.getList(state.formSearch);

      state.myRequestList = list;
      state.total = total;
    } finally {
      state.loading = false;
    }
  };

  const formatTimeRequest = (from: string, to: string, partial: string) => {
    return t('label.fromToDate', {
      from: formatToDate(from),
      to: formatToDate(to),
      partial: partial && `(${partial})`,
    });
  };

  onMounted(() => {
    if (!isEmpty(router.currentRoute.value.query)) {
      const searchInfo = cloneDeep(router.currentRoute.value.query as any);
      searchInfo.requestStatus = formatQueryToArray(searchInfo.requestStatus);
      searchInfo.requestTypes = formatQueryToArray(searchInfo.requestTypes);

      state.formSearch = {
        ...state.formSearch,
        ...pick(searchInfo, [
          'timeRequestFrom',
          'timeRequestTo',
          'requestTypes',
          'requestStatus',
          'pageSize',
          'curentpage',
        ]),
      } as TSearch;
    }

    getMyRequestList(state.formSearch.curentpage);
  });

  watch(
    () => router.currentRoute.value.query,
    () => {
      if (
        isEmpty(router.currentRoute.value.query) &&
        router.currentRoute.value.name === 'myRequest'
      ) {
        state.formSearch = { ...initFormSearch };
        getMyRequestList();
      }
    },
  );

  const handleFormFinish = () => {
    getMyRequestList();

    const query = { ...state.formSearch } as Partial<TSearch>;
    router.push({ query });
  };
</script>

<template>
  <g-top-content />
  <transition name="fade-slide" mode="out-in" appear>
    <div class="my-request-page m-4">
      <div class="bg-white mb-4 p-4 rounded shadow-md">
        <time-off-request-and-balance-modal :staff-i-d="myID" :full-name="fullName" />
        <a-form
          class="grid md:grid-cols-4 sm:grid-cols-2 gap-x-4"
          :model="state.formSearch"
          @finish="handleFormFinish()"
        >
          <a-form-item class="ant-form-item--column required" :label="$t('label.timeRequestFrom')">
            <g-date-picker
              v-model:value="state.formSearch.timeRequestFrom"
              :allow-clear="false"
              :disabled-date-range="{ max: state.formSearch.timeRequestTo }"
            />
          </a-form-item>
          <a-form-item class="ant-form-item--column required" :label="$t('label.timeRequestTo')">
            <g-date-picker
              v-model:value="state.formSearch.timeRequestTo"
              :allow-clear="false"
              :disabled-date-range="{ min: state.formSearch.timeRequestFrom }"
            />
          </a-form-item>
          <a-form-item class="ant-form-item--column" :label="$t('label.requestType')">
            <a-select
              v-model:value="state.formSearch.requestTypes"
              mode="multiple"
              max-tag-count="responsive"
              option-filter-prop="label"
              :placeholder="$t('label.selectOptions')"
              :options="options.requestType"
            />
          </a-form-item>
          <a-form-item class="ant-form-item--column" :label="$t('label.requestStatus')">
            <a-select
              v-model:value="state.formSearch.requestStatus"
              mode="multiple"
              max-tag-count="responsive"
              option-filter-prop="label"
              :placeholder="$t('label.selectOptions')"
              :options="options.requestStatus"
            />
          </a-form-item>
          <div class="md:col-start-4 sm:col-start-2 flex justify-end">
            <g-button type="primary" html-type="submit" class="w-24">
              {{ $t('label.search') }}
            </g-button>
          </div>
        </a-form>
      </div>
      <div class="bg-white p-4 rounded shadow-md">
        <g-table
          v-model:currentPage="state.formSearch.curentpage"
          v-model:pageSize="state.formSearch.pageSize"
          class="table--header-center"
          :columns="createColumns(t)"
          :data-source="state.myRequestList"
          :loading="state.loading"
          :total="state.total"
          @pagination="getMyRequestList"
          @refresh-list="getMyRequestList(state.formSearch.curentpage)"
        >
          <template #no="{ index }">
            {{ index + 1 + state.formSearch.pageSize * (state.formSearch.curentpage - 1) }}
          </template>
          <template #requestType="{ text, record: { requestID, subID } }">
            <router-link
              class="text-blue-600 underline cursor-pointer router-link"
              :to="{ query: { ...state.formSearch, requestID, subID } }"
            >
              {{ text }}
            </router-link>
          </template>
          <template #timeRequest="{ record: { leaveFrom, leaveTo, partialDayName } }">
            {{ formatTimeRequest(leaveFrom, leaveTo, partialDayName) }}
          </template>
          <template #duration="{ record: { duration, requestTypeCode } }">
            {{ duration.toFixed(1) }}
            {{ displayDuration(t, duration, requestTypeCode) }}
          </template>
          <template #approver="{ record: { approverName, approverAccount } }">
            {{ `${approverName} (${approverAccount}) ` }}
          </template>
          <template #status="{ text, record: { requestStatusCode } }">
            <a-tag :color="getColorByStatus(requestStatusCode)" class="min-w-[90px]">
              {{ text }}
            </a-tag>
          </template>
        </g-table>
      </div>
    </div>
  </transition>
  <my-request-detail
    v-model:visible="state.visibleModals.viewRequestModal"
    @refresh-list="getMyRequestList()"
  />
</template>
<style lang="scss" scoped>
  .router-link:focus-visible {
    outline: -webkit-focus-ring-color auto 1px;
  }
</style>
