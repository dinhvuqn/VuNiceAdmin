<script setup lang="ts">
  import { useLanguage } from '@/hooks/useLanguage';

  const { isVieLang, LanguageEnum } = useLanguage();
</script>

<template>
  <a-switch
    v-show="false"
    v-model:checked="isVieLang"
    :checked-children="LanguageEnum.VI"
    :un-checked-children="LanguageEnum.EN"
    class="!mt-2.5"
  />
  <a-result status="403" :title="$t('label.messageAccessDenied')">
    <template #extra>
      <g-button type="primary" @click="$router.push('/')">{{ $t('label.homePageBtn') }}</g-button>
    </template>
  </a-result>
</template>
