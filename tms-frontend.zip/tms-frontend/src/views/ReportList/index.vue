<script setup lang="ts">
  import { createColumns } from './constant';
  import ReportDetailModal from '@/components/common/ViewReportDetailModal/index.vue';
  import ReportListService, { TSearch, TReportList } from '@/services/report-list';
  import { formatToMonth, formatToDateTime } from '@/utils/dateUtil';
  import { downloadExcelFile, getFileSizeKB } from '@/utils';
  import { cloneDeep } from 'lodash-es';
  import { useSelectOptions } from '@/hooks/useSelectOption';
  import SelectOptionEnum from '@/enums/selectOptionEnum';

  const { t } = useI18n();
  const showConfirmModal = inject<Fn<TConfirmConfig>>('showConfirmModal')!;
  const router = useRouter();

  type TState = {
    myReportList: TReportList[];
    formSearch: TSearch;
    paramsSearch: TSearch;
    visibleModals: {
      reportDetail: boolean;
    };
    total: number;
    loading: boolean;
  };

  const { workingMonthFrom: queryMonthFrom, workingMonthTo: queryMonthTo } =
    router.currentRoute.value.query;

  const initSearchParams = {
    workingMonthFrom: formatToMonth(queryMonthFrom as string),
    workingMonthTo: formatToMonth(queryMonthTo as string),
    userIDs: undefined,
    pageSize: 20,
    curentpage: 1,
  };

  const state = reactive<TState>({
    myReportList: [],
    formSearch: cloneDeep(initSearchParams),
    paramsSearch: cloneDeep(initSearchParams),
    visibleModals: {
      reportDetail: false,
    },
    total: 0,
    loading: false,
  });

  const options = useSelectOptions([SelectOptionEnum.USER]);

  const handleClickSearch = () => {
    state.paramsSearch = cloneDeep(state.formSearch);
    getReportList();
  };

  const getReportList = async (currentPage?: number) => {
    try {
      state.loading = true;
      state.formSearch.curentpage = currentPage || 1;
      state.paramsSearch.curentpage = currentPage || 1;

      const { list, total } = await ReportListService.getList(state.paramsSearch);

      state.myReportList = list;
      state.total = total;
    } finally {
      state.loading = false;
    }
  };

  const exportListReport = async () => {
    const { workingMonthFrom, workingMonthTo, userIDs } = state.paramsSearch;

    const responseData = await ReportListService.exportExcel({
      workingMonthFrom,
      workingMonthTo,
      userIDs,
    });

    const fileName = 'TMS_Report_' + formatToDateTime(new Date(), 'YYYYMMDDHHmmss') + '.xlsx';

    showConfirmModal({
      title: t('message.W0004'),
      subTitle: `${fileName} (${getFileSizeKB(responseData)})`,
      icon: 'download-outlined',
      onOK: () => downloadExcelFile(responseData, fileName),
    });
  };

  getReportList();
</script>

<i18n src="./locale" />
<template>
  <g-top-content>
    <g-button type="warning" class="m-w-24" @click="exportListReport">
      {{ t('label.export') }}
    </g-button>
  </g-top-content>
  <transition name="fade-slide" mode="out-in" appear>
    <div class="my-report-page m-4">
      <div class="bg-white mb-4 p-4 rounded shadow-md">
        <a-form class="grid md:grid-cols-4 sm:grid-cols-2 gap-x-4" @finish="handleClickSearch">
          <a-form-item
            name="workingMonthFrom"
            class="ant-form-item--column required"
            :label="t('label.workingMonthFrom')"
          >
            <g-date-picker
              v-model:value="state.formSearch.workingMonthFrom"
              :disabled-date-range="{ max: state.formSearch.workingMonthTo }"
              :allow-clear="false"
              picker="month"
            />
          </a-form-item>
          <a-form-item
            name="workingMonthTo"
            class="ant-form-item--column required"
            :label="t('label.workingMonthTo')"
          >
            <g-date-picker
              v-model:value="state.formSearch.workingMonthTo"
              :disabled-date-range="{ min: state.formSearch.workingMonthFrom }"
              :allow-clear="false"
              picker="month"
            />
          </a-form-item>
          <a-form-item name="userIDs" class="ant-form-item--column" :label="t('label.requester')">
            <a-select
              v-model:value="state.formSearch.userIDs"
              mode="multiple"
              max-tag-count="responsive"
              option-filter-prop="label"
              :placeholder="$t('label.selectOptions')"
              :options="options.userOptions"
            />
          </a-form-item>
          <div class="md:col-start-4 sm:col-start-2 flex justify-end items-center">
            <g-button type="primary" html-type="submit" class="w-24" @click="handleClickSearch">
              {{ $t('label.search') }}
            </g-button>
          </div>
        </a-form>
      </div>
      <div class="bg-white rounded shadow-md p-4">
        <div class="flex">
          <p class="font-medium mr-3">{{ t('label.from') }} :</p>
          <p class="mr-3">{{ formatToMonth(state.paramsSearch.workingMonthFrom) }}</p>
          <p class="font-medium mr-3">{{ t('label.to') }} :</p>
          <p>{{ formatToMonth(state.paramsSearch.workingMonthTo) }}</p>
        </div>
        <g-table
          v-model:currentPage="state.formSearch.curentpage"
          v-model:pageSize="state.formSearch.pageSize"
          :columns="createColumns(t)"
          class="table--header-center"
          :data-source="state.myReportList"
          :loading="state.loading"
          :total="state.total"
          @pagination="getReportList"
          @refresh-list="getReportList(state.formSearch.curentpage)"
        >
          <template #no="{ index }">
            {{ index + 1 + state.formSearch.pageSize * (state.formSearch.curentpage - 1) }}
          </template>
          <template #account="{ value, record: { userID, workingMonthFrom, workingMonthTo } }">
            <router-link
              class="text-blue-600 underline cursor-pointer router-link"
              :to="{ query: { userID, workingMonthFrom, workingMonthTo } }"
            >
              {{ value }}
            </router-link>
          </template>
        </g-table>
      </div>
    </div>
  </transition>
  <report-detail-modal v-model:visible="state.visibleModals.reportDetail" />
</template>
<style lang="scss" scoped>
  .router-link:focus-visible {
    outline: -webkit-focus-ring-color auto 1px;
  }
</style>
