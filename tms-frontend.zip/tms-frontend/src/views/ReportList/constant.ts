import type { ColumnProps } from 'ant-design-vue/es/table/Column';

export const createColumns = (t: Fn<string>): ColumnProps[] => [
  {
    title: t('label.no'),
    dataIndex: 'no',
    key: 'no',
    slots: {
      customRender: 'no',
    },
    align: 'center',
    width: 60,
  },
  {
    title: t('label.employeeID'),
    dataIndex: 'userID',
    key: 'userID',
    width: 200,
  },
  {
    title: t('label.employeeAccount'),
    dataIndex: 'account',
    key: 'account',
    slots: {
      customRender: 'account',
    },
    width: 300,
  },
  {
    title: t('label.employeeName'),
    dataIndex: 'userName',
    key: 'userName',
    width: 250,
  },
  {
    title: t('label.workingDays'),
    dataIndex: 'workingDays',
    key: 'workingDays',
    align: 'right',
    width: 200,
  },
  {
    title: t('label.paidLeaveDays'),
    dataIndex: 'paidLeaveDays',
    key: 'paidLeaveDays',
    align: 'right',
    width: 200,
  },
  {
    title: t('label.unpaidLeaveDays'),
    dataIndex: 'unPaidLeaveDays',
    key: 'unPaidLeaveDays',
    align: 'right',
    width: 200,
  },
];
