import { TMyRequest } from './../../services/my-request/model.d';
import { usePermissioStore } from '@/store/modules/permission';
import { StatusEnum } from '@/enums/statusEnum';
import { useUserStore } from '@/store/modules/user';
import { TReceivedRequest } from '@/services/received-request/model.d';
import type { ColumnProps } from 'ant-design-vue/es/table/Column';

export const { isMyID, userID } = useUserStore();
export const { isHR } = usePermissioStore();

export const createColumns = (t: Fn<string>): ColumnProps[] => [
  {
    title: t('label.requester'),
    dataIndex: 'account',
    key: 'requester',
    width: 250,
    slots: {
      customRender: 'requester',
    },
  },
  {
    title: t('label.requestType'),
    dataIndex: 'requestTypeName',
    key: 'requestType',
    width: 250,
    slots: {
      customRender: 'requestType',
    },
  },
  {
    title: t('label.leavingTime'),
    dataIndex: 'leavingTime',
    key: 'leavingTime',
    width: 300,
    slots: {
      customRender: 'leavingTime',
    },
  },
  {
    title: `${t('label.duration')}`,
    dataIndex: 'duration',
    key: 'duration',
    width: 120,
    align: 'right',
    slots: {
      customRender: 'duration',
    },
  },
  {
    title: t('label.status'),
    dataIndex: 'requestStatusName',
    key: 'status',
    width: 150,
    align: 'center',
    slots: {
      customRender: 'status',
    },
  },
  {
    title: t('label.delegatedBy'),
    dataIndex: 'delegatedByName',
    key: 'delegatedByName',
    width: 150,
  },
  {
    title: t('label.delegatedTo'),
    dataIndex: 'delegatedToName',
    key: 'delegatedToName',
    width: 150,
  },
  {
    title: t('label.action'),
    dataIndex: 'action',
    key: 'action',
    width: 120,
    align: 'center',
    slots: {
      customRender: 'action',
    },
  },
];

const isInConfirmUserList = ({ confirmUsers }: TReceivedRequest) => {
  return confirmUsers.some(
    ({ userID, statusCode }) => isMyID(userID) && statusCode === StatusEnum.SUBMITTED,
  );
};

const isApprover = ({ approverID }: TReceivedRequest) => {
  return isMyID(approverID);
};

const isSubmitted = ({ requestStatusCode }: TReceivedRequest) => {
  return [StatusEnum.SUBMITTED].includes(requestStatusCode);
};

export const isSubmittedOrConfirmed = ({ requestStatusCode }: TReceivedRequest) => {
  return [StatusEnum.SUBMITTED, StatusEnum.CONFIRMED].includes(requestStatusCode);
};

export const isActiveConfirm = (requestList: TReceivedRequest[]) => {
  if (requestList.length === 0) return false;

  return requestList.every((request) => isSubmitted(request) && isInConfirmUserList(request));
};

export const isActiveDelegate = (requestList: TReceivedRequest[]) => {
  if (requestList.length === 0) return false;

  // Check userLogin equals request delegatedTo
  if (isMyID(requestList[0].delegatedTo)) {
    return false;
  }
  return isActiveConfirm(requestList);
};

export const isActiveApprove = (requestList: TReceivedRequest[]) => {
  if (requestList.length === 0) return false;

  return requestList.every((request) => isSubmittedOrConfirmed(request) && isApprover(request));
};

export const isActiveReject = (requestList: TReceivedRequest[]) => {
  if (requestList.length === 0) return false;

  return isActiveApprove(requestList) || isActiveConfirm(requestList);
};

export const isActiveCancel = (request: TReceivedRequest | TMyRequest) => {
  return ![StatusEnum.REJECTED, StatusEnum.CANCELLED].includes(request.requestStatusCode!);
};
