<script setup lang="ts">
  import ReceivedRequestDetail from '@/components/ReceivedRequestList/ReceivedRequestDetail.vue';
  import TopContent from '@/components/ReceivedRequestList/TopContent.vue';
  import ReceivedRequestService, {
    TSearch,
    TReceivedRequest,
    TActionType,
  } from '@/services/received-request';
  import { isEmpty } from '@/utils/is';
  import { formatToDate } from '@/utils/dateUtil';
  import { formatQueryToArray, getColorByStatus } from '@/utils';
  import SelectOptionEnum from '@/enums/selectOptionEnum';
  import { roleEnum } from '@/enums/roleEnum';
  import { StatusEnum } from '@/enums/statusEnum';
  import { usePermissioStore } from '@/store/modules/permission';
  import { useSelectOptions } from '@/hooks/useSelectOption';
  import {
    createColumns,
    isActiveApprove,
    isActiveReject,
    isActiveConfirm,
    isActiveDelegate,
  } from './constant';
  import moment from 'moment';
  import { cloneDeep, pick, omit } from 'lodash-es';
  import { displayDuration } from '@/constants/displayDuration';

  const { t } = useI18n();

  type TState = {
    receivedRequestList: TReceivedRequest[];
    currentRequest: TReceivedRequest;
    formSearch: TSearch;
    selectedRowKeys: string[];
    selectedRows: TReceivedRequest[];
    visibleModals: {
      viewRequestModal: boolean;
    };
    total: number;
    loading: boolean;
  };

  const router = useRouter();
  const { role } = usePermissioStore();

  const initParamRequestStatusByRole = computed(() => {
    const statusByRole = {
      [roleEnum.TEAM_LEADER]: [StatusEnum.SUBMITTED],
      [roleEnum.PM]: [StatusEnum.SUBMITTED],
      [roleEnum.HR]: [StatusEnum.CONFIRMED, StatusEnum.SUBMITTED],
      [roleEnum.DIRETOR]: [StatusEnum.CONFIRMED, StatusEnum.SUBMITTED],
    };
    return statusByRole[role] || [StatusEnum.SUBMITTED];
  });

  const initFormSearch = {
    leaveDateFrom: moment().startOf('year').format('YYYY-MM-DD'),
    leaveDateTo: moment().endOf('year').format('YYYY-MM-DD'),
    requestStatus: initParamRequestStatusByRole.value,
    requestTypes: undefined,
    requesters: undefined,
    pageSize: 20,
    curentpage: 1,
  };

  const options = useSelectOptions([
    SelectOptionEnum.USER,
    SelectOptionEnum.REQUEST_STATUS,
    SelectOptionEnum.REQUEST_TYPE,
  ]);

  const state = reactive<TState>({
    receivedRequestList: [],
    currentRequest: {} as TReceivedRequest,
    formSearch: { ...initFormSearch },
    selectedRowKeys: [],
    selectedRows: [],
    visibleModals: {
      viewRequestModal: false,
    },
    loading: false,
    total: 0,
  });

  const topContentRef = ref<{ handleCommentModal: Fn; handleDeligate: Fn }>();

  const getReceivedRequestList = async (currentPage?: number) => {
    try {
      state.loading = true;
      state.selectedRowKeys = [];
      state.selectedRows = [];
      state.formSearch.curentpage = currentPage || 1;

      const { list, total } = await ReceivedRequestService.getList(state.formSearch);

      state.receivedRequestList = list;
      state.total = total;
    } finally {
      state.loading = false;
    }
  };

  const selectedRequestIds = computed(() =>
    state.selectedRowKeys.map((rowKey) => rowKey.split('|')[0]),
  );

  const rowSelection = computed(() => ({
    selectedRowKeys: state.selectedRowKeys,
    onChange: (selectedRowKeys: string[], selectedRows: TReceivedRequest[]) => {
      state.selectedRowKeys = selectedRowKeys;
      state.selectedRows = selectedRows;
    },
    getCheckboxProps: (record: TReceivedRequest) => ({
      disabled:
        !isActiveApprove([record]) &&
        !isActiveConfirm([record]) &&
        !isActiveDelegate([record]) &&
        !isActiveReject([record]),
    }),
  }));

  const formatTimeRequest = (from: string, to: string, partial: string) => {
    return t('label.fromToDate', {
      from: formatToDate(from),
      to: formatToDate(to),
      partial: partial && `(${partial})`,
    });
  };

  const handleSingleAction = (actionType: TActionType, currentRequest: string) => {
    if (actionType === 'delegate') {
      topContentRef.value?.handleDeligate([currentRequest]);

      return;
    }

    topContentRef.value?.handleCommentModal(actionType, [currentRequest]);
  };

  const refreshList = () => {
    state.visibleModals.viewRequestModal = false;
    getReceivedRequestList();

    const { query } = router.currentRoute.value;

    router.push({ query: omit(query, ['requestID', 'subID']) });
  };

  onMounted(() => {
    if (!isEmpty(router.currentRoute.value.query)) {
      const searchInfo = cloneDeep(router.currentRoute.value.query as any);
      searchInfo.requestStatus = formatQueryToArray(searchInfo.requestStatus);
      searchInfo.requestTypes = formatQueryToArray(searchInfo.requestTypes);
      searchInfo.requesters = formatQueryToArray(searchInfo.requesters, false);

      state.formSearch = {
        ...state.formSearch,
        ...pick(searchInfo, [
          'leaveDateFrom',
          'leaveDateTo',
          'requestStatus',
          'requestTypes',
          'requesters',
          'pageSize',
          'curentpage',
        ]),
      } as TSearch;
    }

    getReceivedRequestList(state.formSearch.curentpage);
  });

  watch(
    () => router.currentRoute.value.query,
    () => {
      if (
        isEmpty(router.currentRoute.value.query) &&
        router.currentRoute.value.name === 'receivedRequestList'
      ) {
        state.formSearch = { ...initFormSearch };
        getReceivedRequestList();
      }
    },
  );

  const handleFormFinish = () => {
    getReceivedRequestList();

    const query = { ...state.formSearch } as Partial<TSearch>;
    router.push({ query });
  };

  const currentRequest = computed(() => {
    const { requestID: id } = router.currentRoute.value.query;

    return state.receivedRequestList.find(({ requestID }) => id === requestID);
  });

  const getDelegateExclusionStaffIds = (selectedRows: TReceivedRequest[]) => {
    const confirmIds = selectedRows
      .map(({ confirmUsers }) => confirmUsers.map(({ userID }) => userID))
      .flat();

    const staffIds = selectedRows.map(({ userID }) => userID);
    const approverIds = selectedRows.map(({ approverID }) => approverID);

    return cloneDeep([...staffIds, ...confirmIds, ...approverIds]);
  };

  const delegateUserOptions = computed(() => {
    const teamLeaderOrPMs = options.value.userOptions.filter(({ role }) =>
      [roleEnum.TEAM_LEADER, roleEnum.PM].includes(role),
    );

    const selectedRows = currentRequest.value ? [currentRequest.value] : state.selectedRows;
    const exclusionStaffIds = getDelegateExclusionStaffIds(selectedRows);

    return teamLeaderOrPMs.filter(({ value }) => !exclusionStaffIds.includes(value));
  });

  const isActiveActionApproveOrSubmit = (requestList: TReceivedRequest[]) =>
    isActiveApprove(requestList) || isActiveConfirm(requestList);
</script>

<template>
  <top-content
    ref="topContentRef"
    :delegate-user-options="delegateUserOptions"
    :selected-rows="state.selectedRows"
    :selected-row-keys="selectedRequestIds"
    @refresh-list="refreshList"
  />
  <transition name="fade-slide" mode="out-in" appear>
    <div class="received-request-list-page m-4">
      <div class="bg-white mb-4 p-4 rounded shadow-md">
        <a-form
          class="grid md:grid-cols-4 sm:grid-cols-2 gap-x-4"
          :model="state.formSearch"
          @finish="handleFormFinish"
        >
          <a-form-item class="ant-form-item--column required" :label="$t('label.leaveDateFrom')">
            <g-date-picker
              v-model:value="state.formSearch.leaveDateFrom"
              :allow-clear="false"
              :disabled-date-range="{ max: state.formSearch.leaveDateTo }"
            />
          </a-form-item>
          <a-form-item class="ant-form-item--column required" :label="$t('label.leaveDateTo')">
            <g-date-picker
              v-model:value="state.formSearch.leaveDateTo"
              :allow-clear="false"
              :disabled-date-range="{ min: state.formSearch.leaveDateFrom }"
            />
          </a-form-item>
          <a-form-item class="ant-form-item--column" :label="$t('label.requestStatus')">
            <a-select
              v-model:value="state.formSearch.requestStatus"
              mode="multiple"
              max-tag-count="responsive"
              :placeholder="$t('label.selectOptions')"
              option-filter-prop="label"
              :options="options.requestStatus"
            />
          </a-form-item>
          <a-form-item class="ant-form-item--column" :label="$t('label.requestType')">
            <a-select
              v-model:value="state.formSearch.requestTypes"
              mode="multiple"
              max-tag-count="responsive"
              :placeholder="$t('label.selectOptions')"
              option-filter-prop="label"
              :options="options.requestType"
            />
          </a-form-item>
          <a-form-item class="ant-form-item--column" :label="$t('label.requester')">
            <a-select
              v-model:value="state.formSearch.requesters"
              mode="multiple"
              max-tag-count="responsive"
              :placeholder="$t('label.selectOptions')"
              option-filter-prop="label"
              :options="options.userOptions"
            />
          </a-form-item>
          <div class="md:col-start-4 sm:col-start-2 flex justify-end items-center">
            <g-button type="primary" html-type="submit" class="w-24">
              {{ $t('label.search') }}
            </g-button>
          </div>
        </a-form>
      </div>
      <div class="bg-white p-4 rounded shadow-md">
        <g-table
          v-model:currentPage="state.formSearch.curentpage"
          v-model:pageSize="state.formSearch.pageSize"
          :row-key="({ requestID, subID }) => `${requestID}|${subID}`"
          class="table--header-center"
          :columns="createColumns(t)"
          :data-source="state.receivedRequestList"
          :row-selection="rowSelection"
          :total="state.total"
          :loading="state.loading"
          @pagination="getReceivedRequestList"
          @refresh-list="getReceivedRequestList(state.formSearch.curentpage)"
        >
          <template #requester="{ record: { requesterName, account } }">
            <span class="text-blue-600">
              {{ `${requesterName} (${account}) ` }}
            </span>
          </template>
          <template #requestType="{ text, record: { requestID, subID } }">
            <router-link
              class="text-blue-600 underline cursor-pointer router-link"
              :to="{ query: { ...state.formSearch, requestID, subID } }"
            >
              {{ text }}
            </router-link>
          </template>
          <template #leavingTime="{ record: { leaveFrom, leaveTo, partialDayName } }">
            {{ formatTimeRequest(leaveFrom, leaveTo, partialDayName) }}
          </template>
          <template #duration="{ record: { duration, requestTypeCode } }">
            {{ duration.toFixed(1) }}
            {{ displayDuration(t, duration, requestTypeCode) }}
          </template>
          <template #status="{ text, record: { requestStatusCode } }">
            <a-tag :color="getColorByStatus(requestStatusCode)" class="min-w-[90px]">
              {{ text }}
            </a-tag>
          </template>
          <template #action="{ record }">
            <a-space>
              <a-tooltip
                :title="isActiveApprove([record]) ? $t('label.approve') : $t('label.confirm')"
              >
                <g-button
                  :disabled="!isActiveActionApproveOrSubmit([record])"
                  @click="
                    handleSingleAction(
                      isActiveApprove([record]) ? 'approve' : 'confirm',
                      record.requestID,
                    )
                  "
                >
                  <template #icon>
                    <g-icon icon="check-outlined" class="text-xl !text-emerald-700" />
                  </template>
                </g-button>
              </a-tooltip>
              <a-tooltip :title="$t('label.reject')">
                <g-button
                  :disabled="!isActiveReject([record])"
                  @click="handleSingleAction('reject', record.requestID)"
                >
                  <template #icon>
                    <g-icon icon="close-outlined" class="text-lg !text-red-700" />
                  </template>
                </g-button>
              </a-tooltip>
            </a-space>
          </template>
        </g-table>
      </div>
      <received-request-detail
        v-model:visible="state.visibleModals.viewRequestModal"
        @handle-action="handleSingleAction"
      />
    </div>
  </transition>
</template>
<style lang="scss" scoped>
  .router-link:focus-visible {
    outline: -webkit-focus-ring-color auto 1px;
  }
</style>
