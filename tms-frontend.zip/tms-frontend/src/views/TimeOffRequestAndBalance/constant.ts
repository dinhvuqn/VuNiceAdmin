import type { ColumnProps } from 'ant-design-vue/es/table/Column';

export const createColumns = (t: Fn<string>): ColumnProps[] => [
  {
    title: t('label.requestType'),
    dataIndex: 'timeOffName',
    width: 400,
    key: 'requestName',
    slots: {
      customRender: 'requestName',
    },
  },
  {
    title: t('label.unit'),
    dataIndex: 'unitName',
    key: 'unitName',
    width: 120,
  },
  {
    title: t('label.maximumAllowed'),
    dataIndex: 'maximumAllowed',
    key: 'maximumAllowed',
    width: 150,
    align: 'right',
    slots: {
      customRender: 'maximumAllowed',
    },
  },
  {
    title: t('label.approvedQuotas'),
    dataIndex: 'approvedQuotas',
    key: 'approvedQuotas',
    width: 150,
    align: 'right',
    slots: {
      customRender: 'approvedQuotas',
    },
  },
  {
    title: t('label.remainingQuotas'),
    dataIndex: 'remainingQuotas',
    key: 'remainingQuotas',
    width: 150,
    align: 'right',
    slots: {
      customRender: 'remainingQuotas',
    },
  },
  {
    title: t('label.pendingQuotas'),
    dataIndex: 'pendingQuotas',
    key: 'pendingQuotas',
    width: 150,
    align: 'right',
    slots: {
      customRender: 'pendingQuotas',
    },
  },
  {
    title: t('label.remark'),
    dataIndex: 'remark',
    key: 'remark',
    width: 300,
    slots: {
      customRender: 'remark',
    },
  },
  {
    title: t('label.action'),
    dataIndex: 'action',
    key: 'action',
    width: 100,
    align: 'center',
    slots: {
      customRender: 'action',
    },
  },
];
