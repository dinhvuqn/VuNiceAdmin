<script setup lang="ts">
  import { IUserOptions } from '@/hooks/useSelectOption';
  import TimeOffLeaveService, { TFormClone } from '@/services/time-off-leave';
  import { displayName } from '@/utils';

  const props = defineProps<{
    visible: boolean;
    userOptions: IUserOptions[];
    searchParams: {
      staffID: string | undefined;
      year: string;
    };
  }>();

  const emit = defineEmits(['update:visible']);

  const showConfirmModal = inject<Fn<TConfirmConfig>>('showConfirmModal')!;
  const setIsLoading = inject<Fn<boolean>>('setIsLoading')!;
  const { t } = useI18n();

  const visible = computed({
    get() {
      return props.visible;
    },
    set(value) {
      emit('update:visible', value);
    },
  });

  const initFormClone = {
    fromStaffID: undefined,
    fromYear: '',
    toStaffID: undefined,
    toYear: '',
  };

  const state = reactive<{ formClone: TFormClone }>({
    formClone: { ...initFormClone },
  });

  const toStaffFullName = computed(() => {
    const staffOption = props.userOptions.find(({ value }) => value === state.formClone.toStaffID)!;

    const { firstName, lastName } = staffOption.userInfo || {};

    return displayName(firstName, lastName);
  });

  const handleSubmit = async () => {
    try {
      setIsLoading(true);

      const isExist = await TimeOffLeaveService.checkExistTimeOff(state.formClone);

      if (isExist) {
        return showConfirmModal({
          type: 'warning',
          width: 400,
          onOK: () => cloneTimeOff(),
          subTitle: t('message.W0006', [toStaffFullName.value, state.formClone.toYear]),
        });
      }

      cloneTimeOff();
    } finally {
      setIsLoading(false);
    }
  };

  const cloneTimeOff = async () => {
    try {
      setIsLoading(true);

      await TimeOffLeaveService.clone(state.formClone);

      visible.value = false;
      state.formClone = { ...initFormClone };
    } finally {
      setIsLoading(false);
    }
  };

  watch(visible, () => {
    if (visible) {
      state.formClone.fromStaffID = props.searchParams.staffID;
      state.formClone.fromYear = props.searchParams.year;
    }
  });
</script>

<i18n src="./locale" />

<template>
  <a-modal v-model:visible="visible" centered width="600px" :footer="false">
    <a-form :model="state.formClone" class="flex flex-col items-center" @finish="handleSubmit">
      <div class="flex w-full gap-4 items-center mb-2">
        <div class="flex-1 min-w-0">
          <a-form-item
            name="fromStaffID"
            class="ant-form-item--column required"
            :label="t('label.staff')"
            :rules="{ required: true, message: '' }"
          >
            <a-select
              v-model:value="state.formClone.fromStaffID"
              disabled
              show-search
              :placeholder="t('label.selectOptions')"
              :options="userOptions"
              option-filter-prop="label"
            />
          </a-form-item>
          <a-form-item
            name="fromYear"
            class="ant-form-item--column required"
            :label="t('label.year')"
          >
            <g-date-picker
              v-model:value="state.formClone.fromYear"
              disabled
              picker="year"
              :allow-clear="false"
            />
          </a-form-item>
        </div>
        <g-icon class="w-16 text-lg" icon="arrow-right-outline" />
        <div class="flex-1 min-w-0">
          <a-form-item
            name="toStaffID"
            class="ant-form-item--column required"
            :label="t('label.staff')"
            :rules="{ required: true, message: '' }"
          >
            <a-select
              v-model:value="state.formClone.toStaffID"
              show-search
              :placeholder="t('label.selectOptions')"
              :options="userOptions"
              option-filter-prop="label"
            />
          </a-form-item>
          <a-form-item
            name="toYear"
            class="ant-form-item--column required"
            :label="t('label.year')"
            :rules="{ required: true, message: '' }"
          >
            <g-date-picker
              v-model:value="state.formClone.toYear"
              picker="year"
              :allow-clear="false"
            />
          </a-form-item>
        </div>
      </div>
      <g-button type="warning" html-type="submit" class="w-24 mx-auto">
        {{ t('label.clone') }}
      </g-button>
    </a-form>
  </a-modal>
</template>
