<script setup lang="ts">
  import moment from 'moment';
  import SelectOptionEnum from '@/enums/selectOptionEnum';
  import { useSelectOptions } from '@/hooks/useSelectOption';
  import { createColumns } from './constant';
  import TimeOffLeaveService, { TSearch, TTimeOffLeave } from '@/services/time-off-leave';
  import { cloneDeep } from 'lodash-es';
  import CloneTimeOffModal from './CloneTimeOffModal.vue';
  import { useNotification } from '@/hooks/useNotification';
  import { displayName, getMaxValueInputByUnitCode } from '@/utils';

  const { t } = useI18n();

  const options = useSelectOptions([SelectOptionEnum.USER, SelectOptionEnum.OFF_UNIT]);
  const setIsLoading = inject<Fn<boolean>>('setIsLoading')!;
  const { createNotification } = useNotification();

  type TEditableTimeOffLeave = TTimeOffLeave & { isEditting?: boolean; isInValid?: boolean };

  type TState = {
    formSearch: TSearch;
    searchParams: TSearch;
    loading: boolean;
    originalTimeOffLeave: TTimeOffLeave[];
    timeOffLeave: TEditableTimeOffLeave[];
    visibleCloneModal: boolean;
  };

  const state = reactive<TState>({
    formSearch: {
      staffID: undefined,
      year: moment().year().toString(),
    },
    searchParams: {
      staffID: undefined,
      year: moment().year().toString(),
    },
    loading: false,
    originalTimeOffLeave: [],
    timeOffLeave: [],
    visibleCloneModal: false,
  });

  const staffFullName = computed(() => {
    const staffOption = options.value.userOptions.find(
      ({ value }) => value === state.searchParams.staffID,
    )!;

    const { firstName, lastName } = staffOption?.userInfo || {};

    return displayName(firstName, lastName);
  });

  const cloneFromMasterData = async () => {
    try {
      state.loading = true;

      await TimeOffLeaveService.cloneFromMasterData(state.formSearch);
      fetchTimeOffLeave();
    } finally {
      state.loading = false;
    }
  };

  const refreshList = () => {
    if (!state.searchParams.staffID) return;

    fetchTimeOffLeave();
  };

  const fetchTimeOffLeave = async () => {
    try {
      state.loading = true;

      state.originalTimeOffLeave = await TimeOffLeaveService.getList(state.formSearch);

      state.timeOffLeave = cloneDeep(state.originalTimeOffLeave);
    } finally {
      state.searchParams = { ...state.formSearch };
      state.loading = false;
    }
  };

  const updateTimeOffLeave = async (index: number) => {
    try {
      setIsLoading(true);

      const { messageId, params } = await TimeOffLeaveService.update(state.timeOffLeave[index]);

      state.originalTimeOffLeave[index] = cloneDeep(state.timeOffLeave[index]);
      state.timeOffLeave[index].isEditting = false;

      createNotification('success', t(`message.${messageId}`, [t(`params.${params}`)]));
    } catch {
      state.timeOffLeave[index].isInValid = true;
    } finally {
      setIsLoading(false);
    }
  };

  const firstInputRefs = ref<HTMLElement[]>([]);

  const edit = (index: number) => {
    state.timeOffLeave[index].isEditting = true;

    nextTick(() => {
      firstInputRefs.value[index].focus();
    });
  };

  const cancelEdit = (index: number) => {
    state.timeOffLeave[index] = cloneDeep(state.originalTimeOffLeave[index]);
    state.timeOffLeave[index].isEditting = false;
  };
</script>

<i18n src="./locale" />

<template>
  <div>
    <g-top-content>
      <g-button
        type="secondary"
        class="mr-2"
        :disabled="!state.searchParams.staffID"
        @click="cloneFromMasterData"
      >
        {{ t('label.cloneFromMasterData') }}
      </g-button>
      <g-button
        type="warning"
        :disabled="state.originalTimeOffLeave.length === 0"
        @click="state.visibleCloneModal = true"
      >
        {{ t('label.clone') }}
      </g-button>
    </g-top-content>
    <transition name="fade-slide" mode="out-in" appear>
      <div class="my-report-page m-4">
        <div class="bg-white mb-4 p-4 rounded shadow-md">
          <a-form
            :model="state.formSearch"
            class="grid md:grid-cols-4 sm:grid-cols-2 gap-x-4"
            @finish="fetchTimeOffLeave"
          >
            <a-form-item
              name="staffID"
              class="ant-form-item--column required"
              :label="t('label.staff')"
              :rules="{ required: true, message: '' }"
            >
              <a-select
                v-model:value="state.formSearch.staffID"
                show-search
                :placeholder="t('label.selectOptions')"
                :options="options.userOptions"
                option-filter-prop="label"
              />
            </a-form-item>
            <a-form-item name="year" class="ant-form-item--column" :label="t('label.year')">
              <g-date-picker
                v-model:value="state.formSearch.year"
                picker="year"
                :allow-clear="false"
              />
            </a-form-item>
            <div class="md:col-start-4 sm:col-start-2 flex justify-end items-center">
              <g-button type="primary" html-type="submit" class="w-24">
                {{ t('label.search') }}
              </g-button>
            </div>
          </a-form>
        </div>
        <div class="bg-white rounded shadow-md p-4">
          <div v-if="state.searchParams.staffID" class="text-base flex font-medium mb-3">
            <i18n-t tag="div" keypath="label.title">
              {{ state.searchParams.year }}
              <span class="text-blue-500">{{ staffFullName }}</span>
            </i18n-t>
          </div>
          <g-table
            class="table--header-center"
            :data-source="state.timeOffLeave"
            :columns="createColumns(t)"
            :loading="state.loading"
            :pagination="false"
            @refresh-list="refreshList"
          >
            <template #requestName="{ text, record }">
              <a v-if="record.isDetail" class="flex items-center">
                <span class="mr-1">{{ text }}</span>
                <g-icon icon="question-circle-filled" />
              </a>
              <div v-else>{{ text }}</div>
            </template>

            <template #maximumAllowed="{ text, record, index }">
              <a-form-item
                name="maximumAllowed"
                class="!mb-0"
                :class="{ 'ant-form-item-has-error': record.isInValid }"
              >
                <a-input-number
                  v-if="record.isEditting"
                  v-model:value="record.maximumAllowed"
                  min="0"
                  :max="getMaxValueInputByUnitCode(record.unitCode)"
                  :ref="(el: HTMLElement) => firstInputRefs[index] = el"
                  @keyup.esc="cancelEdit(index)"
                  @change="record.isInValid = false"
                />
                <div v-else>{{ text }}</div>
              </a-form-item>
            </template>

            <template #remainingQuotas="{ text, record, index }">
              <a-form-item
                name="remainingQuotas"
                class="!mb-0"
                :class="{ 'ant-form-item-has-error': record.isInValid }"
              >
                <a-input-number
                  v-if="record.isEditting"
                  v-model:value="record.remainingQuotas"
                  min="0"
                  :max="getMaxValueInputByUnitCode(record.unitCode)"
                  @keyup.esc="cancelEdit(index)"
                  @change="record.isInValid = false"
                />
                <div v-else>{{ text }}</div>
              </a-form-item>
            </template>

            <template #remark="{ text, record, index }">
              <a-form-item name="remark" class="!mb-0">
                <a-input
                  v-if="record.isEditting"
                  v-model:value="record.remark"
                  :maxlength="255"
                  type="text"
                  @keyup.esc="cancelEdit(index)"
                />
                <div v-else>{{ text }}</div>
              </a-form-item>
            </template>

            <template #action="{ index, record }">
              <a-space size="large" style="gap: 10px">
                <a-tooltip v-if="!record.isEditting" :title="t('label.edit')">
                  <g-button @click="edit(index)">
                    <template #icon>
                      <g-icon icon="edit-outlined" class="text-xl !text-sky-700" />
                    </template>
                  </g-button>
                </a-tooltip>
                <template v-else>
                  <a-tooltip :title="t('label.save')">
                    <g-button @click="updateTimeOffLeave(index)">
                      <template #icon>
                        <g-icon icon="save-outlined" class="text-lg !text-emerald-700" />
                      </template>
                    </g-button>
                  </a-tooltip>
                  <a-tooltip :title="t('label.cancel')">
                    <g-button @click="cancelEdit(index)">
                      <template #icon>
                        <g-icon icon="minus-circle-outlined" class="text-lg !text-red-700" />
                      </template>
                    </g-button>
                  </a-tooltip>
                </template>
              </a-space>
            </template>
          </g-table>
        </div>
      </div>
    </transition>
    <clone-time-off-modal
      v-model:visible="state.visibleCloneModal"
      :user-options="options.userOptions"
      :search-params="state.searchParams"
    />
  </div>
</template>

<style lang="scss" scoped>
  :deep .ant-select {
    width: 100%;
  }
</style>
