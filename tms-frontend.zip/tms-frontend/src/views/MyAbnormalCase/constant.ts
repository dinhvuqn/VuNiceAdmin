import type { ColumnProps } from 'ant-design-vue/es/table/Column';

export const columns: ColumnProps[] = [];
