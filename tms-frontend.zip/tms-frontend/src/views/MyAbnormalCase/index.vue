<script setup lang="ts"></script>

<template>...MyAbnormalCase</template>
