<script setup lang="ts"></script>

<template>
  <div>ReceivedDelegation here...</div>
</template>
