<script setup lang="ts">
  import TimeOffGenerateService, { TTimeOffGenerate } from '@/services/request-type';
  import { useSelectOptions } from '@/hooks/useSelectOption';
  import { useNotification } from '@/hooks/useNotification';
  import SelectOptionEnum from '@/enums/selectOptionEnum';
  import { cloneDeep } from 'lodash-es';
  import { createColumns } from './constant';
  import { getMaxValueInputByUnitCode } from '@/utils';

  const { t } = useI18n();

  const options = useSelectOptions([
    SelectOptionEnum.USER,
    SelectOptionEnum.OFF_UNIT,
    SelectOptionEnum.REQUEST_TYPE,
  ]);

  const setIsLoading = inject<Fn<boolean>>('setIsLoading')!;
  const { createNotification } = useNotification();
  const showConfirmModal = inject<Fn<TConfirmConfig>>('showConfirmModal')!;

  type TEditableTimeOffGenerate = TTimeOffGenerate & {
    isEditting?: boolean;
    isAddNew?: boolean;
    isMaximumAllowed?: boolean;
    isMaximumPerlog?: boolean;
    oldmaximumAllowed?: number | undefined;
    oldmaximumPerLog?: number | undefined;
  };

  type TState = {
    loading: boolean;
    originalTimeOffGenerate: TTimeOffGenerate[];
    timeOffGenerate: TEditableTimeOffGenerate[];
    errors: Recordable<{
      timeOffCode?: boolean;
      maximumAllowed?: boolean;
      maximumPerLog?: boolean;
    }>;
    displayError: boolean;
  };

  const state = reactive<TState>({
    loading: false,
    originalTimeOffGenerate: [],
    timeOffGenerate: [],
    errors: {},
    displayError: true,
  });

  const requestTypeOptions = computed(() => {
    return options.value.requestType.filter(({ value }) => {
      const requestType = state.timeOffGenerate.find(({ timeOffCode }) => timeOffCode === value);

      return !requestType || requestType.isAddNew;
    });
  });

  const fetchTimeOffGenerate = async () => {
    try {
      state.loading = true;

      state.originalTimeOffGenerate = await TimeOffGenerateService.getList();

      state.timeOffGenerate = cloneDeep(state.originalTimeOffGenerate);
    } finally {
      state.loading = false;
    }
  };

  const validate = (index: number) => {
    const { timeOffCode, limitedByYear, maximumAllowed, maximumPerLog } =
      state.timeOffGenerate[index];
    if (limitedByYear == true) {
      state.errors[timeOffCode || 'create'] = {
        timeOffCode: !timeOffCode,
        maximumAllowed: maximumAllowed == 0 ? false : !maximumAllowed,
        maximumPerLog: false,
      };
      return Boolean(timeOffCode && maximumAllowed == 0 ? true : maximumAllowed);
    } else {
      state.errors[timeOffCode || 'create'] = {
        timeOffCode: !timeOffCode,
        maximumAllowed: false,
        maximumPerLog: maximumPerLog == 0 ? false : !maximumPerLog,
      };
      return Boolean(timeOffCode && maximumPerLog == 0 ? true : maximumPerLog);
    }
  };

  const updateOrInsertTimeOffGenerate = async (index: number) => {
    try {
      if (!validate(index)) {
        state.displayError = true;
        return;
      }
      setIsLoading(true);

      const timeOffGenerateData = state.timeOffGenerate[index];
      const method = timeOffGenerateData.isAddNew ? 'create' : 'update';

      const { messageId, params } = await TimeOffGenerateService[method](timeOffGenerateData);
      createNotification('success', t(`message.${messageId}`, [t(`params.${params}`)]));

      if (method === 'create') {
        fetchTimeOffGenerate();
      } else {
        state.timeOffGenerate[index].isEditting = false;
        state.originalTimeOffGenerate[index] = cloneDeep(state.timeOffGenerate[index]);
      }
      state.timeOffGenerate[index].oldmaximumPerLog = undefined;
      state.timeOffGenerate[index].oldmaximumAllowed = undefined;
    } finally {
      setIsLoading(false);
    }
  };

  const deleteRequestType = async (index: number) => {
    try {
      setIsLoading(true);

      const { messageId, params } = await TimeOffGenerateService.remove(
        state.timeOffGenerate[index].timeOffCode!,
      );
      createNotification('success', t(`message.${messageId}`, [t(`params.${params}`)]));

      fetchTimeOffGenerate();
    } finally {
      setIsLoading(false);
    }
  };

  const firstInputRefs = ref<HTMLElement[]>([]);

  const disabledAddNewBtn = computed(() => state.timeOffGenerate.some(({ isAddNew }) => isAddNew));

  const addNew = () => {
    state.errors = {};
    const initTimeOffGenerate: TEditableTimeOffGenerate = {
      timeOffName: '',
      timeOffNameEN: '',
      timeOffNameJP: '',
      unitCode: 10,
      unitName: '',
      limitedByYear: false,
      paidLeave: false,
      maximumAllowed: undefined,
      maximumPerLog: undefined,
      timeOffCode: undefined,
      isEditting: true,
      isAddNew: true,
      isMaximumAllowed: false,
      isMaximumPerlog: true,
      oldmaximumAllowed: undefined,
      oldmaximumPerLog: undefined,
    };

    state.timeOffGenerate.unshift(initTimeOffGenerate);
    state.originalTimeOffGenerate.unshift(initTimeOffGenerate);

    nextTick(() => {
      firstInputRefs.value[0].focus();
    });
  };

  const edit = (index: number) => {
    state.timeOffGenerate[index].isEditting = true;
    if (state.timeOffGenerate[index].limitedByYear == true) {
      state.timeOffGenerate[index].isMaximumAllowed = true;
      state.timeOffGenerate[index].isMaximumPerlog = false;
    } else {
      state.timeOffGenerate[index].isMaximumAllowed = false;
      state.timeOffGenerate[index].isMaximumPerlog = true;
    }

    nextTick(() => {
      firstInputRefs.value[index].focus();
    });
  };

  const cancelEdit = (index: number) => {
    if (state.timeOffGenerate[index].isAddNew) {
      state.timeOffGenerate.shift();
      state.originalTimeOffGenerate.shift();

      return;
    }

    state.timeOffGenerate[index] = cloneDeep(state.originalTimeOffGenerate[index]);
  };

  const handleDelete = (index: number) => {
    showConfirmModal({
      type: 'warning',
      subTitle: t('message.confirmDelete'),
      onOK: () => deleteRequestType(index),
    });
  };

  fetchTimeOffGenerate();
  const changeLimitByYear = (index: number) => {
    if (state.timeOffGenerate[index].limitedByYear) {
      state.timeOffGenerate[index].isMaximumAllowed = true;
      state.timeOffGenerate[index].isMaximumPerlog = false;
      state.timeOffGenerate[index].oldmaximumPerLog = state.timeOffGenerate[index].maximumPerLog;
      state.timeOffGenerate[index].maximumAllowed = state.timeOffGenerate[index].oldmaximumAllowed;
      state.timeOffGenerate[index].maximumPerLog = undefined;
      state.displayError = false;
    } else {
      state.timeOffGenerate[index].isMaximumAllowed = false;
      state.timeOffGenerate[index].isMaximumPerlog = true;
      state.timeOffGenerate[index].oldmaximumAllowed = state.timeOffGenerate[index].maximumAllowed;
      state.timeOffGenerate[index].maximumPerLog = state.timeOffGenerate[index].oldmaximumPerLog;
      state.timeOffGenerate[index].maximumAllowed = undefined;
      state.displayError = false;
    }
  };
</script>

<i18n src="./locale" />

<template>
  <div class="flex flex-col h-full">
    <g-top-content>
      <g-button :disabled="disabledAddNewBtn" type="secondary" @click="addNew">
        {{ t('label.addNew') }}
      </g-button>
    </g-top-content>
    <transition name="fade-slide" mode="out-in" appear>
      <div class="my-report-page m-4 flex-1 min-h-0">
        <div
          class="bg-white rounded shadow-md p-4"
          :class="{ 'min-h-full': state.timeOffGenerate.length > 0 }"
        >
          <g-table
            class="table--header-center"
            :data-source="state.timeOffGenerate"
            :columns="createColumns(t)"
            :loading="state.loading"
            :pagination="false"
            :scroll="{ y: 685, x: 1000 }"
            @refresh-list="fetchTimeOffGenerate"
          >
            <template #timeOffName="{ record, text }">
              <a-form-item
                class="!mb-0"
                :class="{
                  'ant-form-item-has-error':
                    state.errors[record.timeOffCode || 'create']?.timeOffCode,
                }"
              >
                <a-select
                  v-if="record.isAddNew"
                  v-model:value="record.timeOffCode"
                  show-search
                  option-filter-prop="label"
                  :ref="(el: HTMLElement) => firstInputRefs[0] = el"
                  :placeholder="$t('label.selectOptions')"
                  :options="requestTypeOptions"
                  @change=" (_, { label }: any) => record.timeOffName = label"
                />
                <div v-else class="text-left">{{ text }}</div>
              </a-form-item>
            </template>

            <template #unit="{ record, text, index }">
              <a-select
                v-if="record.isEditting"
                v-model:value="record.unitCode"
                :default-value="10"
                :options="options.offUnit"
                :ref="(el: HTMLElement) => {
                  if (!record.isAddNew) {
                    firstInputRefs[index] = el
                  }
                }"
                @change=" (_, { label }: any) => record.unitName = label"
              />
              <div v-else class="text-left">{{ text }}</div>
            </template>

            <template #limitedByYear="{ record, index }">
              <a-checkbox
                v-model:checked="record.limitedByYear"
                @change="changeLimitByYear(index)"
                :disabled="!record.isEditting"
              />
            </template>

            <template #paidLeave="{ record }">
              <a-checkbox v-model:checked="record.paidLeave" :disabled="!record.isEditting" />
            </template>

            <template #maximumAllowed="{ text, record, index }">
              <a-form-item
                name="maximumAllowed"
                class="!mb-0"
                :class="{
                  'ant-form-item-has-error':
                    state.errors[record.timeOffCode || 'create']?.maximumAllowed &&
                    state.displayError,
                }"
              >
                <a-input-number
                  v-if="record.isEditting && record.isMaximumAllowed"
                  v-model:value="record.maximumAllowed"
                  min="0"
                  :max="getMaxValueInputByUnitCode(record.unitCode)"
                  @keyup.esc="cancelEdit(index)"
                />
                <div v-else>{{ text }}</div>
              </a-form-item>
            </template>

            <template #maximumPerLog="{ text, record, index }">
              <a-form-item
                name="maximumPerLog"
                class="!mb-0"
                :class="{
                  'ant-form-item-has-error':
                    state.errors[record.timeOffCode || 'create']?.maximumPerLog &&
                    state.displayError,
                }"
              >
                <a-input-number
                  v-if="record.isEditting && record.isMaximumPerlog"
                  v-model:value="record.maximumPerLog"
                  min="0"
                  :max="getMaxValueInputByUnitCode(record.unitCode)"
                  @keyup.esc="cancelEdit(index)"
                />
                <div v-else>{{ text }}</div>
              </a-form-item>
            </template>

            <template #action="{ index, record }">
              <a-space size="large" style="gap: 10px">
                <a-tooltip v-if="!record.isEditting" :title="t('label.edit')">
                  <g-button @click="edit(index)">
                    <template #icon>
                      <g-icon icon="edit-outlined" class="text-xl !text-sky-700" />
                    </template>
                  </g-button>
                </a-tooltip>
                <a-tooltip v-if="!record.isEditting" :title="t('label.delete')">
                  <g-button @click="handleDelete(index)">
                    <template #icon>
                      <g-icon icon="delete-outlined" class="text-xl !text-red-600" />
                    </template>
                  </g-button>
                </a-tooltip>
                <template v-else>
                  <a-tooltip :title="t('label.save')">
                    <g-button @click="updateOrInsertTimeOffGenerate(index)">
                      <template #icon>
                        <g-icon icon="save-outlined" class="text-lg !text-emerald-700" />
                      </template>
                    </g-button>
                  </a-tooltip>
                  <a-tooltip :title="t('label.cancel')">
                    <g-button @click="cancelEdit(index)">
                      <template #icon>
                        <g-icon icon="minus-circle-outlined" class="text-lg !text-red-700" />
                      </template>
                    </g-button>
                  </a-tooltip>
                </template>
              </a-space>
            </template>
          </g-table>
        </div>
      </div>
    </transition>
  </div>
</template>

<style lang="scss" scoped>
  :deep .ant-select {
    width: 100%;
  }
</style>
