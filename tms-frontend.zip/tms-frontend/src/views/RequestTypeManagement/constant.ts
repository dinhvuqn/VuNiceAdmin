import type { ColumnProps } from 'ant-design-vue/es/table/Column';

export const createColumns = (t: Fn<string>): ColumnProps[] => [
  {
    title: t('label.requestType'),
    dataIndex: 'timeOffName',
    width: 350,
    key: 'timeOffName',
    slots: {
      customRender: 'timeOffName',
    },
  },
  {
    title: t('label.unit'),
    dataIndex: 'unitName',
    key: 'unitName',
    width: 110,
    slots: {
      customRender: 'unit',
    },
  },
  {
    title: t('label.limitedByYear'),
    dataIndex: 'limitedByYear',
    key: 'limitedByYear',
    width: 150,
    align: 'center',
    slots: {
      customRender: 'limitedByYear',
    },
  },
  {
    title: t('label.paidLeave'),
    dataIndex: 'paidLeave',
    key: 'paidLeave',
    width: 150,
    align: 'center',
    slots: {
      customRender: 'paidLeave',
    },
  },
  {
    title: t('label.maximumAllowed'),
    dataIndex: 'maximumAllowed',
    key: 'maximumAllowed',
    width: 150,
    align: 'right',
    slots: {
      customRender: 'maximumAllowed',
    },
  },
  {
    title: t('label.maximumPerLog'),
    dataIndex: 'maximumPerLog',
    key: 'maximumPerLog',
    width: 150,
    align: 'right',
    slots: {
      customRender: 'maximumPerLog',
    },
  },
  {
    title: t('label.action'),
    dataIndex: 'action',
    key: 'action',
    width: 100,
    align: 'center',
    slots: {
      customRender: 'action',
    },
  },
];
