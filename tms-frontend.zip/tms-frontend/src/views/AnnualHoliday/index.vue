<script setup lang="ts">
  import moment from 'moment';
  import SelectOptionEnum from '@/enums/selectOptionEnum';
  import { useSelectOptions } from '@/hooks/useSelectOption';
  import { createColumns } from './constant';
  import { cloneDeep } from 'lodash-es';
  import AnnualHolidayService, { TSearch, TAnnualHoliday } from '@/services/annual-holiday';
  import CloneAnnualHolidayModal from './CloneAnnualHolidayModal.vue';
  import { Ref } from 'vue';
  import { VIETNAM } from '@/constants/countries';
  import { useNotification } from '@/hooks/useNotification';
  import { formatToDate, getFirstWorkDateOfYear } from '@/utils/dateUtil';

  const { t } = useI18n();

  const options = useSelectOptions([SelectOptionEnum.COUNTRY]);
  const setIsLoading = inject<Fn<boolean>>('setIsLoading')!;
  const showConfirmModal = inject<Fn<TConfirmConfig>>('showConfirmModal')!;
  const { createNotification } = useNotification();
  type TEditableAnnualHoliday = TAnnualHoliday & { isEditting?: boolean };

  type TState = {
    formSearch: TSearch;
    searchParams: TSearch;
    loading: boolean;
    originalAnnualHoliday: TAnnualHoliday[];
    annualHoliday: TEditableAnnualHoliday[];
    visibleCloneModal: boolean;
    errors: Recordable<{ holidayName?: boolean; holidayDate?: boolean }>;
  };

  const state = reactive<TState>({
    formSearch: {
      country: VIETNAM,
      year: moment().year().toString(),
    },
    searchParams: {
      country: undefined,
      year: moment().year().toString(),
    },
    loading: false,
    originalAnnualHoliday: [],
    annualHoliday: [],
    visibleCloneModal: false,
    errors: {},
  });

  const countryName = computed(
    () => options.value.country?.find(({ value }) => value === state.searchParams.country)?.label,
  );

  const refreshList = () => {
    if (!state.searchParams.country) return;

    fetchAnnualHoliday();
  };

  const fetchAnnualHoliday = async () => {
    try {
      state.errors = {};
      state.loading = true;

      state.originalAnnualHoliday = await AnnualHolidayService.getList(state.formSearch);

      state.annualHoliday = cloneDeep(state.originalAnnualHoliday);
    } finally {
      state.searchParams = { ...state.formSearch };
      state.loading = false;
    }
  };

  const validate = (index: number) => {
    const { holidayName, holidayDate, holidayID } = state.annualHoliday[index];

    state.errors[holidayID || 'create'] = {
      holidayName: !holidayName,
      holidayDate: !holidayDate,
    };

    return Boolean(holidayName && holidayDate);
  };

  const validateFiled = (index: number, field: 'holidayName' | 'holidayDate') => {
    const { holidayID } = state.annualHoliday[index];
    const fieldValue = state.annualHoliday[index][field];

    if (!state.errors[holidayID || 'create']) {
      state.errors[holidayID || 'create'] = {};
    }

    state.errors[holidayID || 'create'][field] = !fieldValue;

    return Boolean(fieldValue);
  };

  const updateOrInsertHoliday = async (index: number) => {
    try {
      if (!validate(index)) return;

      setIsLoading(true);

      const hodidayData = state.annualHoliday[index];
      const method = hodidayData.holidayID ? 'update' : 'create';

      const { messageId, params } = await AnnualHolidayService[method](hodidayData);
      createNotification('success', t(`message.${messageId}`, [t(`params.${params}`)]));

      if (method === 'create') {
        fetchAnnualHoliday();
      } else {
        state.annualHoliday[index].isEditting = false;
        state.originalAnnualHoliday[index] = cloneDeep(state.annualHoliday[index]);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const deleteHoliday = async (index: number) => {
    try {
      setIsLoading(true);

      const { messageId, params } = await AnnualHolidayService.remove(
        state.annualHoliday[index].holidayID!,
      );
      createNotification('success', t(`message.${messageId}`, [t(`params.${params}`)]));
      fetchAnnualHoliday();
    } finally {
      setIsLoading(false);
    }
  };

  const firstInputRefs = ref<Ref<TPickerEvent>[]>([]);

  const disabledAddNewBtn = computed(
    () => !state.searchParams.country || state.annualHoliday.some(({ holidayID }) => !holidayID),
  );

  const addNew = () => {
    state.errors = {};

    const initHoliday = {
      countryCode: state.searchParams.country,
      countryName: '',
      holidayDate: formatToDate(getFirstWorkDateOfYear(state.searchParams.year)),
      holidayName: '',
      holidayForeignName: '',
      holidayID: undefined,
      isEditting: true,
    };

    state.annualHoliday.unshift(initHoliday);
    state.originalAnnualHoliday.unshift(initHoliday);

    nextTick(() => {
      firstInputRefs.value[0].value.focus();
    });
  };

  const edit = (index: number) => {
    state.annualHoliday[index].isEditting = true;

    nextTick(() => {
      firstInputRefs.value[index].value.focus();
    });
  };

  const cancelEdit = (index: number) => {
    if (!state.annualHoliday[index].holidayID) {
      state.annualHoliday.shift();
      state.originalAnnualHoliday.shift();

      return;
    }

    state.annualHoliday[index] = cloneDeep(state.originalAnnualHoliday[index]);
    state.annualHoliday[index].isEditting = false;
    state.errors[state.annualHoliday[index].holidayID || 'create'] = {};
  };

  const handleDelete = (index: number) => {
    showConfirmModal({
      type: 'warning',
      subTitle: t('message.confirmDelete'),
      onOK: () => deleteHoliday(index),
    });
  };

  onMounted(() => {
    fetchAnnualHoliday();
  });
</script>

<i18n src="./locale" />

<template>
  <div>
    <g-top-content>
      <a-space>
        <g-button :disabled="disabledAddNewBtn" type="secondary" @click="addNew">
          {{ t('label.addNew') }}
        </g-button>
        <g-button
          type="warning"
          :disabled="state.originalAnnualHoliday.length === 0"
          @click="state.visibleCloneModal = true"
        >
          {{ t('label.clone') }}
        </g-button>
      </a-space>
    </g-top-content>
    <transition name="fade-slide" mode="out-in" appear>
      <div class="my-report-page m-4">
        <div class="bg-white mb-4 p-4 rounded shadow-md">
          <a-form
            :model="state.formSearch"
            class="grid md:grid-cols-4 sm:grid-cols-2 gap-x-4"
            @finish="fetchAnnualHoliday"
          >
            <a-form-item
              name="country"
              class="ant-form-item--column required"
              :label="t('label.country')"
              :rules="{ required: true, message: '' }"
            >
              <a-select
                v-model:value="state.formSearch.country"
                show-search
                :placeholder="t('label.selectOptions')"
                :options="options.country"
                option-filter-prop="label"
              />
            </a-form-item>
            <a-form-item name="year" class="ant-form-item--column" :label="t('label.year')">
              <g-date-picker
                v-model:value="state.formSearch.year"
                picker="year"
                :allow-clear="false"
              />
            </a-form-item>
            <div class="md:col-start-4 sm:col-start-2 flex justify-end items-center">
              <g-button type="primary" html-type="submit" class="w-24">
                {{ t('label.search') }}
              </g-button>
            </div>
          </a-form>
        </div>
        <div class="bg-white rounded shadow-md p-4">
          <div v-if="state.searchParams.country" class="text-base flex font-medium mb-3">
            <i18n-t tag="div" keypath="label.title">
              {{ state.searchParams.year }}
              <span class="text-blue-500">{{ countryName }}</span>
            </i18n-t>
          </div>
          <g-table
            class="table--header-center"
            :data-source="state.annualHoliday"
            :columns="createColumns(t)"
            :loading="state.loading"
            :pagination="false"
            @refresh-list="refreshList"
          >
            <template #holidayDate="{ record, text, index }">
              <a-form-item
                class="!mb-0"
                :class="{
                  'ant-form-item-has-error':
                    state.errors[record.holidayID || 'create']?.holidayDate,
                }"
              >
                <g-date-picker
                  v-if="record.isEditting"
                  v-model:value="record.holidayDate"
                  :ref="(el: Ref<TPickerEvent>) => (firstInputRefs[index] = el)"
                  :disabled-date-range="{
                    min: moment(state.searchParams.year).startOf('year'),
                    max: moment(state.searchParams.year).endOf('year'),
                  }"
                  @change="validateFiled(index, 'holidayDate')"
                />
                <div v-else>{{ text }}</div>
              </a-form-item>
            </template>

            <template #holidayName="{ text, record, index }">
              <a-form-item
                class="!mb-0"
                :class="{
                  'ant-form-item-has-error':
                    state.errors[record.holidayID || 'create']?.holidayName,
                }"
              >
                <a-input
                  v-if="record.isEditting"
                  v-model:value="record.holidayName"
                  @keyup.esc="cancelEdit(index)"
                  @change="validateFiled(index, 'holidayName')"
                />
                <div v-else>{{ text }}</div>
              </a-form-item>
            </template>

            <template #foreignName="{ text, record, index }">
              <a-input
                v-if="record.isEditting"
                v-model:value="record.holidayForeignName"
                @keyup.esc="cancelEdit(index)"
              />
              <div v-else>{{ text }}</div>
            </template>

            <template #action="{ index, record }">
              <a-space size="large" style="gap: 10px">
                <template v-if="!record.isEditting">
                  <a-tooltip v-if="!record.isEditting" :title="t('label.edit')">
                    <g-button @click="edit(index)">
                      <template #icon>
                        <g-icon icon="edit-outlined" class="text-xl !text-sky-700" />
                      </template>
                    </g-button>
                  </a-tooltip>
                  <a-tooltip v-if="!record.isEditting" :title="t('label.delete')">
                    <g-button @click="handleDelete(index)">
                      <template #icon>
                        <g-icon icon="delete-outlined" class="text-xl !text-red-600" />
                      </template>
                    </g-button>
                  </a-tooltip>
                </template>

                <template v-else>
                  <a-tooltip :title="t('label.save')">
                    <g-button @click="updateOrInsertHoliday(index)">
                      <template #icon>
                        <g-icon icon="save-outlined" class="text-lg !text-emerald-700" />
                      </template>
                    </g-button>
                  </a-tooltip>
                  <a-tooltip :title="t('label.cancel')">
                    <g-button @click="cancelEdit(index)">
                      <template #icon>
                        <g-icon icon="minus-circle-outlined" class="text-lg !text-red-700" />
                      </template>
                    </g-button>
                  </a-tooltip>
                </template>
              </a-space>
            </template>
          </g-table>
        </div>
      </div>
    </transition>
    <clone-annual-holiday-modal
      v-model:visible="state.visibleCloneModal"
      :country-options="options.country"
      :search-params="state.searchParams"
    />
  </div>
</template>
