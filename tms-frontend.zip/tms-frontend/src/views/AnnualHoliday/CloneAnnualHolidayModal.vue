<script setup lang="ts">
  import AnnualHolidayService, { TFormClone, TSearch } from '@/services/annual-holiday';

  const props = defineProps<{
    visible: boolean;
    countryOptions: IOptions;
    searchParams: TSearch;
  }>();

  const emit = defineEmits(['update:visible']);

  const showConfirmModal = inject<Fn<TConfirmConfig>>('showConfirmModal')!;
  const setIsLoading = inject<Fn<boolean>>('setIsLoading')!;
  const { t } = useI18n();

  const visible = computed({
    get() {
      return props.visible;
    },
    set(value) {
      emit('update:visible', value);
    },
  });

  const initFormClone = {
    fromYear: '',
    toYear: '',
    country: undefined,
  };

  const state = reactive<{ formClone: TFormClone }>({
    formClone: { ...initFormClone },
  });

  const countryInfo = computed(() =>
    props.countryOptions.find(({ value }) => value === state.formClone.country),
  );

  const handleSubmit = async () => {
    try {
      setIsLoading(true);

      const isExist = await AnnualHolidayService.checkExistHoliday(state.formClone);

      if (isExist) {
        return showConfirmModal({
          type: 'warning',
          width: 450,
          onOK: () => cloneAnnualHoliday(),
          subTitle: t('message.W0007', [state.formClone.toYear, countryInfo.value?.label]),
        });
      }

      cloneAnnualHoliday();
    } finally {
      setIsLoading(false);
    }
  };

  const cloneAnnualHoliday = async () => {
    try {
      setIsLoading(true);

      await AnnualHolidayService.clone(state.formClone);

      visible.value = false;
      state.formClone = { ...initFormClone };
    } finally {
      setIsLoading(false);
    }
  };

  watch(visible, () => {
    if (visible) {
      state.formClone.fromYear = props.searchParams.year;
      state.formClone.country = props.searchParams.country;
    }
  });
</script>

<i18n src="./locale" />

<template>
  <a-modal v-model:visible="visible" centered width="600px" :footer="false">
    <a-form :model="state.formClone" class="flex flex-col items-center" @finish="handleSubmit">
      <div class="flex w-full gap-4 items-center mb-2">
        <div class="flex-1 min-w-0">
          <a-form-item
            name="fromCountry"
            class="ant-form-item--column required"
            :label="t('label.country')"
          >
            <a-select
              :value="state.formClone.country"
              disabled
              show-search
              :placeholder="t('label.selectOptions')"
              :options="countryOptions"
              option-filter-prop="label"
            />
          </a-form-item>
          <a-form-item
            name="fromYear"
            class="ant-form-item--column required"
            :label="t('label.year')"
          >
            <g-date-picker
              v-model:value="state.formClone.fromYear"
              disabled
              picker="year"
              :allow-clear="false"
            />
          </a-form-item>
        </div>
        <g-icon class="w-16 text-lg" icon="arrow-right-outline" />
        <div class="flex-1 min-w-0">
          <a-form-item
            name="toCountry"
            class="ant-form-item--column required"
            :label="t('label.country')"
          >
            <a-select
              :value="state.formClone.country"
              disabled
              show-search
              :placeholder="t('label.selectOptions')"
              :options="countryOptions"
              option-filter-prop="label"
            />
          </a-form-item>
          <a-form-item
            name="toYear"
            class="ant-form-item--column required"
            :label="t('label.year')"
            :rules="{ required: true, message: '' }"
          >
            <g-date-picker
              v-model:value="state.formClone.toYear"
              picker="year"
              :allow-clear="false"
            />
          </a-form-item>
        </div>
      </div>
      <g-button
        type="warning"
        html-type="submit"
        class="w-24 mx-auto"
        :disabled="state.formClone.fromYear === state.formClone.toYear"
      >
        {{ t('label.clone') }}
      </g-button>
    </a-form>
  </a-modal>
</template>
