import type { ColumnProps } from 'ant-design-vue/es/table/Column';

export const createColumns = (t: Fn<string>): ColumnProps[] => [
  {
    title: t('label.holidayDate'),
    dataIndex: 'holidayDate',
    key: 'holidayDate',
    width: 200,
    slots: {
      customRender: 'holidayDate',
    },
  },
  {
    title: t('label.holidayName'),
    dataIndex: 'holidayName',
    width: 200,
    key: 'holidayName',
    slots: {
      customRender: 'holidayName',
    },
  },
  {
    title: t('label.foreignName'),
    dataIndex: 'holidayForeignName',
    key: 'foreignName',
    width: 200,
    slots: {
      customRender: 'foreignName',
    },
  },
  {
    title: t('label.action'),
    dataIndex: 'action',
    key: 'action',
    width: 80,
    align: 'center',
    slots: {
      customRender: 'action',
    },
  },
];
