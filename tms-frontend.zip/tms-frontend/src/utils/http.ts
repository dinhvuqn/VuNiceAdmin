import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';
import { useUserStoreWithOut } from '@/store/modules/user';
import { useNotification } from '@/hooks/useNotification';
import { getLanguage } from '@/hooks/useLanguage';
import { t, te } from '@/i18n';
import { router } from '@/router';
import { isString } from './is';
import { getToken } from './auth';
import StatusCodes from 'http-status-codes';

declare module 'axios' {
  export interface AxiosRequestConfig {
    notShowNotiPopup?: boolean;
  }
}

enum MethodEnums {
  GET = 'GET',
  POST = 'POST',
  PUT = 'PUT',
  PATCH = 'PATCH',
  DELETE = 'DELETE',
}

const { createNotification } = useNotification();

// baseURL
const BASE_URL =
  import.meta.env.MODE === 'dev' ||
  import.meta.env.MODE === 'test' ||
  import.meta.env.MODE === 'prod'
    ? import.meta.env.VITE_API_BASE_URL
    : '';

const instance = axios.create({
  baseURL: BASE_URL,
  withCredentials: true,
  timeout: 10000,
});

instance.interceptors.request.use(
  (config) => {
    const token = getToken();
    const language = getLanguage();

    if (token) {
      config.headers = {
        ...config.headers,
        Authorization: token,
        'X-LANGUAGE': language,
      };
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  },
);

instance.interceptors.response.use(
  (response) => {
    if (!response.data || !isString(response.data)) return response.data;

    const successMessage = t(`message.${response.data}`);
    createNotification('success', successMessage);
  },
  async (error) => {
    if ([StatusCodes.UNAUTHORIZED].includes(error.response.status)) {
      router.push({ path: '/login', query: { path: router.currentRoute.value.fullPath } });

      return useUserStoreWithOut().logout();
    }

    if (!error.config.notShowNotiPopup && error.response.data) {
      let { errorID, params } = error.response.data;

      if (error.response.data instanceof Blob) {
        const data = JSON.parse(await error.response.data.text());

        errorID = data.errorID;
        params = data.params;
      }

      const paramsOutput = params?.map((param) =>
        te(`params.${param}`) ? t(`params.${param}`) : param,
      );
      if (
        error.response.data.status !== StatusCodes.FORBIDDEN &&
        error.response.data.status !== StatusCodes.NOT_FOUND
      ) {
        const errorMessage = t(`message.${errorID}`, paramsOutput);
        createNotification('error', errorMessage);
      }
    }

    return Promise.reject(error);
  },
);

const request = <T, R = T>(config: AxiosRequestConfig, options?: AxiosRequestConfig) => {
  return instance.request<T, R>({ ...config, ...options });
};

export function get<T = any, R = T>(config: AxiosRequestConfig, options?: AxiosRequestConfig) {
  return request<T, R>({ ...config, method: MethodEnums.GET }, options);
}

export function post<T = any, R = T>(config: AxiosRequestConfig, options?: AxiosRequestConfig) {
  return request<T, R>({ ...config, method: MethodEnums.POST }, options);
}

export function patch<T = any, R = T>(config: AxiosRequestConfig, options?: AxiosRequestConfig) {
  return request<T, R>({ ...config, method: MethodEnums.PATCH }, options);
}

export function put<T = any, R = T>(config: AxiosRequestConfig, options?: AxiosRequestConfig) {
  return request<T, R>({ ...config, method: MethodEnums.PUT }, options);
}

export function remove<T = any, R = T>(config: AxiosRequestConfig, options?: AxiosRequestConfig) {
  return request<T, R>({ ...config, method: MethodEnums.DELETE }, options);
}

export default request;
export type { AxiosInstance, AxiosResponse };
