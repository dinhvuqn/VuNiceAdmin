/**
 * Personal matters
 */
export const PERSONAL_MATTERS = 10;
/**
 * Leave for sickness of children
 */
export const LEAVE_FOR_SICKNESS_OF_CHILDREN = 11;
/**
 * Leave for prenatal check-up
 */
export const LEAVE_FOR_PRENATAL_CHECKUP = 12;
/**
 * Leave due to diseases requiring long-term treatment
 */
export const LEAVE_DUE_TO_DISEASES_REQUIRING_LONGTERM_TREATMENT = 13;
/**
 * Leave for miscarriage
 */
export const LEAVE_FOR_MISCARRIAGE = 14;
/**
 * Leave for convalescence and health rehabilitation after sickness
 */
export const LEAVE_FOR_CONVALESCENCE_AND_HEALTH_REHABILITATION_AFTER_SICKNESS = 19;
/**
 * Leave for convalescence and health rehabilitation after maternity period
 */
export const LEAVE_FOR_CONVALESCENCE_AND_HEALTH_REHABILITATION_AFTER_MATERNITY_PERIOD = 20;
/**
 * Personal health reasons
 */
export const PERSONAL_HEALTH_REASONS = 21;
/**
 * Casual leave
 */
export const CASUAL_LEAVE = 22;
/**
 * Leave for marriage
 */
export const LEAVE_FOR_MARRIAGE = 23;
/**
 * Maternity leave
 */
export const MATERNITY_LEAVE = 24;
/**
 * Leave for bereavement
 */
export const LEAVE_FOR_BEREAVEMENT = 25;
/**
 * Wife's Maternity leave
 */
export const WIFES_MATERNITY_LEAVE = 26;

/**
 * Leave for long-term treatment at hospital
 */
export const LEAVE_FOR_LONGTERM_TREATMENT_AT_HOSPITAL = 27;

/**
 * Leave for short-term treatment
 */
export const LEAVE_FOR_SHORTTERM_TREATMENT = 28;
/**
 * Other
 */
export const OTHER = 99;
