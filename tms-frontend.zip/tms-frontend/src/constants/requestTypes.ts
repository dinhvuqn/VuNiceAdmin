import * as reasons from '@/constants/reasons';
/**
 * Annual leave
 */
export const ANNUAL_LEAVE = 10;
/**
 * Remaining Annual Leave of previous year
 */
export const REMAINING_ANNUAL_LEAVE_OF_PREVIOUS_YEAR = 11;
/**
 * Compensation Leave
 */
export const COMPENSATION_LEAVE = 12;
/**
 * Sick leave (Within medical record)
 */
export const SICK_LEAVE = 13;
/**
 * Casual leave
 */
export const CASUAL_LEAVE = 14;
/**
 * Unpaid Leave
 */
export const UNPAID_LEAVE = 15;
/**
 * Leave for marriage
 */
export const LEAVE_FOR_MARRIAGE = 17;
/**
 * Maternity leave ( One kid)
 */
export const MATERNITY_LEAVE_ONE_KID = 18;
/**
 * Maternity leave ( Twins)
 */
export const MATERNITY_LEAVE_TWINS = 19;
/**
 * Maternity leave ( Triplets)
 */
export const MATERNITY_LEAVE_TRIPLETS = 20;
/**
 * Leave for bereavement (parents, child)
 */
export const LEAVE_FOR_BEREAVEMENT_PARENTS__CHILD = 24;
/**
 * Work in different time from company-specified working-time
 */
export const DIFFERENT_COMPANY_STANDARD_WORKING_TIME = 35;
/**
 * Work From Home
 */
export const WORK_FROM_HOME = 36;
/**
 * Leave for sickness of children (Within medical record)
 */
export const LEAVE_FOR_SICKNESS_OF_CHILDREN_WITHIN_MEDICAL_RECORD = 40;
/**
 * Wife's Maternity leave (normal birth)
 */
export const WIFES_MATERNITY_LEAVE_NORMAL_BIRTH = 41;
/**
 * Wife's Maternity leave (cesarean section)
 */
export const WIFES_MATERNITY_LEAVE_CESAREAN_SECTION = 42;
/**
 * Wife's Maternity leave (Twins)
 */
export const WIFES_MATERNITY_LEAVE_TWINS = 43;
/**
 * Maternity leave ( One kid) & ( Twins) & ( Triplets)
 */
export const REQUEST_MONTH_TYPES = [
  MATERNITY_LEAVE_ONE_KID,
  MATERNITY_LEAVE_TWINS,
  MATERNITY_LEAVE_TRIPLETS,
];
/**
 * check if decrease Leave-Off balance
 * @param requestTypeCode
 * @return
 */
export const isLeaveOff = (requestTypeCode: number | undefined): boolean => {
  return !(
    requestTypeCode === DIFFERENT_COMPANY_STANDARD_WORKING_TIME ||
    requestTypeCode === WORK_FROM_HOME
  );
};

/**
 * requestType And Reason Map
 */
export const requestTypeAndReasonMap = {
  [ANNUAL_LEAVE]: [
    reasons.PERSONAL_MATTERS,
    reasons.LEAVE_FOR_SICKNESS_OF_CHILDREN,
    reasons.LEAVE_FOR_PRENATAL_CHECKUP,
    reasons.LEAVE_DUE_TO_DISEASES_REQUIRING_LONGTERM_TREATMENT,
    reasons.LEAVE_FOR_MISCARRIAGE,
    reasons.LEAVE_FOR_CONVALESCENCE_AND_HEALTH_REHABILITATION_AFTER_SICKNESS,
    reasons.LEAVE_FOR_CONVALESCENCE_AND_HEALTH_REHABILITATION_AFTER_MATERNITY_PERIOD,
    reasons.PERSONAL_HEALTH_REASONS,
    reasons.CASUAL_LEAVE,
    reasons.LEAVE_FOR_MARRIAGE,
    reasons.MATERNITY_LEAVE,
    reasons.LEAVE_FOR_BEREAVEMENT,
    reasons.WIFES_MATERNITY_LEAVE,
    reasons.LEAVE_FOR_LONGTERM_TREATMENT_AT_HOSPITAL,
    reasons.LEAVE_FOR_SHORTTERM_TREATMENT,
    reasons.OTHER,
  ],
  [REMAINING_ANNUAL_LEAVE_OF_PREVIOUS_YEAR]: [
    reasons.PERSONAL_MATTERS,
    reasons.LEAVE_FOR_SICKNESS_OF_CHILDREN,
    reasons.LEAVE_FOR_PRENATAL_CHECKUP,
    reasons.LEAVE_DUE_TO_DISEASES_REQUIRING_LONGTERM_TREATMENT,
    reasons.LEAVE_FOR_MISCARRIAGE,
    reasons.LEAVE_FOR_CONVALESCENCE_AND_HEALTH_REHABILITATION_AFTER_SICKNESS,
    reasons.LEAVE_FOR_CONVALESCENCE_AND_HEALTH_REHABILITATION_AFTER_MATERNITY_PERIOD,
    reasons.PERSONAL_HEALTH_REASONS,
    reasons.CASUAL_LEAVE,
    reasons.LEAVE_FOR_MARRIAGE,
    reasons.MATERNITY_LEAVE,
    reasons.LEAVE_FOR_BEREAVEMENT,
    reasons.WIFES_MATERNITY_LEAVE,
    reasons.LEAVE_FOR_LONGTERM_TREATMENT_AT_HOSPITAL,
    reasons.LEAVE_FOR_SHORTTERM_TREATMENT,
    reasons.OTHER,
  ],
  [COMPENSATION_LEAVE]: [
    reasons.PERSONAL_MATTERS,
    reasons.LEAVE_FOR_SICKNESS_OF_CHILDREN,
    reasons.LEAVE_FOR_PRENATAL_CHECKUP,
    reasons.LEAVE_DUE_TO_DISEASES_REQUIRING_LONGTERM_TREATMENT,
    reasons.LEAVE_FOR_MISCARRIAGE,
    reasons.LEAVE_FOR_CONVALESCENCE_AND_HEALTH_REHABILITATION_AFTER_SICKNESS,
    reasons.LEAVE_FOR_CONVALESCENCE_AND_HEALTH_REHABILITATION_AFTER_MATERNITY_PERIOD,
    reasons.PERSONAL_HEALTH_REASONS,
    reasons.CASUAL_LEAVE,
    reasons.LEAVE_FOR_MARRIAGE,
    reasons.MATERNITY_LEAVE,
    reasons.LEAVE_FOR_BEREAVEMENT,
    reasons.WIFES_MATERNITY_LEAVE,
    reasons.LEAVE_FOR_LONGTERM_TREATMENT_AT_HOSPITAL,
    reasons.LEAVE_FOR_SHORTTERM_TREATMENT,
    reasons.OTHER,
  ],
  [SICK_LEAVE]: [
    reasons.LEAVE_DUE_TO_DISEASES_REQUIRING_LONGTERM_TREATMENT,
    reasons.LEAVE_FOR_MISCARRIAGE,
    reasons.LEAVE_FOR_CONVALESCENCE_AND_HEALTH_REHABILITATION_AFTER_SICKNESS,
    reasons.LEAVE_FOR_LONGTERM_TREATMENT_AT_HOSPITAL,
    reasons.LEAVE_FOR_SHORTTERM_TREATMENT,
    reasons.OTHER,
  ],
  [CASUAL_LEAVE]: [reasons.CASUAL_LEAVE, reasons.OTHER],
  [UNPAID_LEAVE]: [
    reasons.PERSONAL_MATTERS,
    reasons.LEAVE_FOR_SICKNESS_OF_CHILDREN,
    reasons.LEAVE_FOR_PRENATAL_CHECKUP,
    reasons.LEAVE_DUE_TO_DISEASES_REQUIRING_LONGTERM_TREATMENT,
    reasons.LEAVE_FOR_MISCARRIAGE,
    reasons.LEAVE_FOR_CONVALESCENCE_AND_HEALTH_REHABILITATION_AFTER_SICKNESS,
    reasons.LEAVE_FOR_CONVALESCENCE_AND_HEALTH_REHABILITATION_AFTER_MATERNITY_PERIOD,
    reasons.PERSONAL_HEALTH_REASONS,
    reasons.CASUAL_LEAVE,
    reasons.LEAVE_FOR_MARRIAGE,
    reasons.MATERNITY_LEAVE,
    reasons.LEAVE_FOR_BEREAVEMENT,
    reasons.WIFES_MATERNITY_LEAVE,
    reasons.LEAVE_FOR_LONGTERM_TREATMENT_AT_HOSPITAL,
    reasons.LEAVE_FOR_SHORTTERM_TREATMENT,
    reasons.OTHER,
  ],
  [LEAVE_FOR_MARRIAGE]: [reasons.LEAVE_FOR_MARRIAGE, reasons.OTHER],
  [MATERNITY_LEAVE_ONE_KID]: [
    reasons.LEAVE_FOR_CONVALESCENCE_AND_HEALTH_REHABILITATION_AFTER_MATERNITY_PERIOD,
    reasons.MATERNITY_LEAVE,
    reasons.OTHER,
  ],
  [MATERNITY_LEAVE_TWINS]: [
    reasons.LEAVE_FOR_CONVALESCENCE_AND_HEALTH_REHABILITATION_AFTER_MATERNITY_PERIOD,
    reasons.MATERNITY_LEAVE,
    reasons.OTHER,
  ],
  [MATERNITY_LEAVE_TRIPLETS]: [
    reasons.LEAVE_FOR_CONVALESCENCE_AND_HEALTH_REHABILITATION_AFTER_MATERNITY_PERIOD,
    reasons.MATERNITY_LEAVE,
    reasons.OTHER,
  ],
  [LEAVE_FOR_BEREAVEMENT_PARENTS__CHILD]: [reasons.LEAVE_FOR_BEREAVEMENT, reasons.OTHER],
  [DIFFERENT_COMPANY_STANDARD_WORKING_TIME]: [
    reasons.PERSONAL_MATTERS,
    reasons.LEAVE_FOR_SICKNESS_OF_CHILDREN,
    reasons.LEAVE_FOR_PRENATAL_CHECKUP,
    reasons.PERSONAL_HEALTH_REASONS,
    reasons.OTHER,
  ],
  [WORK_FROM_HOME]: [
    reasons.PERSONAL_MATTERS,
    reasons.LEAVE_FOR_SICKNESS_OF_CHILDREN,
    reasons.PERSONAL_HEALTH_REASONS,
    reasons.OTHER,
  ],
  [LEAVE_FOR_SICKNESS_OF_CHILDREN_WITHIN_MEDICAL_RECORD]: [
    reasons.LEAVE_FOR_SICKNESS_OF_CHILDREN,
    reasons.OTHER,
  ],
  [WIFES_MATERNITY_LEAVE_NORMAL_BIRTH]: [reasons.WIFES_MATERNITY_LEAVE, reasons.OTHER],
  [WIFES_MATERNITY_LEAVE_CESAREAN_SECTION]: [reasons.WIFES_MATERNITY_LEAVE, reasons.OTHER],
  [WIFES_MATERNITY_LEAVE_TWINS]: [reasons.WIFES_MATERNITY_LEAVE, reasons.OTHER],
};
