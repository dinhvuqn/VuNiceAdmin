/**
 * VIETNAM
 */
export const VIETNAM = 10;
/**
 * JAPAN
 */
export const JAPAN = 20;
/**
 * USA
 */
export const USA = 30;
