export const initBarChartOption = () => ({
  grid: {
    top: 40,
    left: 250,
  },
  tooltip: {
    show: true,
    textStyle: {
      fontFamily: 'Segoe UI',
    },
  },
  toolbox: {
    show: true,
  },
  xAxis: {
    type: 'value',
  },
  yAxis: {
    data: [] as string[],
    axisLabel: {
      fontFamily: 'Segoe UI',
      lineHeight: 16,
    },
  },
  legend: {
    top: 0,
    itemGap: 25,
    data: [] as string[],
    textStyle: {
      fontFamily: 'Segoe UI',
    },
  },
  series: [],
});
