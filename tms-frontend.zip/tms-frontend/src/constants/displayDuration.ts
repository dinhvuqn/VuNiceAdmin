import { REQUEST_MONTH_TYPES } from '@/constants/requestTypes';

export const displayDuration = (t: Fn<string>, duration: number, requestTypeCode?: number) => {
  if (REQUEST_MONTH_TYPES.includes(requestTypeCode!)) {
    return duration === 1 ? t('label.month') : t('label.months');
  }

  return duration === 1 ? t('label.day') : t('label.days');
};
