import { BaseService } from '@/services/base.service';
import { removeEmptyValues } from '@/utils';
import { TAction, TActionType, TSearch, TList, TReceivedRequest } from './model';

type TRequest = {
  TSearch: TSearch;
};

type TResponse = {
  TList: TList;
};

class ReceivedRequestService extends BaseService<TRequest, TResponse> {
  static _instance = new ReceivedRequestService();

  get enity() {
    return '/received-request';
  }

  get actionEnity() {
    return `${this.enity}/action`;
  }

  async action(actionType: TActionType, formAction: TAction) {
    const data = removeEmptyValues({ ...formAction, action: actionType });

    return await this.request.post({ url: this.actionEnity }, { data });
  }
}

export type { TSearch, TList, TReceivedRequest, TAction, TActionType };
export default ReceivedRequestService._instance;
