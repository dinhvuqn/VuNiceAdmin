import { BaseService } from '@/services/base.service';
import { TDashboardByRequestType } from './model';

class DashboardService extends BaseService<any, any> {
  static _instance = new DashboardService();

  get enity() {
    return '/dashboard';
  }

  async dashboardByRequestType() {
    return await this.request.get<TDashboardByRequestType[]>({
      url: `${this.enity!}/by-request-type`,
    });
  }
}

export type { TDashboardByRequestType };
export default DashboardService._instance;
