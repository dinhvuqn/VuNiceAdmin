/**
 * Response type bellow
 */

export type TDashboardByRequestType = {
  countDay: number;
  countStaff: number;
  requestTypeCode: number;
  requestTypeName: string;
};
