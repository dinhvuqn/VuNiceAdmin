/**
 * Request type bellow
 */

export type TSearch = {
  workingMonth: string;
  employeeAccounts: number[] | undefined;
  pageSize: number;
  curentpage: number;
};

/**
 * Response type bellow
 */

export type TReportList = {
  id: string;
  employeeAccount: {
    id: number;
    label: string;
  };
  workingMonth: string;
  workingDays: number;
  paidLeaveDays: number;
  overtimeDays: number;
};

export type TList = {
  list: TReportList[];
  total: number;
};
