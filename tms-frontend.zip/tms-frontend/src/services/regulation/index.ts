import { BaseService } from '@/services/base.service';

class RegulationService extends BaseService<any, any> {
  static _instance = new RegulationService();

  get enity() {
    return '/regulation';
  }

  async useLeaveDays() {
    return await this.request.get({ url: `${this.enity!}/use-leave-days`, responseType: 'blob' });
  }

  async userManual() {
    return await this.request.get({ url: `${this.enity!}/user-manual`, responseType: 'blob' });
  }

  async uploadUseLeaveDays(data: FormData) {
    return await this.request.post({
      url: `${this.enity!}/use-leave-days/upload`,
      headers: { 'Content-Type': 'multipart/form-data' },
      data,
    });
  }

  async uploadUserManual(data: FormData) {
    return await this.request.post({
      url: `${this.enity!}/user-manual/upload`,
      headers: { 'Content-Type': 'multipart/form-data' },
      data,
    });
  }
}

export default RegulationService._instance;
