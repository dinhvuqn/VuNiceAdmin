import { BaseService } from '@/services/base.service';
import { TSearch, TList, TReportList, TExport } from './model';

type TRequest = {
  TSearch: TSearch;
  TExport: TExport;
};

type TResponse = {
  TList: TList;
};

class MyReportService extends BaseService<TRequest, TResponse> {
  static _instance = new MyReportService();

  get enity() {
    return '/my-report';
  }
}

export type { TSearch, TList, TReportList, TExport };
export default MyReportService._instance;
