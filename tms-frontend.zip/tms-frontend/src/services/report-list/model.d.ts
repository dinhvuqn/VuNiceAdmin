/**
 * Request type bellow
 */

export type TSearch = {
  workingMonthFrom: string;
  workingMonthTo: string;
  userIDs: number[] | undefined;
  pageSize: number;
  curentpage: number;
};

export type TExport = {
  workingMonthFrom: string;
  workingMonthTo: string;
  userIDs: number[] | undefined;
};

/**
 * Response type bellow
 */

export type TReportList = {
  userID: string;
  account: string;
  userName: string;
  workingMonthFrom: string;
  workingMonthTo: string;
  workingDays: number;
  paidLeaveDays: number;
  unPaidLeaveDays: number;
};

export type TList = {
  list: TReportList[];
  total: number;
};
