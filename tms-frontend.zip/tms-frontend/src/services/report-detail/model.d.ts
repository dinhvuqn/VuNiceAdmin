/**
 * Request type bellow
 */

export type TSearch = {
  workingMonthFrom: string;
  workingMonthTo: string;
  userID: string;
};

/**
 * Response type bellow
 */

export type TReportDetail = {
  userID: string;
  firstName: string;
  lastName: string;
  account: string;
  userName: string;
  workingMonthFrom: string;
  workingMonthTo: string;
  requestDetails: TReportDetailList[];
};

export type TReportDetailList = {
  category: string;
  requestID: string;
  requestTypeCode: string;
  requestTypeName: string;
  duration: string;
  leaveFrom: string;
  leaveTo: string;
  userID: string;
  approverAccount: string;
  createUserName: string;
  approverID: string;
  approverName: string;
  account: string;
};

export type TList = TReportDetail;
