import { BaseService } from '@/services/base.service';
import { TSearch, TList, TReportDetail } from './model';

type TRequest = {
  TSearch: TSearch;
};

type TResponse = {
  TList: TList;
};

class ReportDetailService extends BaseService<TRequest, TResponse> {
  static _instance = new ReportDetailService();

  get enity() {
    return '/my-report/detail';
  }
}

export type { TSearch, TList, TReportDetail };
export default ReportDetailService._instance;
