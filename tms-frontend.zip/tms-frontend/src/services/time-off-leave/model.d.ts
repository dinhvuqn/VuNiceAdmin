/**
 * Request type bellow
 */

export type TSearch = {
  staffID: string | undefined;
  year: string;
};

export type TFormClone = {
  fromStaffID: string | undefined;
  fromYear: string;
  toStaffID: string | undefined;
  toYear: string;
};

/**
 * Response type bellow
 */

export type TTimeOffLeave = {
  timeOffCode: string;
  userID: string;
  timeOffName: string;
  unit: string;
  maximumAllowed: number;
  approvedQuotas: number;
  remainingQuotas: number;
  pendingQuotas: number;
  remark: string;
};

export type TList = TTimeOffLeave[];
