import { BaseService } from '@/services/base.service';
import { TSearch, TList, TTimeOffLeave, TFormClone } from './model';

type TRequest = {
  TSearch: TSearch;
};

type TResponse = {
  TList: TList;
  TDetail: { messageId: string; params: string[] };
};

class TimeOffLeaveService extends BaseService<TRequest, TResponse> {
  static _instance = new TimeOffLeaveService();

  get enity() {
    return '/time-off-leave';
  }

  async checkExistTimeOff(data: TFormClone) {
    return await this.request.post<boolean>({ url: `${this.enity}/check-exist`, data });
  }

  async cloneFromMasterData(data: TSearch) {
    return await this.request.post({ url: `${this.enity}/clone-from-master-data`, data });
  }

  async clone(data: TFormClone) {
    return await this.request.post({ url: `${this.enity}/clone`, data });
  }
}

export type { TSearch, TList, TTimeOffLeave, TFormClone };
export default TimeOffLeaveService._instance;
