/**
 * Request type bellow
 */

export type TSearch = {};

/**
 * Response type bellow
 */

export type TMyTimeOffLeave = {
  timeOffCode: string;
  userID: string;
  timeOffName: string;
  unit: string;
  maximumAllowed: number;
  approvedQuotas: number;
  remainingQuotas: number;
  pendingQuotas: number;
};

export type TList = TMyTimeOffLeave[];
