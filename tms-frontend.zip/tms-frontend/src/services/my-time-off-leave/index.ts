import { BaseService } from '@/services/base.service';
import { TSearch, TList, TMyTimeOffLeave } from './model';

type TRequest = {
  TSearch: TSearch;
};

type TResponse = {
  TList: TList;
};

class MyTimeOffLeaveService extends BaseService<TRequest, TResponse> {
  static _instance = new MyTimeOffLeaveService();

  get enity() {
    return '/my-time-off-leave';
  }
}

export type { TSearch, TList, TMyTimeOffLeave };
export default MyTimeOffLeaveService._instance;
