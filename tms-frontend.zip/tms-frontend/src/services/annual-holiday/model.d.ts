/**
 * Request type bellow
 */

export type TSearch = {
  year: string;
  country: number | undefined;
};

export type TFormClone = {
  fromYear: string;
  toYear: string;
  country: number | undefined;
};

/**
 * Response type bellow
 */

export type TAnnualHoliday = {
  holidayID: number | undefined;
  countryCode: number | undefined;
  countryName?: string;
  holidayDate: string;
  holidayName: string;
  holidayForeignName: string;
  createUserID?: string;
  createDateTime?: string;
  updateUserID?: string;
  updateDateTime?: string;
};

export type TList = TAnnualHoliday[];
