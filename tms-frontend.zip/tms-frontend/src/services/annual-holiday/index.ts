import { BaseService } from '@/services/base.service';
import { TSearch, TList, TAnnualHoliday, TFormClone } from './model';

type TRequest = {
  TSearch: TSearch;
};

type TResponse = {
  TList: TList;
  TDetail: { messageId: string; params: string[] };
};

class AnnualHolidayService extends BaseService<TRequest, TResponse> {
  static _instance = new AnnualHolidayService();

  get enity() {
    return '/annual-holiday';
  }

  async countHoliday(params: { startDate: string; endDate: string }) {
    return await this.request.get<number>({ url: '/count-holiday', params });
  }

  async checkExistHoliday(data: TFormClone) {
    return await this.request.post<boolean>({ url: `${this.enity}/check-exist`, data });
  }

  async clone(data: TFormClone) {
    return await this.request.post({ url: `${this.enity}/clone`, data });
  }
}

export type { TSearch, TList, TAnnualHoliday, TFormClone };
export default AnnualHolidayService._instance;
