import { BaseService } from '@/services/base.service';
import { TTimeOffGenerate } from './model';

type TRequest = {};

type TResponse = {
  TList: TTimeOffGenerate[];
  TDetail: { messageId: string; params: string[] };
};

class RequestTypeService extends BaseService<TRequest, TResponse> {
  static _instance = new RequestTypeService();

  get enity() {
    return '/request-type';
  }
}

export type { TTimeOffGenerate };
export default RequestTypeService._instance;
