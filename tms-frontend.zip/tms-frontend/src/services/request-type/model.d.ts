/**
 * Response type bellow
 */

export type TTimeOffGenerate = {
  timeOffCode?: number;
  limitedByYear: boolean;
  timeOffName: string;
  timeOffNameEN: string;
  timeOffNameJP: string;
  unitCode: number;
  unitName: string;
  maximumAllowed: number | undefined;
  maximumPerLog: number | undefined;
  paidLeave: boolean;
};
