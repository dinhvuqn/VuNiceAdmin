import { BaseService } from '@/services/base.service';
import {
  TSearch,
  TList,
  TCreate,
  TUpdate,
  TDetail,
  TMyRequest,
  TCancel,
  TWorkingTime,
} from './model';

type TRequest = {
  TSearch: TSearch;
  TCreate: TCreate;
  TUpdate: TUpdate;
};

type TResponse = {
  TList: TList;
  TDetail: TDetail;
};

class MyRequestService extends BaseService<TRequest, TResponse> {
  static _instance = new MyRequestService();

  get enity() {
    return '/my-request';
  }

  async cancel(data: TCancel) {
    return await this.request.post({ url: `${this.enity!}/cancel` }, { data });
  }

  async checkRemainWorkingTime(params: TWorkingTime) {
    type TWorkingTimeResponse = {
      requestMonth: string;
      warningFlag: boolean;
      workingTime: number;
      standardWorkingTime: number;
    };

    return await this.request.get<TWorkingTimeResponse>(
      { url: `${this.enity!}/check-remain-working-time` },
      { params },
    );
  }
}

export type { TSearch, TList, TCreate, TUpdate, TDetail, TMyRequest, TWorkingTime };
export default MyRequestService._instance;
