/**
 * Request type bellow
 */

export type TSearch = {
  timeRequestFrom: string;
  timeRequestTo: string;
  requestTypes: number[] | undefined;
  requestStatus: number[] | undefined;
  pageSize: number;
  curentpage: number;
};

export type TCreate = {
  requestTypeCode: number | undefined;
  representedUserID: string | undefined;
  leaveFrom: string;
  leaveTo: string;
  partialDay: number | undefined;
  reasonCode: number | undefined;
  approverID: string | undefined;
  detailedReason?: string;
  confirmUserIDs: string[] | undefined;
  informTo?: string[] | undefined;
  expectedApproveDateTime?: string;
  duration?: number | undefined;
};

export type TUpdate = {
  requestID?: string;
} & TCreate;

export type TCancel = {
  requestID: string;
  comment: string;
  subID: string;
};

export type TWorkingTime = {
  leaveFrom: string;
  leaveTo: string;
  partialDay: number | undefined;
  requestTypeCode: number | undefined;
  representedUserID: string | undefined;
  requestID: string | undefined;
};

export type TUpdate = {};

/**
 * Response type bellow
 */

export type TMyRequest = {
  account: string;
  approveDateTime: string;
  approverID: string;
  approverName: string;
  approverAccount: string;
  confirmDateTime: string;
  confirmUserID: string;
  confirmUserName: string;
  createDateTime: string;
  createUserID: string;
  createUserName: string;
  delegatedBy: string;
  delegatedByName: string;
  delegatedTo: string;
  delegatedToName: string;
  detailedReason: string;
  duration: string;
  inforUser: string;
  leaveFrom: string;
  leaveTo: string;
  partialDay: string;
  partialDayName: string;
  reasonCode: string;
  reasonName: string;
  requestID: string;
  requestStatusCode: number;
  requestStatusName: string;
  requestTypeCode: number;
  requestTypeName: string;
  updateDateTime: string;
  updateUserID: string;
  updateUserName: string;
  subID: string;
  userID: string;
  createrAccount: string;
  updaterAccount: string;
  confirmUsers: {
    userID: string;
    account: string;
    firstName: string;
    lastName: string;
    statusCode: number;
    statusName: string;
    confirmDateTime: string;
  }[];
  requestComments: {
    account: string;
    comment: string;
    commentAt: string;
    commentBy: string;
    requestStatusCode: number;
    requestStatusName: string;
  }[];
  requesterName: string;
  requestComments: {
    account: string;
    comment: string;
    commentAt: string;
    commentBy: string;
    requestStatusCode: number;
    requestStatusName: string;
  }[];
};

export type TList = {
  list: TMyRequest[];
  total: number;
};

export type TDetail = {};
