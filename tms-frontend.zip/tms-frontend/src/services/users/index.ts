import { TLoginRequest, TLoginResponse, TPermissionResponse } from './model';
import { get, post } from '@/utils/http';

enum URL {
  login = '/authentication/login',
  permission = '/authentication/permission',
  changePassword = '/users/change-password',
  forgotPassword = '/users/forgot-password',
}

class UserService {
  static _instance = new UserService();

  async login(formData: TLoginRequest) {
    return await post<TLoginResponse>({ url: URL.login, data: formData, notShowNotiPopup: true });
  }

  async permission() {
    return await get<TPermissionResponse>({ url: URL.permission });
  }
}

export type { TLoginRequest, TLoginResponse, TPermissionResponse };
export default UserService._instance;
