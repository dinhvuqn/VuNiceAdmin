export type TLoginRequest = {
  account: string;
  password: string;
  isRememberMe: boolean;
};

export type TTmsUser = {
  account: string;
  email: string;
  firstName: string;
  joinDate: string;
  lastName: string;
  leftDate: string;
  imageBase64: string;
  loginFirstTimeFlag: boolean;
  tel: string;
  userID: string;
  roleCode?: number;
};

export type TLoginResponse = {
  token: string;
  tmsUser: TTmsUser;
};

export type TPermissionResponse = {
  fullName: string;
  auths: string[];
  modules: string[];
  is_admin?: 0 | 1;
  firstName: string;
  lastName: string;
  tmsUser: TTmsUser;
};
