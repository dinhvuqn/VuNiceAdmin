import { BaseService } from '@/services/base.service';
import { TSearch, TList, TReportList } from './model';

type TRequest = {
  TSearch: TSearch;
};

type TResponse = {
  TList: TList;
};

class MyReportService extends BaseService<TRequest, TResponse> {
  static _instance = new MyReportService();

  get enity() {
    return '/report-timeoff-balance';
  }
}

export type { TSearch, TList, TReportList };
export default MyReportService._instance;
