/**
 * Request type bellow
 */
export type TSearch = {
  year: string;
  userIDs: number[] | undefined;
  requestTypes: number[] | undefined;
  pageSize: number;
  curentpage: number;
};

/**
 * Response type bellow
 */
export type TReportList = {
  userID: string;
  employeeName: string;
  displayName: string;
  approvedQuotas: number;
  maximumAllowed: number;
  pendingQuotas: number;
  remainingQuotas: number;
  userName: string;
};

export type TList = {
  list: TReportList[];
  total: number;
};
