<script setup lang="ts">
  import { useTitle } from '@/hooks/useTitle';
  import { useLoading } from '@/hooks/useLoading';
  import { useConfirmModal } from '@/hooks/useConfirmModal';

  useTitle();
  const { isLoading } = useLoading();
  const { confirmModalVisible, confirmModalConfig } = useConfirmModal();
</script>

<template>
  <a-spin :spinning="isLoading" :delay="300">
    <router-view />
    <g-confirm-modal
      v-model:visible="confirmModalVisible"
      :confirm-modal-config="confirmModalConfig"
    />
  </a-spin>
</template>
