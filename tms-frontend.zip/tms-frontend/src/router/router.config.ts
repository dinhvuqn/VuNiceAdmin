import { RouteRecordRaw } from 'vue-router';
import AppLayout from '@/layouts/AppLayout/index.vue';
import BlankLayout from '@/layouts/BlankLayout.vue';
import { roleEnum } from '@/enums/roleEnum';

declare module 'vue-router' {
  export interface RouteMeta {
    icon?: TIcon;
    title?: string;
    breadcrumb?: string;
    role?: roleEnum[];
    hidden?: boolean;
    externalLink?: string;
  }
}

export const accessRoutes: RouteRecordRaw[] = [
  {
    path: '/',
    name: 'app',
    component: AppLayout,
    redirect: '/leave-request',
    meta: {
      title: 'menuTitle.leaveManagement',
      breadcrumb: 'menuTitle.home',
      icon: 'calendar-outlined',
    },
    children: [
      {
        path: '/leave-request',
        name: 'leaveRequest',
        component: BlankLayout,
        redirect: '/leave-request/my-request',
        meta: { title: 'menuTitle.leaveRequest', icon: 'read-filled' },
        children: [
          {
            path: '/leave-request/my-request',
            component: () => import('@/views/MyRequest/index.vue'),
            name: 'myRequest',
            meta: { title: 'menuTitle.myRequest' },
          },
          {
            path: '/leave-request/my-request/:id/:subID',
            component: () => import('@/views/CreateRequest/index.vue'),
            name: 'editMyRequest',
            meta: {
              title: 'menuTitle.editRequest',
              menuHighlight: '/leave-request/my-request',
              hidden: true,
            },
          },
          {
            path: '/leave-request/create-request',
            component: () => import('@/views/CreateRequest/index.vue'),
            name: 'createRequest',
            meta: {
              title: 'menuTitle.createRequest',
              breadcrumb: 'menuTitle.createNewRequest',
            },
          },
          {
            path: '/leave-request/received-request-list',
            component: () => import('@/views/ReceivedRequestList/index.vue'),
            name: 'receivedRequestList',
            meta: {
              title: 'menuTitle.receivedRequestList',
              role: [roleEnum.DIRETOR, roleEnum.PM, roleEnum.HR, roleEnum.TEAM_LEADER],
            },
          },
          {
            path: '/leave-request/received-request-list/:id/:subID',
            component: () => import('@/views/CreateRequest/index.vue'),
            name: 'editRecivedRequest',
            meta: {
              title: 'menuTitle.editRequest',
              menuHighlight: '/leave-request/received-request-list',
              hidden: true,
              role: [roleEnum.DIRETOR, roleEnum.PM, roleEnum.HR],
            },
          },
        ],
      },
      {
        path: '/master-info-management',
        name: 'masterInfoManagement',
        component: BlankLayout,
        redirect: { name: 'timeOffRequestBalance' },
        meta: {
          title: 'menuTitle.masterInfoManagement',
          icon: 'profile-filled',
          role: [roleEnum.DIRETOR, roleEnum.HR],
        },
        children: [
          {
            path: '/master-info-management/time-off-request-balance',
            component: () => import('@/views/TimeOffRequestAndBalance/index.vue'),
            name: 'timeOffRequestBalance',
            meta: {
              title: 'menuTitle.timeOffRequest',
              breadcrumb: 'menuTitle.timeOffRequestBalance',
            },
          },
          {
            path: '/master-info-management/annual-holiday',
            component: () => import('@/views/AnnualHoliday/index.vue'),
            name: 'annualHoliday',
            meta: {
              title: 'menuTitle.annualHoliday',
            },
          },
          {
            path: '/master-info-management/request-type',
            component: () => import('@/views/RequestTypeManagement/index.vue'),
            name: 'requestType',
            meta: {
              title: 'menuTitle.requestTypeManagement',
            },
          },
        ],
      },
      {
        path: '/my-report',
        name: 'myReport',
        component: BlankLayout,
        redirect: '/my-report/report-list',
        meta: {
          title: 'menuTitle.myReport',
          icon: 'reconciliation-filled',
          role: [roleEnum.DIRETOR, roleEnum.HR],
        },
        children: [
          {
            path: '/my-report/my-abnormal-case',
            component: () => import('@/views/MyAbnormalCase/index.vue'),
            name: 'myAbnormalCase',
            meta: {
              title: 'My Abnormal Case',
              hidden: true,
            },
          },
          {
            path: '/my-report/my-late-coming-early-leave',
            component: () => import('@/views/MyLateComingEarlyLeave/index.vue'),
            name: 'myLateComingEarlyLeave',
            meta: {
              title: 'My Late Coming Early Leave',
              hidden: true,
            },
          },
          {
            path: '/my-report/my-working-time-report',
            component: () => import('@/views/MyWorkingTimeReport/index.vue'),
            name: 'byWorkingTimeReport',
            meta: {
              title: 'My Working Time Report',
              hidden: true,
            },
          },
          {
            path: '/my-report/report-list',
            component: () => import('@/views/ReportList/index.vue'),
            name: 'reportList',
            meta: { title: 'menuTitle.timeOffRequestsReport' },
          },
          {
            path: '/my-report/report-list-Timeoff-balance',
            component: () => import('@/views/TimeOffRequestAndBalanceReport/index.vue'),
            name: 'reportListTimeOffBalance',
            meta: { title: 'menuTitle.quotasBalancesReport' },
          },
        ],
      },
      {
        path: '/regulations',
        component: BlankLayout,
        redirect: '/regulations/leave-off-rule',
        meta: {
          title: 'menuTitle.regulations',
          icon: 'container-filled',
        },
        children: [
          {
            path: '/regulations/leave-off-rule',
            component: () => import('@/views/TheUseOfLeaveDays/index.vue'),
            meta: {
              title: 'menuTitle.theUseOfLeaveDays',
            },
          },
          {
            path: '/regulations/user-manual',
            component: () => import('@/views/UserManual/index.vue'),
            meta: {
              title: 'menuTitle.userManual',
            },
          },
        ],
      },
      {
        path: '/delegation',
        name: 'delegation',
        component: BlankLayout,
        redirect: '/delegation/received-delegation',
        meta: {
          title: 'menuTitle.delegation',
          hidden: true,
          icon: 'reconciliation-filled',
          role: [roleEnum.DIRETOR, roleEnum.PM, roleEnum.HR],
        },
        children: [
          {
            path: '/delegation/received-delegation',
            component: () => import('@/views/ReceivedDelegation/index.vue'),
            name: 'receivedDelegation',
            meta: {
              title: 'menuTitle.receivedDelegation',
            },
          },
        ],
      },
      {
        path: '/dashboard',
        component: () => import('@/views/Dashboard/index.vue'),
        name: 'dashboard',
        meta: {
          title: 'menuTitle.dashboard',
          icon: 'dashboard-filled',
          role: [roleEnum.DIRETOR, roleEnum.PM, roleEnum.HR],
        },
      },
    ],
  },
];

const constantRoutes: RouteRecordRaw[] = [
  {
    path: '/login',
    component: () => import('@/views/login/index.vue'),
    name: 'login',
    meta: {
      title: 'label.login',
    },
  },
  ...accessRoutes,
  {
    path: '/:pathMatch(.*)',
    redirect: '/404',
  },
  {
    path: '/404',
    component: () => import('@/views/404.vue'),
    meta: {
      title: 'label.notFound',
    },
  },
  {
    path: '/403',
    component: () => import('@/views/403.vue'),
    meta: {
      title: 'label.accessDenied',
    },
  },
];

export default constantRoutes;
