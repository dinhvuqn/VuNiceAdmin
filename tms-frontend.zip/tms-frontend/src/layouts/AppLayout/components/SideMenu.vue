<script setup lang="ts">
  import MenuItem from './MenuItem.vue';
  import { accessRoutes } from '@/router/router.config';
  import { useLanguage } from '@/hooks/useLanguage';
  import logo from '@/assets/images/logo.png';

  const props = defineProps<{ collapsed: boolean }>();

  type TState = {
    collapsed: boolean;
    openKeys: string[];
  };

  const menuItems = accessRoutes.map(({ children }) => children || []).flat();

  const route = useRoute();
  const state = reactive<TState>({
    collapsed: true,
    openKeys: menuItems.map(({ path }) => path),
  });

  const { isVieLang, LanguageEnum } = useLanguage();

  const selectedKeys = computed(() =>
    route.matched.map(({ path, meta }) => (meta.menuHighlight as string) || path),
  );
</script>

<template>
  <a-layout-sider :collapsed="props.collapsed" width="260" breakpoint="lg">
    <div
      :class="[
        'flex items-center h-16 justify-center',
        { 'justify-between px-4': !props.collapsed },
      ]"
    >
      <img :src="logo" :class="props.collapsed ? 'h-[30px]' : 'h-[50px]'" />
      <a-switch
        v-if="!props.collapsed"
        v-model:checked="isVieLang"
        :checked-children="LanguageEnum.VI"
        :un-checked-children="LanguageEnum.EN"
        class="!mt-2.5"
      />
    </div>
    <a-menu
      v-model:selectedKeys="selectedKeys"
      v-model:openKeys="state.openKeys"
      mode="inline"
      :force-sub-menu-render="true"
    >
      <menu-item v-for="mainMenu in menuItems" :menu-item="mainMenu" :key="mainMenu.path" />
    </a-menu>
  </a-layout-sider>
</template>

<style lang="scss">
  .ant-layout-sider {
    background: linear-gradient(to bottom, #fffffff5, #fffffff5), url('@/assets/images/sidebar.png');
    background-size: cover;
    box-shadow: 0px 5px 5px -3px rgb(0 0 0 / 6%), 0px 8px 10px 1px rgb(0 0 0 / 4%),
      0px 3px 14px 2px rgb(0 0 0 / 4%);
    height: 100vh;
    z-index: 1;

    &-collapsed {
      .ant-menu-root .ant-menu-submenu > .ant-menu-submenu-title {
        padding-left: 28px !important;
      }
    }

    .ant-menu {
      background-color: transparent;

      &.ant-menu-inline,
      &.ant-menu-vertical {
        border-right: 0;
      }

      &:not(.ant-menu-horizontal) .ant-menu-item-selected {
        background-color: rgba(25, 118, 210, 0.08);
      }

      &.ant-menu-root > .ant-menu-item {
        padding: 0 20px !important;
        margin: 0 0 6px;
      }

      &-submenu {
        & > .ant-menu {
          background-color: transparent;
          padding: 0 20px;

          .ant-menu-title-content:before {
            content: '';
            position: absolute;
            width: 4px;
            height: 4px;
            background-color: #34314c;
            border-radius: 50%;
            top: 50%;
            transform: translateY(-50%);
            left: 10px;
          }
        }

        &-title {
          padding: 0 20px !important;
          margin: 0 0 6px;
          height: 45px !important;
        }

        .ant-menu-submenu-arrow {
          color: #34314c !important;
          right: 17px;
        }
      }

      .ant-menu-item {
        height: 45px !important;
        margin-top: 0;
        padding-left: 34px !important;

        &-active,
        &:focus-within {
          background-color: rgba(0, 0, 0, 0.04);
        }
      }

      span,
      a {
        font-family: 'Roboto', 'Helvetica', 'Arial', sans-serif;
        letter-spacing: 0.2px;
        color: #34314c;

        &:hover {
          color: #34314c;
        }
      }
    }
  }
</style>
