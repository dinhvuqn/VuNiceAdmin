<script setup lang="ts">
  import { usePermissioStore } from '@/store/modules/permission';
  import type { RouteMeta, RouteRecordRaw } from 'vue-router';

  const permissionStore = usePermissioStore();
  const props = defineProps<{ menuItem: RouteRecordRaw }>();

  const { title, hidden, role, icon, externalLink } = computed<RouteMeta>(
    () => props.menuItem.meta || {},
  ).value;

  const isHidden = computed(() => hidden || (role && !role?.includes(permissionStore.role)));
</script>

<template>
  <template v-if="!isHidden">
    <a-sub-menu v-if="menuItem.children" :key="menuItem.path">
      <template #title>
        <div class="flex items-center">
          <g-icon v-if="icon" :icon="icon" class="!text-xl mr-1" />
          <span>{{ $t(title!) }}</span>
        </div>
      </template>
      <menu-item v-for="subMenu in menuItem.children" :key="subMenu.path" :menu-item="subMenu" />
    </a-sub-menu>

    <template v-else>
      <a-menu-item :key="menuItem.path">
        <a v-if="externalLink" :href="externalLink" target="_blank">{{ $t(title!) }}</a>
        <div v-else class="flex items-center gap-2.5">
          <g-icon v-if="icon" :icon="icon" class="!text-xl mr-1" />
          <router-link :to="menuItem.path">{{ $t(title!) }}</router-link>
        </div>
      </a-menu-item>
    </template>
  </template>
</template>
