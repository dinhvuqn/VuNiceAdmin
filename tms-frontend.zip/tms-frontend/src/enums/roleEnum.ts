export enum roleEnum {
  STAFF = 10,
  PM = 20,
  DIRETOR = 30,
  HR = 40,
  IT = 50,
  TEAM_LEADER = 60,
}
