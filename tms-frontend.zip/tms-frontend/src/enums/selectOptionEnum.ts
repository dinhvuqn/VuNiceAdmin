enum SelectOptionEnum {
  REQUEST_STATUS = 'requestStatus',
  REQUEST_TYPE = 'requestType',
  USER_ROLE = 'userRole',
  REASON = 'reason',
  PARTIAL_DAY = 'partialDay',
  USER = 'user',
  OFF_UNIT = 'offUnit',
  COUNTRY = 'country',
}

export default SelectOptionEnum;
