export enum ColorEnum {
  RED = 'red',
  BLUE = 'blue',
  GREEN = 'green',
}
