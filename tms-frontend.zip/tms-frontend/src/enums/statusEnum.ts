export enum StatusEnum {
  SUBMITTED = 10,
  CONFIRMED = 20,
  APPROVED = 30,
  REJECTED = 40,
  CANCELLED = 50,
  EDITED = 60,
  DELEGATED = 70,
}
