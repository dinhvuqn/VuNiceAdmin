/* Object type */
interface ObjTy {
  [propName: string]: any;
}

/* ant select option type */
type IOptions<T = number> = Array<{
  label: string;
  value: T;
  role?: number;
}>;

/* type of argument for showConfirmModal */
type TConfirmConfig = {
  type?: 'info' | 'warning';
  width?: number | string;
  title?: string;
  subTitle?: string;
  icon?: TIcon;
  onOK?: Fn;
  onCancel?: Fn;
};

const icons = [
  'calendar-outlined',
  'info-circle-outlined',
  'question-circle-filled',
  'logout-outlined',
  'check-outlined',
  'close-outlined',
  'message-outlined',
  'download-outlined',
  'check-circle-filled',
  'close-circle-filled',
  'info-circle-filled',
  'exclamation-circle-filled',
  'warning-outlined',
  'menu-outlined',
  'read-filled',
  'reconciliation-filled',
  'edit-outlined',
  'save-outlined',
  'minus-circle-outlined',
  'arrow-right-outline',
  'delete-outlined',
  'profile-filled',
  'history-outlined',
  'container-filled',
  'dashboard-filled',
  'bar-chart-outlined',
] as const;

type TIcon = typeof icons[number];

type TPickerEvent = { focus: Fn; blur: Fn };
