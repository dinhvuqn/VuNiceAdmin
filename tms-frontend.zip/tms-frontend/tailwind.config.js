const gridTemplateRows = {};

for (let i = 7; i <= 20; i++) {
  gridTemplateRows[i] = `repeat(${i}, minmax(0, 1fr))`;
}

module.exports = {
  content: ['./index.html', './src/**/*.{vue,js,ts}'],
  safelist: ['text-cyan-600', 'text-green-600', 'text-blue-600', 'text-orange-600', 'text-red-600'],
  theme: {
    extend: {
      gridTemplateRows,
    },
  },
  plugins: [],
};
