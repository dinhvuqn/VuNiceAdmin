import { RouteRecordRaw } from 'vue-router';
import { roleEnum } from '@/enums/roleEnum';

declare module 'vue-router' {
  export interface RouteMeta {
    icon?: TIcon;
    title?: string;
    breadcrumb?: string;
    role?: roleEnum[];
    hidden?: boolean;
    externalLink?: string;
  }
}

export const accessRoutes: RouteRecordRaw[] = [
  {
    path: '/',
    component: () => import('@/views/Dashboard/index.vue'),
    name: 'dashboard',
    meta: {
      title: 'menuTitle.dashboard',
      icon: 'dashboard-filled',
      role: [roleEnum.DIRETOR, roleEnum.PM],
    },
  },
];

const constantRoutes: RouteRecordRaw[] = [
  // {
  //   path: '/login',
  //   component: () => import('@/views/login/index.vue'),
  //   name: 'login',
  //   meta: {
  //     title: 'label.login',
  //   },
  // },
  ...accessRoutes,
  {
    path: '/:pathMatch(.*)',
    redirect: '/404',
  },
  {
    path: '/404',
    component: () => import('@/views/Dashboard/index.vue'),
    meta: {
      title: 'label.notFound',
    },
  },
  {
    path: '/403',
    component: () => import('@/views/403.vue'),
    meta: {
      title: 'label.accessDenied',
    },
  },
];

export default constantRoutes;
