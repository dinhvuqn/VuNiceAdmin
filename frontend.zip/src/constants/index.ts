export const pageSizeOptions: IOptions = [
  {
    label: '20',
    value: 20,
  },
  {
    label: '50',
    value: 50,
  },
  {
    label: '100',
    value: 100,
  },
];

// ==================TIME OFF LEAVE UNIT CODE===================

/**
 * Day(s) unit code
 */
export const OFF_UNIT_DAY_CODE = 10;

/**
 * Month(s) unit code
 */
export const OFF_UNIT_MONTH_CODE = 20;

/**
 * Request(s) unit code
 */
export const OFF_UNIT_REQUESTS_CODE = 30;

// ==================DOMAIN EMAIL===================

/**
 * Domain @sbifpt.com
 */
export const DOMAIN_EMAIL = '@sbifpt.com';
