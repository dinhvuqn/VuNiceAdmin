import {
  TLoginRequest,
  TLoginResponse,
  TPermissionResponse,
  TTmsUser,
  TSearch,
  TTmsUserData,
} from './model';
import { get, post } from '@/utils/http';
import { BaseService } from '../base.service';

enum URL {
  login = '/authentication/login',
  permission = '/authentication/permission',
  getAllUsers = '/list',
}

type TRequest = {};

type TResponse = {
  TDetail: { messageId: string; params: string[] };
};
class UserService extends BaseService<TRequest, TResponse> {
  static _instance = new UserService();

  get enity() {
    return '/users';
  }

  async login(formData: TLoginRequest) {
    return await post<TLoginResponse>({ url: URL.login, data: formData, notShowNotiPopup: true });
  }

  async permission() {
    return await get<TPermissionResponse>({ url: URL.permission });
  }
  async getAllUsers(params: TSearch) {
    return await get({ url: `${this.enity}${URL.getAllUsers}` }, { params });
  }
  async getUserId(id: string) {
    return await get({ url: `${this.enity}/${id}` });
  }
}

export type { TLoginRequest, TLoginResponse, TPermissionResponse, TTmsUser, TSearch, TTmsUserData };
export default UserService._instance;
