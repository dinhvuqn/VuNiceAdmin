<script setup lang="ts">
  import { DatePickerProps } from 'ant-design-vue/es';
  import moment, { MomentInput } from 'moment';

  interface IProps {
    value: DatePickerProps['value'] | string;
    format?: DatePickerProps['format'];
    valueFormat?: DatePickerProps['valueFormat'];
    showTime?: DatePickerProps['showTime'];
    disabled?: DatePickerProps['disabled'];
    disabledDate?: DatePickerProps['disabledDate'];
    picker?: DatePickerProps['picker'];
    allowClear?: DatePickerProps['allowClear'];
    disabledDateRange?: AtLeastOne<{
      min: MomentInput;
      max: MomentInput;
    }>;
    placeholder?: string;
    isDisabledWeekend?: boolean;
  }

  const props = withDefaults(defineProps<IProps>(), {
    format: ({ showTime, picker }: IProps): any => {
      if (showTime) return 'YYYY-MM-DD HH:mm:ss';

      switch (picker) {
        case 'year':
          return 'YYYY';
        case 'month':
          return ['YYYY-MM', 'YYYY/MM', 'YYYYMM'];
        case 'time':
          return ['HH:mm:ss', 'HH-mm-ss', 'HHmmss'];
        default:
          return ['YYYY-MM-DD', 'YYYY/MM/DD', 'YYYYMMDD'];
      }
    },
    valueFormat: ({ showTime, picker }: IProps) => {
      if (showTime) return 'YYYY-MM-DD HH:mm:ss';

      switch (picker) {
        case 'year':
          return 'YYYY';
        case 'month':
          return 'YYYY-MM';
        case 'time':
          return 'HH:mm:ss';
        default:
          return 'YYYY-MM-DD';
      }
    },
    isDisabledWeekend: true,
  });

  const emit = defineEmits(['update:value']);

  const value = computed({
    get() {
      return props.value;
    },
    set(value) {
      emit('update:value', value);
    },
  });

  const disabledDate = (current) => {
    // Need to disabled - Saturday:6 | Sunday:0
    if ([0, 6].includes(current.weekday()) && props.isDisabledWeekend) return true;

    if (props.disabledDateRange) {
      const { min, max } = props.disabledDateRange;

      return (min && current.valueOf() < moment(min)) || (max && current.valueOf() > moment(max));
    }

    return props.disabledDate && props.disabledDate(current);
  };

  const antPicker = ref();

  defineExpose(antPicker);
</script>

<template>
  <a-date-picker
    v-model:value="value"
    v-bind="{
      format,
      valueFormat,
      disabled,
      disabledDate,
      picker,
      showTime,
      allowClear,
      ...$attrs,
    }"
    ref="antPicker"
    :placeholder="placeholder || $t('label.selectDate')"
  />
</template>
