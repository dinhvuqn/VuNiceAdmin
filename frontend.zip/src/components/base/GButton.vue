<script setup lang="ts">
  import { ButtonProps } from 'ant-design-vue/es';
    
  type TButtonType = 'primary' | 'secondary' | 'success' | 'warning' | 'danger' | 'default';

  interface IProps {
    type?: TButtonType;
    disabled?: ButtonProps['disabled'];
    htmlType?: ButtonProps['htmlType'];
    loading?: ButtonProps['loading'];
  }

  const slots = useSlots();
  const props = withDefaults(defineProps<IProps>(), {
    type: 'default',
    disabled: false,
  });

  const btnClassName = computed(() => {
    const slotKeys = Object.keys(slots);

    return [
      'g-button',
      {
        [`btn--${props.type}`]: props.type,
        'ant-btn-icon-only': slotKeys.length === 1 && slotKeys.includes('icon'),
      },
    ];
  });
</script>

<template>
  <a-button v-bind="{ disabled, htmlType, loading }" :class="btnClassName">
    <template v-for="slot in Object.keys($slots)">
      <slot :name="slot"></slot>
    </template>
  </a-button>
</template>

<style lang="scss">
  .g-button.ant-btn {
    letter-spacing: 0.1px;
    font-size: 13px;
    font-weight: 500;

    &:not(:disabled),
    &:focus {
      color: var(--text-color, theme('colors.gray.600'));
      background: var(--bg-color, #fff);
      border-color: var(--border-color, theme('colors.gray.300'));
    }

    &:hover,
    &:focus-within {
      color: var(--text-color, theme('colors.sky.500'));
      background-color: var(--hover-bg-color);
      border-color: var(--hover-border-color, var(--hover-bg-color));
    }

    &:not(.btn--default) {
      &:focus-within {
        box-shadow: 0 0 0 2px var(--shadow-color);
        border-color: white;
      }
    }

    &.btn--default:focus-within {
      box-shadow: 0 0 0 1.5px rgb(14 165 233 / 50%);
    }

    &:disabled {
      color: var(--disabled-text-color, theme('colors.gray.400'));
      background-color: var(--disabled-bg-color, theme('colors.gray.200'));
      border-color: var(--disabled-border-color, theme('colors.gray.300'));
      opacity: 0.8;
    }

    &.btn--primary {
      --text-color: theme('colors.white');
      --bg-color: theme('colors.sky.600');
      --border-color: theme('colors.sky.600');
      --hover-bg-color: theme('colors.sky.500');
      --shadow-color: rgb(0 139 202 / 70%);
    }

    &.btn--secondary {
      --text-color: theme('colors.white');
      --bg-color: theme('colors.cyan.500');
      --border-color: theme('colors.cyan.500');
      --hover-bg-color: theme('colors.cyan.400');
      --shadow-color: rgb(34 211 238 / 70%);
    }

    &.btn--success {
      --text-color: #fff;
      --bg-color: theme('colors.emerald.400');
      --border-color: theme('colors.emerald.400');
      --hover-bg-color: theme('colors.emerald.300');
      --shadow-color: rgb(110 231 183 / 70%);
    }

    &.btn--warning {
      --text-color: theme('colors.white');
      --bg-color: theme('colors.amber.500');
      --border-color: theme('colors.amber.500');
      --hover-bg-color: theme('colors.amber.400');
      --shadow-color: rgb(251 191 36 / 70%);
    }

    &.btn--danger {
      --text-color: theme('colors.white');
      --bg-color: theme('colors.red.500');
      --border-color: theme('colors.red.500');
      --hover-bg-color: theme('colors.red.400');
      --shadow-color: rgb(248 113 113 / 70%);
    }
  }
</style>
