<script setup lang="ts">
  const props = withDefaults(
    defineProps<{ visible: boolean; title?: string; requiredComment: boolean }>(),
    { requiredComment: true },
  );

  const visible = computed({
    get() {
      return props.visible;
    },
    set(value) {
      emit('update:visible', value);
    },
  });

  const comment = ref('');

  const isDisabledOkBtn = computed(
    () => props.requiredComment && comment.value.trim().length === 0,
  );

  watch(
    () => props.visible,
    () => {
      comment.value = '';
    },
  );

  const emit = defineEmits(['update:visible', 'ok', 'cancel']);
</script>

<template>
  <a-modal
    v-model:visible="visible"
    centered
    class="g-comment-modal"
    :title="title || $t('label.comment')"
  >
    <div class="flex flex-col items-center">
      <a-textarea
        v-model:value="comment"
        :rows="4"
        :placeholder="$t('label.addAComment')"
        @blur="comment = comment.trim()"
        @keyup="comment = ($event.target as HTMLTextAreaElement).value"
      />
    </div>

    <template #footer>
      <a-space size="small">
        <g-button
          type="primary"
          class="w-20"
          :disabled="isDisabledOkBtn"
          @click="emit('ok', comment)"
        >
          {{ $t('label.ok') }}
        </g-button>
        <g-button class="w-20" @click="emit('cancel')">
          {{ $t('label.close') }}
        </g-button>
      </a-space>
    </template>
  </a-modal>
</template>

<style lang="scss">
  .g-comment-modal {
    .ant-modal-close-x {
      width: 48px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .ant-modal-header,
    .ant-modal-body {
      padding: 16px;
    }
  }
</style>
