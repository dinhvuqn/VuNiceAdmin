const TokenKey = 'x-auth-token';

type TStorageType = 'localStorage' | 'sessionStorage';

export function getToken() {
  return sessionStorage.getItem(TokenKey) || localStorage.getItem(TokenKey) || '';
}

export function setToken(from: TStorageType = 'localStorage', token: string) {
  const storage = from === 'localStorage' ? localStorage : sessionStorage;

  storage.setItem(TokenKey, token);
}

export function removeToken() {
  localStorage.removeItem(TokenKey);
  sessionStorage.removeItem(TokenKey);
}
