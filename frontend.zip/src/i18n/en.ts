export default {
  appTitle: 'Time Management System',
  tms: 'Time Management System',
  menuTitle: {
    home: 'Home',
  },
  message: {
    // Error message
    E0000: 'Unknow error!',

    // Warning message
    W0001: 'Are you sure?',

    // Success message
    S0001: 'Your request has been successfully submitted',
  },
  label: {
    homePageBtn: 'HOME PAGE',
  },
  params: {
    create: 'create',
  },
};
