<script setup lang="ts">
  // import Header from './components/Header.vue';
  // import SideMenu from './components/SideMenu.vue';

  const collapsed = ref(false);
  console.log(collapsed);
</script>

<template>
  <a-layout class="basic-layout-wrap">
    <!-- <side-menu v-model:collapsed="collapsed" /> -->

    <a-layout>
      <!-- <Header v-model:collapsed="collapsed" /> -->
      <a-layout-content class="basic-layout-content bg-gray-100">
        <router-view />
      </a-layout-content>
    </a-layout>
  </a-layout>
</template>

<style lang="scss" scoped>
  .basic-layout-wrap {
    height: 100vh;
    overflow: hidden;

    .basic-layout-content {
      height: calc(100vh - 80px);
      overflow-y: auto;
      margin: 0;
    }
  }
</style>
