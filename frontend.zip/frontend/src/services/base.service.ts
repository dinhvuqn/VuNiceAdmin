import { displayName } from './../utils/index';
import Http, { get, post, patch, remove, put } from '@/utils/http';
import { removeEmptyValues } from '@/utils/index';

type TBaseRequest = {
  TSearch: any;
  TCreate: any;
  TUpdate: any;
  TExport: any;
};

type TBaseResponse = {
  TList: any;
  TDetail: any;
  TExcelFile: any;
};

const CODE_TABLE_URL = '/code-table';
const USERS_URL = '/users';

type TCodeTableResponse = {
  [k: string]: {
    categoryID: string;
    code: string;
    categoryName: string;
    displayOrder: number;
    displayName: string;
    useFlag: number;
    explanation: string;
    createUserID: string;
    createDateTime: string;
    updateUserID: string;
    updateDateTime: string;
  }[];
};

type TUserRespone = {
  account: string;
  userID: string;
  roleCode: number;
  firstName: string;
  lastName: string;
}[];

type TOptionsResponse = {
  [k: string]: IOptions;
};

export class BaseService<T extends Partial<TBaseRequest>, R extends Partial<TBaseResponse>> {
  get enity(): string | void {
    throw new Error('entity getter not defined');
  }

  get request() {
    return { Http, get, post, patch, remove, put };
  }

  async getUsers() {
    return await get<TUserRespone>({ url: USERS_URL });
  }

  async getUserOptions() {
    const users = await this.getUsers();

    return users.map((userInfo) => {
      const { account, userID, roleCode, firstName, lastName } = userInfo;

      return {
        label: displayName(firstName, lastName, account),
        value: userID,
        role: roleCode,
        userInfo,
      };
    });
  }

  async getCodeTable(categoryIDs?: string[]) {
    return await get<TCodeTableResponse>({ url: CODE_TABLE_URL }, { params: { categoryIDs } });
  }

  async getSelectOptions(categoryIDs?: string[]) {
    const codeTable = await this.getCodeTable(categoryIDs);

    return Object.keys(codeTable).reduce((response, categoryId) => {
      response[categoryId] = codeTable[categoryId]
        .filter(({ displayOrder }) => displayOrder != 0)
        .map(({ code, displayName }) => ({
          value: code,
          label: displayName,
        }));

      return response;
    }, {}) as TOptionsResponse;
  }

  async getList(parameters: Partial<T['TSearch']> = {}) {
    const params = removeEmptyValues(parameters);

    return await get<R['TList']>({ url: this.enity! }, { params });
  }

  async getByID(id: string, subID = '') {
    return await get({ url: `${this.enity!}/${id}/${subID}` });
  }

  async create(data: T['TCreate']) {
    return await post<R['TDetail']>(
      { url: `${this.enity!}/create` },
      { data: removeEmptyValues(data) },
    );
  }

  async update(data: T['TUpdate']) {
    return await put<R['TDetail']>(
      { url: `${this.enity!}/update` },
      { data: removeEmptyValues(data) },
    );
  }

  async remove(id: string | number) {
    return await remove({ url: `${this.enity!}/${id}/delete` });
  }

  async exportExcel(parameters: Partial<T['TExport']> = {}) {
    const params = removeEmptyValues(parameters);

    return await get<string>({ url: `${this.enity!}/export`, responseType: 'blob' }, { params });
  }
}
