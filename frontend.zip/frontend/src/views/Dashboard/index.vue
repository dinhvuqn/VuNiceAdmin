<script setup lang="ts"></script>

<i18n src="./locale" />
<template>
  <g-top-content />
  <transition name="fade-slide" mode="out-in" appear>
    <div class="overflow-auto">
      <h1>Hello Word</h1>
    </div>
  </transition>
</template>
