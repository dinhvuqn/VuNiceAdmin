<script setup lang="ts">
  import { TableProps } from 'ant-design-vue/es';
  import { pageSizeOptions } from '@/constants';
  import { Empty } from 'ant-design-vue';

  interface IProps {
    columns: TableProps['columns'];
    dataSource: TableProps['dataSource'];
    rowKey: TableProps['rowKey'];
    rowSelection?: TableProps['rowSelection'];
    rowClassName?: TableProps['rowClassName'];
    pagination?: TableProps['pagination'];
    currentPage?: number;
    pageSize?: number;
    size?: TableProps['size'];
    scroll?: TableProps['scroll'];
    total?: number;
    loading?: TableProps['loading'];
  }

  const props = withDefaults(defineProps<IProps>(), {
    rowKey: 'id',
    rowClassName: () => (_: any, index: number) => (index % 2 ? 'bg-gray-50' : ''),
    pagination: () => ({}),
    size: 'small',
    scroll: () => ({ y: 640, x: 1000 }),
  });

  const { locale } = useI18n();

  const emit = defineEmits(['update:currentPage', 'update:pageSize', 'pagination', 'refresh-list']);

  const currentPage = computed({
    get() {
      return props.currentPage;
    },
    set(pageNumber) {
      emit('update:currentPage', pageNumber);
    },
  });

  const pageSize = computed({
    get() {
      return props.pageSize;
    },
    set(pageSize) {
      emit('update:pageSize', pageSize);
    },
  });

  watch(
    () => locale.value,
    () => emit('refresh-list'),
  );
</script>

<template>
  <a-table
    bordered
    class="g-table"
    :pagination="false"
    v-bind="{
      columns,
      dataSource,
      rowKey,
      rowSelection,
      rowClassName,
      size,
      loading,
      scroll,
      ...$attrs,
    }"
  >
    <template #emptyText>
      <a-empty :description="$t('label.noData')" :image="Empty.PRESENTED_IMAGE_SIMPLE" />
    </template>
    <template v-for="(slot, index) in Object.keys($slots)" :key="index" #[slot]="slotProps">
      <slot :name="slot" v-bind="slotProps"></slot>
    </template>
  </a-table>

  <div v-if="pagination" class="flex justify-between items-center mt-5">
    <div>
      <span v-if="total > 0" class="mr-0">
        {{ $t('label.totalRecords', { total }) }}{{ ' - ' }}
      </span>
      <label class="mr-2">{{ $t('label.show') }}</label>
      <a-select
        v-model:value="pageSize"
        class="w-20"
        :options="pageSizeOptions"
        @change="emit('pagination')"
      />
    </div>
    <div class="flex items-center">
      <a-pagination
        v-model:current="currentPage"
        v-model:pageSize="pageSize"
        :total="total"
        :show-size-changer="false"
        v-bind="pagination"
        @change="emit('pagination', $event)"
      />
    </div>
  </div>
</template>

<style lang="scss">
  .g-table {
    .ant-table-cell-row-hover {
      background-color: theme('colors.blue.50') !important;
    }
  }
</style>
