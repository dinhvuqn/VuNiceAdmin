export enum StatusEnum {
  STATUS_1 = 10,
  STATUS_2 = 20,
}
