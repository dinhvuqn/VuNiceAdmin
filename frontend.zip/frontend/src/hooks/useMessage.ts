import { message as Message } from 'ant-design-vue';

// import 'ant-design-vue/es/message/style/css';

export function useMessage() {
  return {
    createMessage: Message,
  };
}
