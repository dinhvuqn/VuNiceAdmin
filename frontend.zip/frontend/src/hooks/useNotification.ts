import { h } from 'vue';
import { notification as Notification } from 'ant-design-vue';
import GIcon from '@/components/base/GIcon.vue';
// import 'ant-design-vue/es/notification/style/css';
import { i18n } from '@/i18n';

type TType = 'success' | 'error' | 'info' | 'warning';

const { t } = i18n.global;

const icon = {
  success: 'check-circle-filled',
  error: 'close-circle-filled',
  info: 'info-circle-filled',
  warning: 'exclamation-circle-filled',
};

const notification = (type: TType, description: string, duration = 3) => {
  const message = {
    success: t('label.success'),
    error: t('label.error'),
    info: t('label.info'),
    warning: t('label.warning'),
  };

  Notification[type]({
    message: message[type],
    description,
    duration,
    icon: () => h(GIcon, { icon: icon[type] as TIcon }),
    closeIcon: () => h(GIcon, { icon: 'close-circle-filled' }),
    class: `ant-notification-notice--${type}`,
  });
};

export function useNotification() {
  return {
    createNotification: notification,
    Notification,
  };
}
