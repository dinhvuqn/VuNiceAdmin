/**
 * Configure and register global directives
 */
import type { App } from 'vue';
import { setupRoleDirective } from './role';

export function setupGlobDirectives(app: App) {
  setupRoleDirective(app);
}
